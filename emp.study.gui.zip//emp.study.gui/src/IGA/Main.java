package IGA;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import javax.swing.UnsupportedLookAndFeelException;

import pack.gui.mainGUI;
public class Main{
	public static ArrayList<String> PRIOFILEs = new ArrayList<String>();
	public static ArrayList<String> DEPFILEs = new ArrayList<String>();
	static StringBuilder sb;
	public static double TOTAL_ELI_TIME=0, TOTAL_PRIO_TIME, START_TIME, END_TIME=0, ELI_START_TIME, ELI_END_TIME, MAX_ELI_TIME=0.0, MIN_ELI_TIME=9999, AVG_ELI_TIME;
	
	public static long timeOut;
	public static int threshholdDisagreement, TotRunNumber, GENERATIONS, NUM_REQ, IteratorIGA, SEQ_REQ, donePair, pGraphFlag, dGraphFlag, totalTie=0, WEIGHT_PRIO, WEIGHT_DEP, WEIGHT_ELI;
	public static float topPopulationPerc;
	public void main(String string) throws IOException, InterruptedException, ArrayIndexOutOfBoundsException, InvocationTargetException, ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
		System.out.println("Starting Main module for IGA...");
		Main.START_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
		//donePair = Integer.parseInt(configFile.getProperty("user_error_rate"));
		//pGraphFlag = Integer.parseInt(configFile.getProperty("priority_graph_flag"));
		//dGraphFlag = Integer.parseInt(configFile.getProperty("dependency_graph_flag"));
		//WEIGHT_PRIO = Integer.parseInt(configFile.getProperty("weight_priority"));
		//WEIGHT_DEP = Integer.parseInt(configFile.getProperty("weight_dependency")); 
		//WEIGHT_ELI = Integer.parseInt(configFile.getProperty("weight_elicited"));
		//timeOut = Integer.parseInt(configFile.getProperty("time_out"))*1000;
		//TotRunNumber = Integer.parseInt(configFile.getProperty("total_run_number"));
		//threshholdDisagreement = Integer.parseInt(configFile.getProperty("minimum_disagreement"));
		//topPopulationPerc = Float.parseFloat(configFile.getProperty("percentage_population"));
		String filepath = mainGUI.OutPath + "iga/results/iga_framework.out";
		FileWriter fstream = new FileWriter(filepath);
		fstream.close();
		getSize gS = new getSize();
		NUM_REQ = gS.getPopulationSize(mainGUI.x1);
		SEQ_REQ = NUM_REQ;
		
		//get prio count
		final File priofolder = new File(mainGUI.PROJECT_PATH+"in/"+mainGUI.x1+"/prio/");
		File[] priolistOfFiles = priofolder.listFiles();
		mainGUI.TOTPRIO = priolistOfFiles.length;
		for (int i = 0; i < priolistOfFiles.length; i++){
		    File fileEntry = priolistOfFiles[i];
		    if (!fileEntry.isDirectory()){
		        PRIOFILEs.add(fileEntry.getName());
		    }
		}
		//get dep count
		final File depfolder = new File(mainGUI.PROJECT_PATH+"in/"+mainGUI.x1+"/dep/");
		File[] deplistOfFiles = depfolder.listFiles();
		mainGUI.TOTDEP = deplistOfFiles.length;
		for (int i = 0; i < deplistOfFiles.length; i++){
		    File fileEntry = deplistOfFiles[i];
		    if (!fileEntry.isDirectory()){
		        DEPFILEs.add(fileEntry.getName());
		    }
		}
		
		//clear previous files...
		clearIGAFiles cF1 = new clearIGAFiles();
		cF1.deleteFiles();

		//CALLING FOR IGA PRIORITIZATION...
			IGAMain igamain = new IGAMain();
			igamain.subMain(mainGUI.x1);
			
		//FINAL FRAMEWORK FOR RAND, GA AND IGA...
			mainFrame mF = new mainFrame();
			mF.framework();
			if(mainGUI.GSFLAG == 1){
			disAgrGS dAGS = new disAgrGS();
			dAGS.disAgreementEliOrder(mainGUI.x1);
			
			analysisGA dAGS1 = new analysisGA();
			dAGS1.disAgreementEliOrder(mainGUI.x1);
			}
			Main.END_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
			Main.TOTAL_PRIO_TIME = Double.parseDouble((mainGUI.fmtObj.format(Main.END_TIME - Main.START_TIME)));
			
			creatFramework cF2 = new creatFramework();
			cF2.creatFrameworkMethod(mainGUI.x1);
			System.out.println("Finished Main module for IGA...");
	}
}
