package IGA;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;


public class findMindisAgreement {

	public void minDisAgreement() throws IOException{
		BufferedWriter bw = null, bw1 = null, bw2 = null, bw3 = null;
		String filepath = mainGUI.OutPath + "iga/analysis/disAgreementMINrow.txt";
		bw = new BufferedWriter(new FileWriter(filepath));
		filepath = mainGUI.OutPath + "iga/analysis/disAgreementMIN.txt";
		bw1 = new BufferedWriter(new FileWriter(filepath));
		filepath = mainGUI.OutPath + "iga/analysis/disAgreementAVG.txt";
		bw2 = new BufferedWriter(new FileWriter(filepath));
		filepath = mainGUI.OutPath + "iga/analysis/disAgreementSTDV.txt";
		bw3 = new BufferedWriter(new FileWriter(filepath));
		filepath = mainGUI.OutPath + "iga/analysis/disAgreement.txt";
		FileInputStream Fstream = new FileInputStream(filepath);
		DataInputStream IN = new DataInputStream(Fstream);
		BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
		String strLine;
		while ((strLine = BR.readLine()) != null){
			String[] temp0 = strLine.split("\t");
			int[] temp = new int[temp0.length/Main.NUM_REQ];
			for(int j=0; j<temp0.length/Main.NUM_REQ; j++){
				int index = j*Main.NUM_REQ;
				int minR = Integer.parseInt(temp0[index]);
				for(int i=j*Main.NUM_REQ; i<j*Main.NUM_REQ+Main.NUM_REQ; i++){
					if(Integer.parseInt(temp0[i]) < minR)
						minR = Integer.parseInt(temp0[i]);
				}
				temp[j] = minR;
			}
			
			int[] disAry = new int[temp.length];
			int min, j=0;
			min = temp[0];
			disAry[j] = min;
			for(int i=1; i<temp.length; i++){
				j++;
				if(temp[i] < min){
					disAry[j]  = temp[i];
					min = temp[i];
				}
				else
					disAry[j]  = min;
			}
			int sum=0;
			for(int i=0; i<temp.length; i++)
				sum = sum + temp[i];
			int avg = sum / temp.length;
			int stdvsum=0;
			for(int i=0; i<temp.length; i++)
				stdvsum = (int) (stdvsum + Math.pow((temp[i]-avg),2));
			int stdDV = (int) Math.sqrt(stdvsum/temp.length);
			filepath = mainGUI.OutPath + "iga/analysis/disAgreementMINrow.txt";
			bw = new BufferedWriter(new FileWriter(filepath,true));
			filepath = mainGUI.OutPath + "iga/analysis/disAgreementMIN.txt";
			bw1 = new BufferedWriter(new FileWriter(filepath,true));
			filepath = mainGUI.OutPath + "iga/analysis/disAgreementAVG.txt";
			bw2 = new BufferedWriter(new FileWriter(filepath,true));
			filepath = mainGUI.OutPath + "iga/analysis/disAgreementSTDV.txt";
			bw3 = new BufferedWriter(new FileWriter(filepath,true));
			
			for(int i=0; i<disAry.length; i++){
				if(disAry[i] != 0)
				bw.write(disAry[i]+"\t");
			}
			bw.write("\n");
			bw.flush();
			bw1.write(min+"\t");
			bw1.flush();
			bw2.write(avg+"\t");
			bw2.flush();
			bw3.write(stdDV+"\t");
			bw3.flush();
		}
		bw.close(); bw1.close(); bw2.close(); bw3.close();
	}
}

