package IGA;
import java.awt.HeadlessException;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.UnsupportedLookAndFeelException;

import pack.gui.mainGUI;


/**
 * @author Francis Palma
 *
 */
public class Algorithm{
	
	public static double[] ELI_CUMUL_TIME_SUM = new double[mainGUI.MAX_ELI_PAIR];
	public static double[] ELI_INDV_TIME = new double[mainGUI.MAX_ELI_PAIR];
	public static int[] eliOrderFlag = new int[mainGUI.MAX_ELI_PAIR];
	public static String[] Pr_min = new String[Main.NUM_REQ], eliOrderedPair = new String[mainGUI.MAX_ELI_PAIR], errorEli = new String[mainGUI.MAX_ELI_PAIR];
	public static String[][] Prio = new String[Main.NUM_REQ+1][Main.NUM_REQ], Prio_New = new String[Main.NUM_REQ+1][Main.NUM_REQ];
	public static int[][] eliCitedMatrix = new int[Main.SEQ_REQ][Main.SEQ_REQ];
	public static int elicitedPairs = 0, maxElicitedPairs = mainGUI.MAX_ELI_PAIR, percentDone, totalTies, nn=0, errorPair=0;
	public static int[] randPos = new int[mainGUI.MAX_ELI_PAIR], errorDone = new int[mainGUI.MAX_ELI_PAIR];
	FileInputStream fis = null, fstream = null, Fstream = null;
	BufferedInputStream bis = null;
	DataInputStream dis = null, in = null, IN = null;
	BufferedReader br = null, BR = null;
	public int iterate = 1;
	public Algorithm() throws ArrayIndexOutOfBoundsException, IOException{}

	public void prioritizationRequirement(String x1) throws IOException,ArrayIndexOutOfBoundsException, InterruptedException, InvocationTargetException, ClassNotFoundException, InstantiationException, IllegalAccessException, HeadlessException, UnsupportedLookAndFeelException {
		int index=0;
		System.out.println("Starting main algorithm for IGA...");
		
		initPopulation IPop = new initPopulation();
		IPop.initializePopulation(x1);

		for(int x=0; x<getSize.populationSIZE+1; x++){
			for(int y=0; y<getSize.populationSIZE; y++){				
				Prio_New[x][y] = Prio[x][y];
			}
		}
				
		//7 compute disagreement.
		disAgreementCalc disAgree = new disAgreementCalc();
		disAgree.disAgreementFind();
		int iteration = 0;
		
		BufferedWriter bw = null;
		//bw = new BufferedWriter(new FileWriter("../IGA/Resources/disAgreement.txt"));
		String filepath = mainGUI.OutPath+"iga/analysis/disAgreement.txt";
		bw = new BufferedWriter(new FileWriter(filepath, true));
		iteration++;
		int sum=0;
		for(int k=0; k<getSize.populationSIZE+1; k++){
			sum = sum + disAgreementCalc.disagreement[k];
			bw.write(disAgreementCalc.disagreement[k] +"\t");
		}
		bw.flush();
		bw.close();

		//writing the populations in the file
		filepath = mainGUI.OutPath+"iga/analysis/population.txt";
		bw = new BufferedWriter(new FileWriter(filepath, true));
		filepath = mainGUI.OutPath+"iga/analysis/populationtemp.txt";
		BufferedWriter bwtemp = new BufferedWriter(new FileWriter(filepath));
		bw.write(IGAMain.RunNumber + "\n");
    	for(int m=0; m<getSize.populationSIZE+1; m++){
    		for(int n=0; n<getSize.populationSIZE; n++){
    			bw.write(Prio[m][n] + " ");
    			bwtemp.write(Prio[m][n] + " ");
    		}
    		bw.write("\n");
    		bwtemp.write("\n");
    	}
    	bw.write("\n");
    	bw.close();		
    	bwtemp.write("\n");
    	bwtemp.flush();
    	bwtemp.close();
        
        elicitedPairs = 0;
        
        BufferedWriter bw2 = null;
        int[] locOpt = new int[5];
        for(int i=0; i<locOpt.length; i++)
        	locOpt[i] = 0;
        int p=0;
        
		//totalTies=0;
        while((minDisAgree.minDisagreementValue > Main.threshholdDisagreement) && (elicitedPairs <= maxElicitedPairs) && (iterate <= Main.GENERATIONS)){
		
        	//System.out.println("run: "+ IGAMain.RunNumber +"\t"+"generation: "+iterate + "\teli pair: "+ elicitedPairs + "\tmin dis: " + minDisAgree.minDisagreementValue);
        	//11.

        	samplePopTournamentSelect samP = new samplePopTournamentSelect();
        	samP.tournamentSelection();
						
			for(int x=0; x<getSize.populationSIZE+1; x++){
				for(int y=0; y<getSize.populationSIZE; y++){
					Prio_New[x][y] = Prio[x][y];
				}
			}

			//12 sort in increasing order.
			for (int pass=0; pass < getSize.populationSIZE+1; pass++) {  // count how many time s
		        for (int i=0; i < getSize.populationSIZE; i++) {
		            if (disAgreementCalc.disagreement[i] > disAgreementCalc.disagreement[i+1]) {
		                int temp = disAgreementCalc.disagreement[i];  
		                disAgreementCalc.disagreement[i] = disAgreementCalc.disagreement[i+1];  
		                disAgreementCalc.disagreement[i+1] = temp;
		                for(int k=0; k<getSize.populationSIZE; k++){
		                	String tempS = Prio[i][k];
		                	Prio[i][k] = Prio[i+1][k];
		                	Prio[i+1][k] = tempS;
		                	tempS = Prio_New[i][k];
		                	Prio_New[i][k] = Prio_New[i+1][k];
		                	Prio_New[i+1][k] = tempS;
		                }
		            }
		        }
		    }
			
			//13 checking ties in top 5% indv.
			int checkTiesValue=0;
			checkTies cT = new checkTies();
			checkTiesValue = cT.checkTiesTOPpopulationPerc();
			
			//local optimizations.....checking if min disagreement remains same for last five times.
			int check=1, zeroflag=0, ixflag=0;
			if(p == 4){
				p = 0;
				ixflag=1;
			}
			if(ixflag == 0){
				locOpt[p] = minDisAgree.minDisagreementValue;
				p = p + 1;
			}
			int temp = locOpt[0];
			for(int t=1; t<4; t++){
				if(temp != locOpt[t])
					check = 0;}
			for(int t=0; t<4; t++){
				if(locOpt[t] == 0)
					zeroflag = 1;}
			if(checkTiesValue == 1 && elicitedPairs < maxElicitedPairs && zeroflag == 0 && check == 1){
				//System.out.println("called to elicition on: " + iterate + " with " + elicitedPairs);
				Main.sb = new StringBuilder(); 
				double START_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
				elicitPairs.doPairElicit(x1);
				double END_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
				if(Main.sb.length() > 0){
					elicitPairs.ELI_SESSION[index][0] = Main.sb.toString();
					elicitPairs.ELI_SESSION[index][1] = Double.toString(END_TIME - START_TIME);
					index++;
				}
				//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				//frame.add(textField);
				//String text = textField.getText();
				//System.out.println(text);
				//frame.setVisible(true);

				//System.out.println("returned from elicition on: " + iterate + " with " + elicitedPairs);
			}
			Random randomGenerator = new Random();
 			int randN = randomGenerator.nextInt(100);
			if(randN <= 10){
				// 17 - mutation
				mutationCalc mutationC = new mutationCalc();
				mutationC.performMutation();
			}
			else{
				// 18 - cross over.
				crossOverCalc crossOver = new crossOverCalc();
				crossOver.performCrossOver();
			}

			for(int x=0; x<getSize.populationSIZE+1; x++){
				for(int y=0; y<getSize.populationSIZE; y++){
					Prio_New[x][y] = Prio[x][y];
				}
			}
			
			//19 - 22 calculating the dis agreement in the iteration
			disAgreementElicited disAgrElicited = new disAgreementElicited();
			disAgrElicited.disAgreementFindElicited();
			
			for(int i=0; i<getSize.populationSIZE; i++)
				Pr_min[i] = Prio[minDisAgree.minDisAgIndex][i];
			filepath = mainGUI.OutPath + "iga/analysis/disAgreement.txt";
			bw2 = new BufferedWriter(new FileWriter(filepath, true));
			///////bw2.write("\n");
			iteration++;
			sum=0;
			for(int k=0; k<getSize.populationSIZE+1; k++){
				sum = sum + disAgreementCalc.disagreement[k];
				bw2.write(disAgreementCalc.disagreement[k] + "\t");
			}
			//initialSum[iteration-1] = sum;
			bw2.flush();
			bw2.close();
			
			//write the population set in the file
			filepath = mainGUI.OutPath + "iga/analysis/population.txt";
        	bw = new BufferedWriter(new FileWriter(filepath, true));
        	filepath = mainGUI.OutPath + "iga/analysis/populationtemp.txt";
        	bwtemp = new BufferedWriter(new FileWriter(filepath, true));
			
        	for(int m=0; m<getSize.populationSIZE+1; m++){
        		for(int n=0; n<getSize.populationSIZE; n++){
        			bw.write(Prio[m][n] + " ");
        			bwtemp.write(Prio[m][n] + " ");
        		}
        		bw.write("\n");
        		bwtemp.write("\n");
        	}
        	bw.write("\n");
        	bw.close();
        	bwtemp.write("\n");
        	bwtemp.flush();
        	bwtemp.close();
        	iterate = iterate + 1;
        	 
	}//end while
		
		JOptionPane.showMessageDialog(null, "Running post prioritization analysis...  \nThis will take several minutes, please wait...           \n\nPress OK to continue...  \n\n");
        filepath = mainGUI.OutPath + "iga/analysis/population.txt";
        bw = new BufferedWriter(new FileWriter(filepath, true));
        bw.write(IGAMain.RunNumber + "\n");
        bw.close(); 
		
		filepath = mainGUI.OutPath + "iga/analysis/disAgreement.txt";
		BufferedWriter bw5 = new BufferedWriter(new FileWriter(filepath, true));
		bw5.write("\n");
		bw5.close();
		
		//disagreement for the final elicited graph`
		disAgrFinalElicitedGraph disAgrFinalElicited = new disAgrFinalElicitedGraph();
		disAgrFinalElicited.disAgreementFinalElicited();
		BufferedWriter bw3 = null;
		
		//bw = new BufferedWriter(new FileWriter("../IGA/Resources/disAgrFinalEli.txt"));
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEli.txt";
		bw3 = new BufferedWriter(new FileWriter(filepath, true));
		bw3.write("\n");
		bw3.close();
		
		//disagreement in respect of gold standard
		if(mainGUI.GSFLAG==1){
			disAgrElicitedOrder disEliOrder =  new disAgrElicitedOrder();
			disEliOrder.disAgreementEliOrder(x1);
			BufferedWriter bw4 = null;
			filepath = mainGUI.OutPath + "iga/analysis/disAgrGoldSTD.txt";
			bw4 = new BufferedWriter(new FileWriter(filepath, true));
			bw4.write("\n");
			bw4.close();}
		System.out.println("Finished main algorithm for IGA...");
	}

}//end class