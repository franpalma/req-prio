package IGA;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;


public class findMindisAgrFinalEli {

	public void minDisAgreementFinalEli() throws IOException{
		BufferedWriter bw = null; BufferedWriter bw1 = null; BufferedWriter bw2 = null; BufferedWriter bw3 = null;
		String filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliMINrow.txt";
		bw = new BufferedWriter(new FileWriter(filepath));
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliMIN.txt";
		bw1 = new BufferedWriter(new FileWriter(filepath));
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliAVG.txt";
		bw2 = new BufferedWriter(new FileWriter(filepath));
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliSTDV.txt";
		bw3 = new BufferedWriter(new FileWriter(filepath));
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEli.txt";
		FileInputStream Fstream = new FileInputStream(filepath);
		DataInputStream IN = new DataInputStream(Fstream);
		BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
		String strLine;
		while ((strLine = BR.readLine()) != null){
			String[] temp0 = strLine.split("\t");
			int[] temp = new int[temp0.length/Main.NUM_REQ];
			for(int j=0; j<temp0.length/Main.NUM_REQ; j++){
				int minR = Integer.parseInt(temp0[j*Main.NUM_REQ]);
				for(int i=j*Main.NUM_REQ; i<j*Main.NUM_REQ+Main.NUM_REQ; i++){
					if(Integer.parseInt(temp0[i]) < minR){
						minR = Integer.parseInt(temp0[i]);
					}
				}
				temp[j] = minR;
			}
			
			int[] disAry = new int[temp.length];
			int min, j=0;
			min = temp[0];
			disAry[j] = min;
			for(int i=1; i<temp.length; i++){
				j++;
				if(temp[i] < min){
					disAry[j]  = temp[i];
					min = temp[i];
				}
				else
					disAry[j]  = min;
			}
			int sum=0;
			for(int i=0; i<temp.length; i++)
				sum = sum + temp[i];
			int avg = sum / temp.length;
			int stdvsum=0;
			for(int i=0; i<temp.length; i++)
				stdvsum = (int) (stdvsum + Math.pow((temp[i]-avg),2));
			int stdDV = (int) Math.sqrt(stdvsum/temp.length);
			filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliMINrow.txt";
			bw = new BufferedWriter(new FileWriter(filepath, true));
			filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliMIN.txt";
			bw1 = new BufferedWriter(new FileWriter(filepath, true));
			filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliAVG.txt";
			bw2 = new BufferedWriter(new FileWriter(filepath, true));
			filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliSTDV.txt";
			bw3 = new BufferedWriter(new FileWriter(filepath, true));
			for(int i=0; i<disAry.length; i++)
				bw.write(disAry[i]+"\t");
			bw.write("\n");
			bw.flush();
			bw1.write(min+"\t");
			bw1.flush();
			bw2.write(avg+"\t");
			bw2.flush();
			bw3.write(stdDV+"\t");
			bw3.flush();
		}
		bw.close(); bw1.close(); bw2.close(); bw3.close();
	}
}

