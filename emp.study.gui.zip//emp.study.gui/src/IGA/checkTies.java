package IGA;

public class checkTies {
	public static int minDisValueTies;
	public static int tiesIndex = 0;
	
	public int checkTiesTOPpopulationPerc(){
		System.out.println("Checking ties for IGA...");
		int flag=0;
		minDisValueTies = disAgreementCalc.disagreement[0];
		for(int i=1; i<getSize.populationSIZE+1; i++)	{
			if(minDisValueTies == disAgreementCalc.disagreement[i])		{
				minDisValueTies = disAgreementCalc.disagreement[i];
				tiesIndex = i;
				flag = 1;
			}
		}
		if(flag  == 0)
			return 0;
		else 
			return 1;
	}
}
