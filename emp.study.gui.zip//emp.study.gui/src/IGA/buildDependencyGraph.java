package IGA;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;

public class buildDependencyGraph {
	public static int[][][] depndencyMatrix = new int[mainGUI.TOTDEP][Main.SEQ_REQ][Main.SEQ_REQ];
	public buildDependencyGraph(){}

	public void buildDepGraph(String x1) throws NumberFormatException, IOException{
		System.out.println("Building 'Dep' graph for IGA...");
		String prepath = mainGUI.InPath;
		String postpath = "/dep/";	
	for(int x=0; x<mainGUI.TOTDEP; x++){
		String filepath = prepath + x1 + postpath + Main.DEPFILEs.get(x);
		FileInputStream FStream = new FileInputStream(filepath);
		DataInputStream In = new DataInputStream(FStream);
		BufferedReader Br = new BufferedReader(new InputStreamReader(In));
		String strLine;
		while ((strLine = Br.readLine()) != null){
			String[]  temp = strLine.split(" ");
			int tempSIZE = temp.length;
			int dstDep = Integer.parseInt(temp[0].substring(2, 5));
				for(int i=1; i<tempSIZE; i++){
					int srcDep = Integer.parseInt(temp[i].substring(2, 5));
					depndencyMatrix[x][srcDep-1][dstDep-1] = 1;
					depndencyMatrix[x][dstDep-1][srcDep-1] = -1;
			}
		}
		FStream.close(); In.close(); Br.close();
	}
		System.out.println("Finished building 'Dep' graph for IGA...");
	}
}
