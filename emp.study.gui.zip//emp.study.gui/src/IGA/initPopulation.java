package IGA;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;


public class initPopulation {
	public void initializePopulation(String x1) throws IOException{
		System.out.println("Initializing population for IGA...");
		String postpath  = "/oth/";
		String prepath = mainGUI.InPath;
		String filepath = prepath + x1 + postpath+"/prList.txt";
		FileInputStream Fstream = new FileInputStream(filepath);
		DataInputStream IN = new DataInputStream(Fstream);
		BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
	String strLine;
	int linecount = 0;
	while((strLine = BR.readLine()) != null){
		String[] temp = new String[Main.NUM_REQ];
		temp = strLine.split(" ");
		for(int j=0; j<temp.length; j++){
			Algorithm.Prio[linecount][j] = temp[j];
		}
		linecount++;
	}
	BR.close();
	IN.close();
	Fstream.close();
	}
}
