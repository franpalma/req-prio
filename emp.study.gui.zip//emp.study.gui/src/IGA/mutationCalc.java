package IGA;

import java.util.Random;

public class mutationCalc {

	public mutationCalc(){
	}
	
	public void performMutation(){
		System.out.println("Applying Mutation operator for IGA...");
		Random randomGenerator = new Random();
		for(int i=0; i< getSize.populationSIZE+1; i++){
			int random1 = randomGenerator.nextInt(getSize.populationSIZE);
			int random2 = randomGenerator.nextInt(getSize.populationSIZE);
			
			if(random1 == random2)			{
				random1 = randomGenerator.nextInt(getSize.populationSIZE);
				random2 = randomGenerator.nextInt(getSize.populationSIZE);
			}		
			
			String temp;
			temp  = Algorithm.Prio[i][random1];
			Algorithm.Prio[i][random1] = Algorithm.Prio[i][random2];
			Algorithm.Prio[i][random2] = temp;
		}
	}
}