package IGA;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;


public class disAgrFinalElicitedGraph{
	public void disAgreementElicited() {}
	public String[][] Prio_Final = new String[Main.NUM_REQ+1][Main.NUM_REQ];
	//public static int[] finalSum = new int[30000], 
	public static int[] finalDisagr = new int[Main.NUM_REQ+1];
	public static FileInputStream Fstream = null;
	public static DataInputStream IN = null;
	public static BufferedReader BR = null;
	
	public void disAgreementFinalElicited() throws IOException{
		System.out.println("Calculating disagreement against final elicited graph for IGA...");
		BufferedWriter bw = null;
		String filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEli.txt";
		bw = new BufferedWriter(new FileWriter(filepath, true));
		filepath = mainGUI.OutPath + "iga/analysis/populationtemp.txt";
		Fstream = new FileInputStream(filepath);
		IN = new DataInputStream(Fstream);
		BR = new BufferedReader(new InputStreamReader(IN));
		String strLin="";
		while ((strLin = BR.readLine()) != null){
			int l=0;
			if(!strLin.equals("")){
				String[] temp = strLin.split(" ");
				if(temp.length == 1) 
					continue;
				for(int i=0; i<temp.length; i++){
					Prio_Final[l][i] = temp[i];
				}
				l++;
			while ((strLin = BR.readLine()) != null){
				if(strLin.equals(""))
					break;
			temp = strLin.split(" ");
			if(temp.length == 1) 
				continue;
			for(int i=0; i<temp.length; i++){
				Prio_Final[l][i] = temp[i];
			}
			l++;
			}
			}
		
		int indexTemp1, indexTemp2, n1=0, n2=0;
		
		//disagree for prios and eli
		for(int x=0; x<mainGUI.TOTPRIO; x++){
		for(int k=0; k<getSize.populationSIZE+1; k++){
			finalDisagr[k] = 0;
			
			for(int i=0; i<getSize.populationSIZE-1; i++){
				for(int j=i+1; j<getSize.populationSIZE; j++){
					for(int f=0; f<Main.NUM_REQ; f++){
						if(Algorithm.Prio_New[k][i] != null){
							if(Prio_Final[k][i].equalsIgnoreCase(getPriority.listNodes[x][f]))
								n1 = f;
						}
						if(Algorithm.Prio_New[k][j] != null){
							if(Prio_Final[k][j].equalsIgnoreCase(getPriority.listNodes[x][f]))
								n2 = f;
						}						
					}
					indexTemp1 = Integer.parseInt(Prio_Final[k][i].substring(2,5))-1;
					indexTemp2 = Integer.parseInt(Prio_Final[k][j].substring(2,5))-1;
					
					if(Main.pGraphFlag == 1 && Main.dGraphFlag == 1){
						if((getPriority.nodesPriority[x][n1]) > (getPriority.nodesPriority[x][n2]))
							finalDisagr[k] = finalDisagr[k] + Main.WEIGHT_PRIO;
					}
					
					else if(Main.pGraphFlag == 1 && Main.dGraphFlag == 0){
						if((getPriority.nodesPriority[x][n1]) > (getPriority.nodesPriority[x][n2]))
							finalDisagr[k] = finalDisagr[k] + Main.WEIGHT_PRIO;
					}
				}
			}
		}
		}
		//disagree for deps only
		for(int x=0; x<mainGUI.TOTDEP; x++){
			for(int k=0; k<getSize.populationSIZE+1; k++){
//				finalDisagr[k] = 0;
				
				for(int i=0; i<getSize.populationSIZE-1; i++){
					for(int j=i+1; j<getSize.populationSIZE; j++){
						indexTemp1 = Integer.parseInt(Prio_Final[k][i].substring(2,5))-1;
						indexTemp2 = Integer.parseInt(Prio_Final[k][j].substring(2,5))-1;
						
						if(Main.pGraphFlag == 1 && Main.dGraphFlag == 1){
							if(buildDependencyGraph.depndencyMatrix[x][indexTemp1][indexTemp2] == -1)
								finalDisagr[k] = finalDisagr[k] + Main.WEIGHT_DEP;
						}
						
						else if(Main.pGraphFlag == 0 && Main.dGraphFlag == 1){
							if(buildDependencyGraph.depndencyMatrix[x][indexTemp1][indexTemp2] == -1)
								finalDisagr[k] = finalDisagr[k] + Main.WEIGHT_DEP;
						}
					}
				}
			}
			}
		
		//disagree for eli
		for(int k=0; k<getSize.populationSIZE+1; k++){
		//	finalDisagr[k] = 0;
			
			for(int i=0; i<getSize.populationSIZE-1; i++){
				for(int j=i+1; j<getSize.populationSIZE; j++){
					indexTemp1 = Integer.parseInt(Prio_Final[k][i].substring(2,5))-1;
					indexTemp2 = Integer.parseInt(Prio_Final[k][j].substring(2,5))-1;
					
					if(Algorithm.eliCitedMatrix[indexTemp1][indexTemp2] == -1)
						finalDisagr[k] = finalDisagr[k] + Main.WEIGHT_ELI;
				}
			}
		}
		
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEli.txt";
		bw = new BufferedWriter(new FileWriter(filepath, true));
		int finalSumEli=0;

		for(int i=0; i<getSize.populationSIZE+1; i++){
			finalSumEli = finalSumEli + finalDisagr[i];
			bw.write(finalDisagr[i] + "\t");
		}

		bw.flush();
		bw.close();
	}//end while
	}	
}