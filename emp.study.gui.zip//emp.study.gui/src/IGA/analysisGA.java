package IGA;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;

public class analysisGA{
	public String[][] Prio_Eli = new String[Main.TotRunNumber][Main.NUM_REQ];
	public FileInputStream Fstream = null;
	public DataInputStream IN = null;
	public BufferedReader BR = null;
	public int indexPrio1, indexStd1, indexPrio2, indexStd2;
	
	//disAgreement for the gold-standard
	public void disAgreementEliOrder(String x1) throws IOException{
		String[] goldSTD = new String[Main.NUM_REQ];
		String prepath = mainGUI.InPath;
		String postpath = "/oth/eliOrd.txt";
		String filepath = prepath + x1 + postpath;
		Fstream = new FileInputStream(filepath);
		IN = new DataInputStream(Fstream);
		BR = new BufferedReader(new InputStreamReader(IN));
		String strLine="";
		while ((strLine = BR.readLine()) != null){		
			String[] tempeli = new String[Main.NUM_REQ];
			tempeli = strLine.split(" ");
			for(int i=0; i<tempeli.length; i++)
				goldSTD[i] = tempeli[i];
		}
}	
}