/**
 * 
 */
package IGA;

import java.util.Random;

/**
 * @author Francis Palma
 *
 */
public class samplePopTournamentSelect{

	public void tournamentSelection(){	
		System.out.println("Starting selection process (Binary Tournament Selection) for IGA...");
		//normalizing the value
		int randD1, randD2, dis1, dis2;
		String[][] tmp = new String[Main.NUM_REQ+1][Main.NUM_REQ];
		
		Random randomGenerator = new Random();
		for(int i=0; i<getSize.populationSIZE+1; i++){
				randD1 = randomGenerator.nextInt(getSize.populationSIZE+1);
				randD2 = randomGenerator.nextInt(getSize.populationSIZE+1);
				
				dis1 = disAgreementCalc.disagreement[randD1];
				dis2 = disAgreementCalc.disagreement[randD2];
				
				if(dis1 < dis2)	{
					for(int j=0; j<getSize.populationSIZE; j++)
						tmp[i][j] = Algorithm.Prio[randD1][j];
				}
				else{
					for(int j=0; j<getSize.populationSIZE; j++)
						tmp[i][j] = Algorithm.Prio[randD2][j];
				}
		}
		
		for(int x=0; x<getSize.populationSIZE+1; x++){
			for(int y=0; y<getSize.populationSIZE; y++){
				Algorithm.Prio[x][y] = tmp[x][y];
			}
		}
	}
}
