package IGA;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;


public class getPriority{
	public static int index;
	public static String[][] listNodes = new String[mainGUI.TOTPRIO][Main.NUM_REQ];
	public static int[][] nodesPriority = new int[mainGUI.TOTPRIO][Main.NUM_REQ];
	public static String[][] listReq = new String[mainGUI.TOTPRIO][Main.NUM_REQ];
	
	public void getPriorityArray(String x1) throws NumberFormatException, IOException{
	System.out.println("Getting requirements' priority infos...");
	String prepath = mainGUI.InPath;
	String postpath = "/prio/";
	for(int x=0; x<mainGUI.TOTPRIO; x++){
		
		String filepath = prepath + x1 + postpath + Main.PRIOFILEs.get(x);
		FileInputStream Fstream = new FileInputStream(filepath);
		DataInputStream IN = new DataInputStream(Fstream);
		BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
		//reading each nodes with the priority and storing in the corresponding array
		int index = 0;
		String strLine;
		while ((strLine = BR.readLine()) != null){
			String[] temp = new String[4];
			temp = strLine.split("\t");
			listNodes[x][index] = temp[0];
			nodesPriority[x][index] = Integer.parseInt(temp[1]);
			listReq[x][index] = temp[2];
			index++;
		}
		Fstream.close(); IN.close(); BR.close();
	}
	System.out.println("Finished restoring requirements' priority infos...");
	}
}