package IGA;
import java.io.File;

import pack.gui.mainGUI;


public class clearIGAFiles {

	public clearIGAFiles() {}
	
	public void deleteFiles(){
		System.out.println("Clearing all previous files for IGA...");
		String filepath = mainGUI.OutPath + "iga/analysis/disAgreementAVG.txt";
		File file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgreementMIN.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgreementMINrow.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgreementSTDV.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgreementSummary.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliAVG.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliMIN.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliMINrow.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliSTDV.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliSummary.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrGoldSTDAVG.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrGoldSTDMIN.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrGoldSTDMINrow.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrGoldSTDSTDV.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/populationtemp.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/population.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/eliPairNo.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/eliGraph.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrGoldSTD.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEli.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgreement.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		filepath = mainGUI.OutPath + "iga/analysis/disAgrGoldSSummary.txt";
		file = new File(filepath);
		if(file.exists())
			file.delete();
		
	}

}
