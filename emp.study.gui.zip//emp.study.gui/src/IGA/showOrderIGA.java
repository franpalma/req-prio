package IGA;

import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextArea;

import pack.gui.mainGUI;
/**
 * @author Francis
 *
 */
public class showOrderIGA extends JDialog{
	public showOrderIGA(JFrame parent) throws IOException {
		super(parent);
		String prepath = mainGUI.PROJECT_PATH;
		String postpath = "out/iga/results/finalorder_iga.out";
		String filepath = prepath + postpath;
		FileInputStream Fstream = new FileInputStream(filepath);
		DataInputStream IN = new DataInputStream(Fstream);
		BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
		String strLine = "";
		String file = "Orders are in User's Elicited Preferences:\n";
		while((strLine = BR.readLine()) != null){
			file += "\n";
			file += strLine;
		}
		BR.close(); IN.close();Fstream.close();
		JTextArea area = new JTextArea();
		area.setPreferredSize(new Dimension(860, 680));
		area.setText(file);
		area.setEditable(false);
		area.setLineWrap(true);
		this.getContentPane().add(area);
		this.setTitle("Final Ordering...");
		this.setLocation(0, 0);
		int windowWidth = 880; int windowHeight = 700;
		this.setSize(windowWidth, windowHeight);
		Point center = GraphicsEnvironment.getLocalGraphicsEnvironment().getCenterPoint();
		this.setBounds(center.x - windowWidth / 2, center.y - windowHeight / 2, windowWidth, windowHeight);
		this.setVisible(true);
	}
	public static void showFinalOrder() throws HeadlessException, IOException{
		System.out.println("Printing final order for IGA...");
		final JFrame frame1 = new JFrame("Final Ordering...");
		new showOrderIGA(frame1);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}