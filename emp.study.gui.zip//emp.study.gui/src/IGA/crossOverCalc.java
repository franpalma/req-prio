package IGA;
import java.util.Random;

public class crossOverCalc{

	public crossOverCalc(){	}
	
	public void performCrossOver(){
		System.out.println("Applying Crossover operator for IGA...");
		String[] P_i = new String[getSize.populationSIZE];
		String[] P_iplus1 = new String[getSize.populationSIZE];
		
		for(int i=0; i< getSize.populationSIZE; i++){
			Random randomGenerator = new Random();
			int cutpoint = randomGenerator.nextInt(getSize.populationSIZE);
			for(int x=0; x<getSize.populationSIZE; x++)	{
				P_i[x] = Algorithm.Prio[i][x];
				P_iplus1[x] = Algorithm.Prio[i+1][x];
			}				
			for(int j=0; j<cutpoint; j++)	{
				for(int l=0; l<getSize.populationSIZE; l++)	{
				
					if(P_i[j].equals(P_iplus1[l]))
						P_iplus1[l] = "NA";
				}
			}
			for(int j=cutpoint; j<getSize.populationSIZE; j++)	{
				for(int k=0; k<getSize.populationSIZE; k++)	{
					if(P_iplus1[k] != null){
					if(P_iplus1[k].equals("NA"))
						continue;}
					else{
						P_i[j] = P_iplus1[k];
						P_iplus1[k] = "NA";
						break;
					}
				}
			}
			for(int x=0; x<getSize.populationSIZE; x++)
				Algorithm.Prio[i][x] = P_i[x];				
		}
	}
}
