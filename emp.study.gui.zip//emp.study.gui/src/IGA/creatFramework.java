package IGA;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import pack.gui.mainGUI;

public class creatFramework {
	
	public static String[] goldStandard = new String[Main.NUM_REQ];
	
	public void creatFrameworkMethod(String x1) throws IOException{
		System.out.println("Creating final framework for IGA...");
	if(mainGUI.GSFLAG == 1){
		String strLine;
		//edit distance...
		List<String> eliOrder = new ArrayList<String>();
		String prepath = mainGUI.InPath;
		String postpath = "/oth/eliOrd.txt";
		String filepath = prepath + x1 + postpath;	
		FileInputStream Fstream = new FileInputStream(filepath);
		DataInputStream IN = new DataInputStream(Fstream);
		BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
		
		while ((strLine = BR.readLine()) != null){
			goldStandard = strLine.split(" ");
			for(int i=0; i<goldStandard.length; i++)
				eliOrder.add(goldStandard[i]);
		}
	}
		//reading IGA individuals
		//calculating edit distance for IGA
		for(int i=0; i<Main.TotRunNumber; i++){
			List<String> indivMin = new ArrayList<String>();
			String temp[] = new String[Main.NUM_REQ];
			temp = mainFrame.individual[i].split(" ");
			for(int j=0; j<temp.length; j++)
				indivMin.add(temp[j]);
			indivMin.clear();
		}
		if(mainGUI.GSFLAG == 1){
		averageDistance aD = new averageDistance();
		aD.calculateAverageDistance();}
		
		FileWriter fstream = new FileWriter(mainGUI.OutPath+"iga/results/iga_framework.out",true);
		BufferedWriter out = new BufferedWriter(fstream);
		if(mainGUI.GSFLAG == 1){
		out.write("\n");
		out.write(">GOLD STANDARD<");
		out.write("\n\n");
		for(int i=0; i<goldStandard.length;i++)
			out.write(goldStandard[i] + " ");
		out.write("\n\n");
		}
		out.write("\n");
		out.write("Pairs decided by the user: \n");
		for(int i=0; i<Algorithm.eliOrderedPair.length; i++){
			if(Algorithm.eliOrderedPair[i] != null){
				out.write(Algorithm.eliOrderedPair[i]);
			}
			out.write("\n");
		}
		out.write("\n\n");
		out.write(">INTERACTIVE GENETIC PRIORITIZATION<");
		out.write("\n\n");
		for(int i=0; i<Main.TotRunNumber; i++){
			out.write(mainFrame.individual[i]+"\t"+"[AD_GS "+averageDistance.avgDistIGA[i]+" ]"+"\t"+"[DIS_GS "+mainFrame.disagree_GS[i]+" ]");
			out.write("\n");
		}
		out.write("\n");
		out.write(">PRIORITIZATION FRAMEWORK<");
		out.write("\n\n");
	if(mainGUI.GSFLAG == 1){
		out.write("[AD_IGA]"+"\t"+"[DIS_IGA]");
		out.write("\n");
		for(int i=0; i<Main.TotRunNumber; i++){
			out.write(averageDistance.avgDistIGA[i]+"\t"+mainFrame.disagree_GS[i]);
			out.write("\n");
		}
		out.write("\n");
		out.write("Error pairs (wrongly decided by the user):\n");
		for(int i=0; i<Algorithm.errorPair; i++){
			if(Algorithm.errorEli[i] != null){
				out.write(Algorithm.errorEli[i]+"\n");
			}
		}
	}
		out.write("\n");
		int temp = Algorithm.elicitedPairs;
		out.write("\nTotal pairs elicited by the user: " + temp);
		out.write("\n");
	if(mainGUI.GSFLAG == 1){
		temp = Algorithm.errorPair;
		out.write("Number of pairs elicited wrongly by the user: " + temp);
		out.write("\n");
		float tmp = (float)((float)(Algorithm.errorPair * 100.00)/Algorithm.elicitedPairs);
		out.write("Percentage/probability of user error: " + tmp);
		out.write("\n");
	}
		out.write("\n");
		out.write("Total Prioritization time: " + Main.TOTAL_PRIO_TIME + "s" + "\n");
		out.write("Total duration of elicitation session: " + Main.TOTAL_ELI_TIME + "s" + "\n");
		out.write("Minimum elicitation time for a pair: " + Main.MIN_ELI_TIME + "s" + "\n");
		out.write("Maximum elicitation time for a pair: " + Main.MAX_ELI_TIME + "s" + "\n");
		out.write("Average elicitation time for all pairs: " + Main.AVG_ELI_TIME + "s" + "\n");
		out.write("\n");
		out.write("\n");
		out.write("FBK IRST, CIT!!!");
		out.flush();
		out.close();
		
		FileWriter fstream1 = new FileWriter(mainGUI.OutPath+"iga/results/finalorder_iga.out");
		BufferedWriter out1 = new BufferedWriter(fstream1);
		String tmpstr[] = new String[Main.NUM_REQ];
		for(int k=0; k<mainFrame.individual.length; k++){
			tmpstr = mainFrame.individual[k].split(" ");
			for(int i=0; i<tmpstr.length; i++){
				if(tmpstr[i] != null){
					for(int j=0; j<Main.NUM_REQ; j++){
						if(getPriority.listNodes[0][j].equalsIgnoreCase(tmpstr[i])){
							out1.write(Integer.toString(i+1) + ": "+tmpstr[i] + " {" + getPriority.listReq[0][j] +"}\n");
						}
					}
				}
			}
		}
		out1.flush();
		out1.close();
		if(mainGUI.GSFLAG == 1){
		FileWriter fstream2 = new FileWriter(mainGUI.OutPath+"iga/results/eli_iga.out");
		BufferedWriter out2 = new BufferedWriter(fstream2);
		out2.write("Elicited pair" + "\t" + "Wrong???"+ "\t"+ "Eli_Time(in Sec)"+ "\t"+ "Cumulative_Eli_Time(in Sec)"+ "\n");
		for(int i=0; i<Algorithm.elicitedPairs; i++){
			String flag = null;
			if(Algorithm.eliOrderFlag[i] == 1)
				flag = "yes";
			else if(Algorithm.eliOrderFlag[i] == 0)
				flag = "no";
			out2.write(Algorithm.eliOrderedPair[i] + "\t\t" + flag+ "\t\t\t"+ Algorithm.ELI_INDV_TIME[i] + "\t\t\t\t\t"+ Algorithm.ELI_CUMUL_TIME_SUM[i]+ "\n");
		}
		
		out2.write("\n\nSession details for the Elicited Pairs: \n\n");
		for(int i=0; i<Algorithm.maxElicitedPairs; i++){
			if(elicitPairs.ELI_SESSION[i][0] != null){
				out2.write("\nSession: "+ Integer.toString(i+1) + "\n");
				out2.write(elicitPairs.ELI_SESSION[i][0] + "\t\t" + elicitPairs.ELI_SESSION[i][1]+ "\n");
			}
		}
		out2.write("\n***{Pairs elicited in each session} [\\t] {Total time (in sec.) for that session}\n");
		out2.flush();
		out2.close();
		}
	}
}
