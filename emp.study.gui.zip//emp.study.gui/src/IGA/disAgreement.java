package IGA;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;


public class disAgreement {
	public void minDisAgreement() throws IOException{
		
		BufferedWriter bw = null;
		String filepath = mainGUI.OutPath + "iga/analysis/disAgreementSummary.txt";
		bw = new BufferedWriter(new FileWriter(filepath));
		filepath = mainGUI.OutPath + "iga/analysis/disAgreement.txt";		
		FileInputStream Fstream = new FileInputStream(filepath);
		DataInputStream IN = new DataInputStream(Fstream);
		BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
		String strLine;
		
		while ((strLine = BR.readLine()) != null){
			String[] temp0 = strLine.split("\t");
			int[] disAry = new int[temp0.length/Main.NUM_REQ];
			for(int j=0; j<temp0.length/Main.NUM_REQ; j++){
				int sum=0;
				for(int i=j*Main.NUM_REQ; i<j*Main.NUM_REQ+Main.NUM_REQ; i++)
					sum = sum +Integer.parseInt(temp0[i]);
				disAry[j] = sum/Main.NUM_REQ;
			}
			filepath = mainGUI.OutPath + "iga/analysis/disAgreementSummary.txt";
			bw = new BufferedWriter(new FileWriter(filepath,true));
			
			for(int i=0; i<disAry.length; i++){
				if(disAry[i] != 0)
				bw.write(disAry[i]+"\t");
			}
			bw.write("\n");
			bw.flush();
		}
		bw.close();
	}
}

