package IGA;

public class minDisAgree {

	public static int minDisagreementValue = 9999;
	public static int minDisAgIndex = 0;
	public minDisAgree() {
		// TODO Auto-generated constructor stub
	}

	public void minDisAgreement(){

		for(int k=0; k<getSize.populationSIZE+1; k++){	
			if(disAgreementCalc.disagreement[k]<minDisagreementValue){
				minDisagreementValue = disAgreementCalc.disagreement[k];
				minDisAgIndex = k;
			}
			else
				continue;	
		}
	}
}
