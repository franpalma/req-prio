package IGA;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;


public class disAgrGS {
	
	public String[][] Prio_Eli = new String[Main.TotRunNumber][Main.NUM_REQ];//[20]
	public FileInputStream Fstream = null;
	public DataInputStream IN = null;
	public BufferedReader BR = null;
	public int indexPrio1, indexStd1, indexPrio2, indexStd2;
	
	//disAgreement for the gold-standard
	public void disAgreementEliOrder(String x1) throws IOException{
		String[] goldSTD = new String[Main.NUM_REQ];
		String prepath = mainGUI.InPath;
		String postpath = "/oth/eliOrd.txt";
		String filepath = prepath + x1 + postpath;
		Fstream = new FileInputStream(filepath);
		IN = new DataInputStream(Fstream);
		BR = new BufferedReader(new InputStreamReader(IN));
		String strLine="";
	while ((strLine = BR.readLine()) != null){		
		String[] tempeli = new String[Main.NUM_REQ];
		tempeli = strLine.split(" ");
		for(int i=0; i<tempeli.length; i++)
			goldSTD[i] = tempeli[i];
	}
	
	for(int i =0; i<Main.TotRunNumber; i++){
		String[] temp = mainFrame.individual[i].split(" ");
		for(int j=0; j<temp.length; j++)
			Prio_Eli[i][j] = temp[j];
	}

	
	for(int k=0; k<Main.TotRunNumber; k++){
		mainFrame.disagree_GS[k] = 0;
		for(int i=0; i<Main.NUM_REQ-1; i++){
			for(int j=i+1; j<Main.NUM_REQ; j++){
				for(int t=0; t<Main.NUM_REQ; t++){
					if(Prio_Eli[k][i].toString().equals(goldSTD[t]))
							indexStd1 = t;
					if(Prio_Eli[k][j].toString().equals(goldSTD[t]))
							indexStd2 = t;
				}
				if(indexStd1 > indexStd2)
					mainFrame.disagree_GS[k] = mainFrame.disagree_GS[k] + 1;
			}
		}
	}
}	
}