package IGA;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import pack.gui.mainGUI;

public class elicitPairs extends JDialog implements ActionListener {
	private static int ELICITFLAG=-1, eliflag=0;
	public static String[][] ELI_SESSION = new String[mainGUI.MAX_ELI_PAIR][2];
	private static String[] eliOrder = new String[getSize.populationSIZE];
	private static int errorflag=0;
	//private JButton okbutton;
	//private JButton cnclbutton;
	private JButton okbutton;
	private JButton cnclbutton;
	private JButton donotknow;
	private JPanel jPanel1;// = new JPanel();
    private JPanel jPanel2;// = new JPanel();
    private JPanel jPanel3;// = new JPanel();
    private JSplitPane splitPane;
    private JSplitPane splitPane2;
	private JLabel priolabel1 = new JLabel("User Priority/Value ");
	private JLabel priolabel2 = new JLabel("User Priority/Value ");
	private JLabel deplabel1 = new JLabel("Depends on ");
	private JLabel deplabel2 = new JLabel("Depends on ");
	private JLabel deplabel11 = new JLabel("Depends on this.");
	private JLabel deplabel21 = new JLabel("Depends on this.");
	private JLabel reqDesc1 = new JLabel("Requirement text description ");
	private JLabel reqDesc2 = new JLabel("Requirement text description ");

	private JTextField priolabel1txt = new JTextField(null,10);
	private JTextField priolabel2txt = new JTextField(null,10);
	private JTextField deplabel1txt = new JTextField(null,30);
	private JTextField deplabel2txt = new JTextField(null,30);
	private JTextField deplabel11txt = new JTextField(null,30);
	private JTextField deplabel21txt = new JTextField(null,30);
	private JTextArea reqDesc1txt = new JTextArea();
	private JTextArea reqDesc2txt = new JTextArea();
	private JComponent j1;// = new JLabel(ax);
	private JComponent j2;// = new JLabel(bx);
	public static String ax, bx;
	
  public elicitPairs(JFrame parent, String str) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
    super(parent, str, true);
    JFrame.setDefaultLookAndFeelDecorated(true);
	JDialog.setDefaultLookAndFeelDecorated(true);
    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		jPanel1 = new JPanel();
		jPanel2 = new JPanel();
		jPanel3 = new JPanel();
		j1 = new JLabel(ax.toString(),SwingConstants.CENTER);
		Font f = new Font("Dialog", Font.PLAIN, 22);
		j1.setFont(f);
		j1.setBorder(BorderFactory.createTitledBorder(""));
		j2 = new JLabel(bx.toString(),SwingConstants.CENTER);
		j2.setBorder(BorderFactory.createTitledBorder(""));
		j2.setFont(f);
		splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true, jPanel1, jPanel2);
		splitPane.setDividerSize(3);
		splitPane.setDividerLocation(.5D);
		splitPane.setResizeWeight(.5D);
		//splitPane.setSize(this.WIDTH, this.HEIGHT/2);
		splitPane2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, jPanel3);
	    splitPane2.setDividerLocation(.5D);
	    splitPane2.setDividerSize(3);
	    splitPane2.setResizeWeight(.7D);
	    //splitPane2.setLayout(null);
		//splitPane.setOneTouchExpandable(true);
		getContentPane().add(splitPane2);
				
		jPanel1.setLayout(null);
		jPanel1.setOpaque(false);
		jPanel2.setLayout(null);
		jPanel2.setOpaque(false);
		jPanel3.setLayout(null);
		jPanel3.setOpaque(false);
		jPanel1.setBorder(BorderFactory.createRaisedBevelBorder());
		jPanel2.setBorder(BorderFactory.createRaisedBevelBorder());
		jPanel3.setBorder(BorderFactory.createRaisedBevelBorder());
		
		okbutton = new JButton();
		cnclbutton = new JButton();
		donotknow = new JButton();
		
		jPanel1.setLayout(null);
		jPanel1.setOpaque(false);
		jPanel2.setLayout(null);
		jPanel2.setOpaque(false);
		jPanel1.setBorder(BorderFactory.createRaisedBevelBorder());
		jPanel2.setBorder(BorderFactory.createRaisedBevelBorder());
	
		okbutton.setText(ax + " is More Important than " + bx);
		okbutton.addActionListener(this);
		okbutton.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e)
		{
			okbutton_actionPerformed(e);
		}
		});	
		cnclbutton.setText(bx + " is More Important than " + ax);
		cnclbutton.addActionListener(this);
		cnclbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				cnclbutton_actionPerformed(e);
			}
		});	
		donotknow.setText("Do not know... ");
		donotknow.addActionListener(this);
		donotknow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				donotknow_actionPerformed(e);
			}
		});
		
		int iax = Integer.parseInt(ax.substring(2, 5))-1;
		int axpriority=9999;
		String axdescription="";
		String ax_dep_on=""; String reqs_dep_on_ax="";
		for(int i=0; i<Main.NUM_REQ; i++){
			if(ax.equalsIgnoreCase(getPriority.listNodes[0][i])){
				axpriority = getPriority.nodesPriority[0][i];
				axdescription = getPriority.listReq[0][i];
			}
		}
		for(int i=0; i<Main.SEQ_REQ; i++){
			if(buildDependencyGraph.depndencyMatrix[0][iax][i] == 1){
				if(i<9)
					reqs_dep_on_ax = reqs_dep_on_ax.concat("RT00"+Integer.toString(i+1) + " ");
				else if(i>=9 && i<99)
					reqs_dep_on_ax = reqs_dep_on_ax.concat("RT0"+Integer.toString(i+1) + " ");
				else
					reqs_dep_on_ax = reqs_dep_on_ax.concat("RT"+Integer.toString(i+1) + " ");
			}
		}
		for(int i=0; i<Main.SEQ_REQ; i++){
			if(buildDependencyGraph.depndencyMatrix[0][i][iax] == 1){
				if(i<9)
					ax_dep_on = ax_dep_on.concat("RT00"+Integer.toString(i+1) + " ");
				else if(i>=9 && i<99)
					ax_dep_on = ax_dep_on.concat("RT0"+Integer.toString(i+1) + " ");
				else
					ax_dep_on = ax_dep_on.concat("RT"+Integer.toString(i+1) + " ");
			}
		}
		
		addComponent(jPanel1, j1, 150,20,100,25);
		addComponent(jPanel1, priolabel1, 30,59,150,25);
		addComponent(jPanel1, deplabel1, 30,99,150,25);
		addComponent(jPanel1, deplabel11, 200,139,150,25);
		addComponent(jPanel1, reqDesc1, 30,179,200,25);
		addComponent(jPanel1, priolabel1txt, 200,59,150,25);
		addComponent(jPanel1, deplabel1txt, 200,99,150,25);
		addComponent(jPanel1, deplabel11txt, 30,139,150,25);
		addComponent(jPanel1, reqDesc1txt, 30,210,320,150);
		priolabel1txt.setText(Integer.toString(axpriority));
		deplabel1txt.setText(ax_dep_on);
		deplabel11txt.setText(reqs_dep_on_ax);
		reqDesc1txt.setText(axdescription);
		priolabel1txt.setEditable(false);
		deplabel1txt.setEditable(false);
		deplabel11txt.setEditable(false);
		reqDesc1txt.setEditable(false);
		reqDesc1txt.setLineWrap(true);
		
		int ibx = Integer.parseInt(bx.substring(2, 5))-1;
		int bxpriority=9999;
		String bxdescription="";
		String bx_dep_on=""; String reqs_dep_on_bx="";
		for(int i=0; i<Main.NUM_REQ; i++){
			if(bx.equalsIgnoreCase(getPriority.listNodes[0][i])){
				bxpriority = getPriority.nodesPriority[0][i];
				bxdescription = getPriority.listReq[0][i];
			}
		}
		for(int i=0; i<Main.SEQ_REQ; i++){
			if(buildDependencyGraph.depndencyMatrix[0][ibx][i] == 1){
				if(i<9)
					reqs_dep_on_bx = reqs_dep_on_bx.concat("RT00"+Integer.toString(i+1) + " ");
				else if(i>=9 && i<99)
					reqs_dep_on_bx = reqs_dep_on_bx.concat("RT0"+Integer.toString(i+1) + " ");
				else
					reqs_dep_on_bx = reqs_dep_on_bx.concat("RT"+Integer.toString(i+1) + " ");
			}
		}
		for(int i=0; i<Main.SEQ_REQ; i++){
			if(buildDependencyGraph.depndencyMatrix[0][i][ibx] == 1){
				if(i<9)
					bx_dep_on = bx_dep_on.concat("RT00"+Integer.toString(i+1) + " ");
				else if(i>=9 && i<99)
					bx_dep_on = bx_dep_on.concat("RT0"+Integer.toString(i+1) + " ");
				else
					bx_dep_on = bx_dep_on.concat("RT"+Integer.toString(i+1) + " ");
			}
		}

		addComponent(jPanel2, j2, 150,20,100,25);
		addComponent(jPanel2, priolabel2, 30,59,150,25);
		addComponent(jPanel2, deplabel2, 30,99,150,25);
		addComponent(jPanel2, deplabel21, 200,139,150,25);
		addComponent(jPanel2, reqDesc2, 30,179,200,25);
		addComponent(jPanel2, priolabel2txt, 200,59,150,25);
		addComponent(jPanel2, deplabel2txt, 200,99,150,25);
		addComponent(jPanel2, deplabel21txt, 30,139,150,25);
		addComponent(jPanel2, reqDesc2txt, 30,210,320,150);
		
		addComponent(jPanel3, okbutton, 80,60,250,40);
		addComponent(jPanel3, donotknow, 360,60,150,40);
		addComponent(jPanel3, cnclbutton, 560,60,250,40);
		
		priolabel2txt.setText(Integer.toString(bxpriority));
		deplabel2txt.setText(bx_dep_on);
		deplabel21txt.setText(reqs_dep_on_bx);
		reqDesc2txt.setText(bxdescription);
		priolabel2txt.setEditable(false);
		deplabel2txt.setEditable(false);
		deplabel21txt.setEditable(false);
		reqDesc2txt.setEditable(false);
		reqDesc2txt.setLineWrap(true);
		
		setTitle("Elicitation between " + elicitPairs.ax + " and " + elicitPairs.bx);
		//this.setAlwaysOnTop(true);
		setLocation(new Point(100, 50));
		setSize(new Dimension(880, 640));
		setVisible(true);
  }
  
	public void cnclbutton_actionPerformed(ActionEvent e) {
		ELICITFLAG=-1; errorflag=0;
		String src = null, dst = null;
		int iax = Integer.parseInt(ax.substring(2, 5))-1;
		int ibx = Integer.parseInt(bx.substring(2, 5))-1;
		Algorithm.eliOrderedPair[Algorithm.nn++] = bx+" "+ax;
		Algorithm.eliCitedMatrix[iax][ibx] = -1;
		Algorithm.eliCitedMatrix[ibx][iax] = 1;
		JOptionPane.showMessageDialog(null, "   Eliciting pair  [ "+bx+", "+ax+" ]   as   # " + Integer.toString(Algorithm.elicitedPairs+1) + "   ");
		ELICITFLAG=1;
		src  = bx; dst = ax;
		if(mainGUI.GSFLAG==1){
		if(ELICITFLAG == 1){
			int SRCindxGS = 0, DSTindxGS = 0;
			for(int j=0; j<Main.NUM_REQ; j++){
				String tmp = eliOrder[j];
				if(src.equalsIgnoreCase(tmp))
					SRCindxGS = j;
				if(dst.equalsIgnoreCase(tmp))
					DSTindxGS = j;
			}
			if(DSTindxGS < SRCindxGS){
				Algorithm.errorPair++;
				Algorithm.errorEli[Algorithm.errorPair-1] = src + " " + dst;
				errorflag = 1;
			}
		}}
		this.hide();
	}
	
	public void donotknow_actionPerformed(ActionEvent e) {
		ELICITFLAG=-1;
		JOptionPane.showMessageDialog(null, "No pairs was elicited...");
		ELICITFLAG=0;
		this.hide();
	}
	
	public void okbutton_actionPerformed(ActionEvent e) {
		ELICITFLAG=-1; errorflag=0;
		String src = null, dst = null;
		//UPDATE HERE THE ELICITED MATRIX...
		int iax = Integer.parseInt(ax.substring(2, 5))-1;
		int ibx = Integer.parseInt(bx.substring(2, 5))-1;

				Algorithm.eliOrderedPair[Algorithm.nn++] = ax+" "+bx;
				Algorithm.eliCitedMatrix[iax][ibx] = 1;
				Algorithm.eliCitedMatrix[ibx][iax] = -1;
				JOptionPane.showMessageDialog(null, "   Eliciting pair  [ "+ax+", "+bx+" ]   as   # " + Integer.toString(Algorithm.elicitedPairs+1) + "   ");
				ELICITFLAG=1;
				src  = ax; dst = bx;
				if(mainGUI.GSFLAG==1){
			//calculate user error here...if he did
			if(ELICITFLAG == 1){
				int SRCindxGS = 0, DSTindxGS = 0;
				for(int j=0; j<Main.NUM_REQ; j++){
					String tmp = eliOrder[j];
					if(src.equalsIgnoreCase(tmp))
						SRCindxGS = j;
					if(dst.equalsIgnoreCase(tmp))
						DSTindxGS = j;
				}
				if(DSTindxGS < SRCindxGS){
					Algorithm.errorPair++;
					Algorithm.errorEli[Algorithm.errorPair-1] = src + " " + dst;
					errorflag = 1;
				}
			}}
			this.hide();
		}
	public static void addComponent(Container container, Component c, int x, int y, int width, int height){
		c.setBounds(x, y, width, height);
		container.add(c);
	}
  
	
public static void doPairElicit(String x1) throws IOException, HeadlessException, ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
	System.out.println("Starting user elicitation session for IGA...");
		// reading GS from the file
		if(eliflag==0){
			JOptionPane.showMessageDialog(null, "Entering into Interactive session...         \n\nPress OK to continue...  \n\n"); eliflag=1;
		}
	if(mainGUI.GSFLAG==1){
        String prepath = mainGUI.InPath;
        String postpath = "/oth/eliOrd.txt";
        String filepath = prepath + x1 + postpath;
		FileInputStream Fstream5 = new FileInputStream(filepath);
		DataInputStream IN5 = new DataInputStream(Fstream5);
		BufferedReader BR5 = new BufferedReader(new InputStreamReader(IN5));
		String strLine="";
		while ((strLine = BR5.readLine()) != null){		
			String[] tempeli = new String[Main.NUM_REQ];
			tempeli = strLine.split(" ");
			for(int i=0; i<tempeli.length; i++)
				eliOrder[i] = tempeli[i];
		}
		BR5.close();
		IN5.close();
		Fstream5.close();
	}
		String a, c;
		int axindex, bxindex, axindex1 = -1, bxindex1 = -1;
		int topPopulationP = (int) (Main.topPopulationPerc * checkTies.tiesIndex);
		for(int i = 0; i<topPopulationP; i++){ //checkTies.tiesIndex
			for(int i1 = i+1; i1<topPopulationP+1; i1++){ //i1<checkTies.tiesIndex+1
				for(int j=0; j<getSize.populationSIZE-1; j++){
					for(int k=j+1; k<getSize.populationSIZE; k++){
						ax = Algorithm.Prio[i][j];
						bx = Algorithm.Prio[i][k];
						a = Algorithm.Prio[i][j] + " "+Algorithm.Prio[i][k];
						c = Algorithm.Prio[i][k] + " "+Algorithm.Prio[i][j];
						
						int flag=0;
						for(int x=0; x<Algorithm.eliOrderedPair.length; x++){
							if(Algorithm.eliOrderedPair[x] == null)
								break;
							if(ax.equalsIgnoreCase(Algorithm.eliOrderedPair[x]) || bx.equalsIgnoreCase(Algorithm.eliOrderedPair[x])){
								flag=1;
								break;
							}
						}
						if(flag == 1) 
							continue;
						
						axindex = j;
						bxindex = k;
						int flg1=0, flg2=0;
						for(int j1 = 0; j1< getSize.populationSIZE; j1++){
							if(ax.equalsIgnoreCase(Algorithm.Prio[i1][j1])){
								axindex1 = j1; flg1=1;}
							if(bx.equalsIgnoreCase(Algorithm.Prio[i1][j1])){
								bxindex1 = j1; flg2=1;}
							if(flg1==1 && flg2==1) 
								break;
						}
						int iax = Integer.parseInt(ax.substring(2, 5))-1;
						int ibx = Integer.parseInt(bx.substring(2, 5))-1;
						
						//if(((Main.pGraphFlag == 1 && Main.dGraphFlag == 1) &&((axindex < bxindex && axindex1 < bxindex1) || (axindex == axindex1 &&  bxindex == bxindex1)) || (buildPriorityGraph.adjacencyMatrix[iax][ibx] == 1 || buildDependencyGraph.depndencyMatrix[iax][ibx] == 1)) || ((Main.pGraphFlag == 0 && Main.dGraphFlag == 1) &&((axindex < bxindex && axindex1 < bxindex1) || (axindex == axindex1 &&  bxindex == bxindex1)) || buildDependencyGraph.depndencyMatrix[iax][ibx] == 1) || ((Main.pGraphFlag == 1 && Main.dGraphFlag == 0) &&((axindex < bxindex && axindex1 < bxindex1) || (axindex == axindex1 &&  bxindex == bxindex1)) || (buildPriorityGraph.adjacencyMatrix[iax][ibx] == 1)))
						//	continue;
						int tmpflag1 = 0;
						int tmpflag2 = 0;
						for(int y1=0; y1<mainGUI.TOTPRIO; y1++){
							if(Main.pGraphFlag == 1 &&((axindex < bxindex && axindex1 < bxindex1) || (axindex == axindex1 &&  bxindex == bxindex1)) || buildPriorityGraph.adjacencyMatrix[y1][iax][ibx] == 1)
								tmpflag1 = 1;
						}
						for(int y1=0; y1<mainGUI.TOTDEP; y1++){
							if(Main.dGraphFlag == 1 &&((axindex < bxindex && axindex1 < bxindex1) || (axindex == axindex1 &&  bxindex == bxindex1)) || buildDependencyGraph.depndencyMatrix[y1][iax][ibx] == 1)
								tmpflag2 = 1;
						}	
						if(tmpflag1 == 1 || tmpflag2 == 1)
							continue;
						else{
							int idx1 = Integer.parseInt(ax.substring(2, 5))-1;
							int idx2 = Integer.parseInt(bx.substring(2, 5))-1;
							int flagg = 1, flagl = 1;
							for(int xx=0; xx<mainGUI.TOTPRIO; xx++){
								if(buildPriorityGraph.adjacencyMatrix[xx][idx1][idx2] == 1 && Main.pGraphFlag == 1)
									flagl = 0;
								if(buildPriorityGraph.adjacencyMatrix[xx][idx2][idx1] == 1 && Main.pGraphFlag == 1)
									flagg = 0;
							}
							for(int xx=0; xx<mainGUI.TOTDEP; xx++){
								if(buildDependencyGraph.depndencyMatrix[xx][idx1][idx2] == 1 && Main.dGraphFlag == 1)
									flagl = 0;
								if(buildDependencyGraph.depndencyMatrix[xx][idx2][idx1] == 1 && Main.dGraphFlag == 1)
									flagg = 0;
							}
							//
							for(int x=0; x<Algorithm.nn; x++){
								if(Algorithm.eliOrderedPair[x] == null)
									continue;
								else{
									if(Algorithm.eliOrderedPair[x].equals(c) || Algorithm.eliOrderedPair[x].equals(a)){
										flagl = 0;
										break;
									}
								}
							}
							
							if(Algorithm.elicitedPairs < Algorithm.maxElicitedPairs && flagg==1 && flagl==1){
								ELICITFLAG=-1;
								Main.ELI_START_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
								String str = "Elicitation between " + ax + " and " + bx;
								Main.sb.append(ax + "-"+bx + "\t");
								new elicitPairs(new JFrame(), str);
								Main.ELI_END_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
								if(ELICITFLAG==1){
									Algorithm.elicitedPairs++;
									Algorithm.ELI_INDV_TIME[Algorithm.elicitedPairs-1] = Double.parseDouble((mainGUI.fmtObj.format(Main.ELI_END_TIME - Main.ELI_START_TIME)));
									if(Algorithm.elicitedPairs == 1)
										Algorithm.ELI_CUMUL_TIME_SUM[Algorithm.elicitedPairs-1] = Double.parseDouble((mainGUI.fmtObj.format(Algorithm.ELI_INDV_TIME[Algorithm.elicitedPairs-1])));
									else
										Algorithm.ELI_CUMUL_TIME_SUM[Algorithm.elicitedPairs-1] = Double.parseDouble((mainGUI.fmtObj.format(Algorithm.ELI_INDV_TIME[Algorithm.elicitedPairs-1]))) + Double.parseDouble((mainGUI.fmtObj.format(Algorithm.ELI_CUMUL_TIME_SUM[Algorithm.elicitedPairs-2])));
									if(errorflag == 1)
										Algorithm.eliOrderFlag[Algorithm.elicitedPairs-1] = 1;
									else
										Algorithm.eliOrderFlag[Algorithm.elicitedPairs-1] = 0;
									double tmp = Main.ELI_END_TIME - Main.ELI_START_TIME;
									if(tmp >= Main.MAX_ELI_TIME)
										Main.MAX_ELI_TIME = Double.parseDouble((mainGUI.fmtObj.format(tmp)));
									if(tmp <= Main.MIN_ELI_TIME)
										Main.MIN_ELI_TIME =Double.parseDouble((mainGUI.fmtObj.format(tmp)));
									Main.TOTAL_ELI_TIME = Main.TOTAL_ELI_TIME + (Main.ELI_END_TIME - Main.ELI_START_TIME);
									Main.AVG_ELI_TIME = Double.parseDouble((mainGUI.fmtObj.format(Main.TOTAL_ELI_TIME / Algorithm.elicitedPairs)));
								}
								
							}
						}
					}
				}
			}
		}
		System.out.println("Closing user elicitation session for IGA...");
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
	    setVisible(false);
	    dispose(); 
	}
}