package IGA;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;


public class disAgrElicitedOrder {
	
	public String[][] Prio_Eli = new String[Main.NUM_REQ+1][Main.NUM_REQ];
	public int[] eliDisagr = new int[Main.NUM_REQ+1];
	FileInputStream Fstream = null;
	DataInputStream IN = null;
	BufferedReader BR = null;
	//public int[] eliOrderFinalSum = new int[100000];
	public int indexPrio1, indexStd1, indexPrio2, indexStd2;
	
	//disAgreement for the gold-standard
	public void disAgreementEliOrder(String x1) throws IOException{
		String[] goldSTD = new String[getSize.populationSIZE];
		String prepath = mainGUI.InPath;
		String postpath = "/oth/eliOrd.txt";
		String filepath = prepath + x1 + postpath;
		Fstream = new FileInputStream(filepath);
		IN = new DataInputStream(Fstream);
		BR = new BufferedReader(new InputStreamReader(IN));
		String strLine="";
	while ((strLine = BR.readLine()) != null){		
		String[] tempeli = new String[Main.NUM_REQ];
		tempeli = strLine.split(" ");
		for(int i=0; i<tempeli.length; i++)
			goldSTD[i] = tempeli[i];
	}
	BR.close();
	IN.close();
	
	BufferedWriter bw = null;
	filepath = mainGUI.OutPath + "iga/analysis/disAgrGoldSTD.txt";
	bw = new BufferedWriter(new FileWriter(filepath, true));
	filepath = mainGUI.OutPath + "iga/analysis/populationtemp.txt";
	Fstream = new FileInputStream(filepath);
	IN = new DataInputStream(Fstream);
	BR = new BufferedReader(new InputStreamReader(IN));
	String strLin="";
	int n=0;
	int minGS=99999;
	while ((strLin = BR.readLine()) != null){
		int l=0;
		if(!strLin.equals("")){
			String[] temp = strLin.split(" ");
			if(temp.length == 1) 
				continue;
			for(int i=0; i<temp.length; i++)
				Prio_Eli[l][i] = temp[i];
			l++;
		while ((strLin = BR.readLine()) != null){
			if(strLin.equals(""))
				break;
			temp = strLin.split(" ");
			if(temp.length == 1) 
				continue;
			for(int i=0; i<temp.length; i++)
				Prio_Eli[l][i] = temp[i];
			l++;
		}
	}
	
	for(int k=0; k<getSize.populationSIZE+1; k++){
		eliDisagr[k] = 0;
		for(int i=0; i<getSize.populationSIZE-1; i++){
			for(int j=i+1; j<getSize.populationSIZE; j++){
				//indexPrio1 = Integer.parseInt(Prio_Eli[k][i].substring(2,5))-1;
				//indexPrio2 = Integer.parseInt(Prio_Eli[k][j].substring(2,5))-1;
				for(int t=0; t<getSize.populationSIZE; t++){
					if(Prio_Eli[k][i].toString().equals(goldSTD[t]))
							indexStd1 = t;
					if(Prio_Eli[k][j].toString().equals(goldSTD[t]))
							indexStd2 = t;
				}
				if(indexStd1 > indexStd2)
					eliDisagr[k] = eliDisagr[k] + 1; 
				
			}
		}
		if(eliDisagr[k] <= minGS)
			minGS = eliDisagr[k];
	}
	filepath = mainGUI.OutPath + "iga/analysis/disAgrGoldSTD.txt";
	bw = new BufferedWriter(new FileWriter(filepath, true));
	int finalSumEli=0;
	
	for(int i=0; i<getSize.populationSIZE+1; i++){
		finalSumEli = finalSumEli + eliDisagr[i];
		bw.write(eliDisagr[i] + "\t");
	}
	//eliOrderFinalSum[n] = finalSumEli;

			n++;
			bw.flush(); bw.close();
		}//end while
	}
}