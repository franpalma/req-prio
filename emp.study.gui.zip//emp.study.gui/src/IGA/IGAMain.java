package IGA;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.swing.UnsupportedLookAndFeelException;

import pack.gui.mainGUI;



public class IGAMain implements ActionListener{
	public static int IteratorIGA;
	public static String Run_Number[] = {"01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"};
	public static String RunNumber;
	public void subMain(String x1) throws IOException, ArrayIndexOutOfBoundsException, InterruptedException, InvocationTargetException, ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
		String filepath = mainGUI.OutPath+"iga/analysis/disAgreement.txt";
		BufferedWriter bw6 = new BufferedWriter(new FileWriter(filepath));
		bw6.close();
		filepath = mainGUI.OutPath+"iga/analysis/disAgrGoldSTD.txt";
		BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
		bw.close();

		for(IteratorIGA=0; IteratorIGA<Main.TotRunNumber; IteratorIGA++){
			RunNumber = Run_Number[IteratorIGA];
			Algorithm.percentDone = (int) Math.round(((Main.donePair * mainGUI.MAX_ELI_PAIR)+((Main.donePair * mainGUI.MAX_ELI_PAIR)%100))/100); //number of error pair
		
			getPriority gP = new getPriority();
			gP.getPriorityArray(x1);
		
		//constructing the adjacency matrix of the graph according to the priority order
			if(Main.pGraphFlag == 1){
				buildPriorityGraph buildGraph = new buildPriorityGraph();
				buildGraph.buildPrioGraph();
			}
		
		//getting dependency graph
			if(Main.dGraphFlag == 1){
				buildDependencyGraph buildDpGraph = new buildDependencyGraph();
				buildDpGraph.buildDepGraph(x1);
			}
		//1.
		
			Algorithm PR = new Algorithm();
			PR.prioritizationRequirement(x1);
		}
		
			findMindisAgreement minAgr = new findMindisAgreement();
			minAgr.minDisAgreement();
			
			finddisAgrGoldSTD minGldStd = new finddisAgrGoldSTD();
			minGldStd.minDisAgreementGoldSTD();
			
			findMindisAgrFinalEli minEli = new findMindisAgrFinalEli();
			minEli.minDisAgreementFinalEli();
			
			disAgreement dA = new disAgreement();
			dA.minDisAgreement();
			
			disAgrFinalEli dAF = new disAgrFinalEli();
			dAF.minDisAgreement();
			if(mainGUI.GSFLAG==1){
			disAgrGoldSTD dAG = new disAgrGoldSTD();
			dAG.minDisAgreement();
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}