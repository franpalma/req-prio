package IGA;

import pack.gui.mainGUI;

public class disAgreementCalc{
	public static int count=0;
	public static float disSum = (float) 0.0;
	public static int[] disagreement = new int[Main.NUM_REQ+1];
		
	public void disAgreementFind(){
		System.out.println("Calculating disagreement for initial constraints for IGA...");
		int indexTemp1, indexTemp2, n1=0, n2=0;
		for(int k=0; k<getSize.populationSIZE+1; k++)
			disagreement[k] = 0;
		//disagree for prios
		for(int x=0; x<mainGUI.TOTPRIO; x++){
		for(int k=0; k<getSize.populationSIZE+1; k++){
			//disagreement[k] = 0;
			for(int i=0; i<getSize.populationSIZE-1; i++){
				for(int j=i+1; j<getSize.populationSIZE; j++){
					for(int f=0; f<Main.NUM_REQ; f++){
						if(Algorithm.Prio_New[k][i].equalsIgnoreCase(getPriority.listNodes[x][f]))
								n1 = f;
						if(Algorithm.Prio_New[k][j].equalsIgnoreCase(getPriority.listNodes[x][f]))
								n2 = f;						
					}
					indexTemp1 = Integer.parseInt(Algorithm.Prio_New[k][i].substring(2,5))-1;
					indexTemp2 = Integer.parseInt(Algorithm.Prio_New[k][j].substring(2,5))-1;
					if(Main.pGraphFlag == 1 && Main.dGraphFlag == 1){
						if((getPriority.nodesPriority[x][n1] > getPriority.nodesPriority[x][n2]))
							disagreement[k] = disagreement[k] + Main.WEIGHT_PRIO;
					}
					
					else if(Main.pGraphFlag == 1 && Main.dGraphFlag == 0){
						if((getPriority.nodesPriority[x][n1] > getPriority.nodesPriority[x][n2]))
							disagreement[k] = disagreement[k] + Main.WEIGHT_PRIO;
					}
				}
			}	
		}	
	}
		
		//disagree for deps
		for(int x=0; x<mainGUI.TOTDEP; x++){
		for(int k=0; k<getSize.populationSIZE+1; k++){
			//disagreement[k] = 0;
			for(int i=0; i<getSize.populationSIZE-1; i++){
				for(int j=i+1; j<getSize.populationSIZE; j++){
					indexTemp1 = Integer.parseInt(Algorithm.Prio_New[k][i].substring(2,5))-1;
					indexTemp2 = Integer.parseInt(Algorithm.Prio_New[k][j].substring(2,5))-1;
					if(Main.pGraphFlag == 1 && Main.dGraphFlag == 1){
						if(buildDependencyGraph.depndencyMatrix[x][indexTemp1][indexTemp2] == -1)
							disagreement[k] = disagreement[k] + Main.WEIGHT_DEP;
					}
					
					else if(Main.pGraphFlag == 0 && Main.dGraphFlag == 1){
						if(buildDependencyGraph.depndencyMatrix[x][indexTemp1][indexTemp2] == -1)
							disagreement[k] = disagreement[k] + Main.WEIGHT_DEP;
					}
				}
			}	
		}	
	}
		minDisAgree minDisAgr = new minDisAgree();
		minDisAgr.minDisAgreement();	
	}
}