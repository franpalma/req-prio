package IGA;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import pack.gui.mainGUI;

public class mainFrame {
	ArrayList<String> populationpr =  new ArrayList<String>();
	ArrayList<String> disagreementrun =  new ArrayList<String>();
	ArrayList<String> disagreementpr =  new ArrayList<String>();
	public static String[] individual = new String[Main.TotRunNumber];//[20]
	public static int[] disagree_GS = new int[Main.TotRunNumber]; //[20]
	int[] disagree_RD = new int[Main.TotRunNumber];//[20]
	String[][] mindisagree = new String[Main.TotRunNumber][2];//[20]
	public FileInputStream Fstream = null;
	public DataInputStream IN = null;
	public BufferedReader BR = null;
	public int index=0;
	
	public void framework() throws IOException, InterruptedException{
		System.out.println("Analysing all population data for IGA...");
	// read global min disagree file
		String filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEliMIN.txt";
		FileInputStream Fstream3 = new FileInputStream(filepath);
		DataInputStream IN3 = new DataInputStream(Fstream3);
		BufferedReader BR3 = new BufferedReader(new InputStreamReader(IN3));
		int last_len =0;
		long l=1;
		String strLin = "";
		while ((strLin = BR3.readLine()) != null){
			if(strLin.equals(""))
					break;
				String[] temp = strLin.split("\t");
				
				for(int i=0; i<temp.length; i++){
					mindisagree[last_len][0] = "Run-"+ Long.toString(i+1);
					mindisagree[last_len][1] = temp[i];
					last_len++;
				}
				l++;		
		}
		BR3.close(); Fstream3.close(); IN3.close();
		
		// read population file
		filepath = mainGUI.OutPath + "iga/analysis/population.txt";
		Fstream = new FileInputStream(filepath);
		IN = new DataInputStream(Fstream);
		BR = new BufferedReader(new InputStreamReader(IN));
		//int temp0 = 0;
		l = 0;
		String temp2 = null;
		String strLin1;
		while ((strLin1 = BR.readLine()) != null){
			long flag=0;
			if(!strLin1.equals("")){
				if(strLin1.length() == 2){
					flag = 1;
				
					if(strLin1.equalsIgnoreCase(temp2)){
						findMinDisIndividual(strLin1);
						populationpr.clear();
					}
				}
								
				if(strLin1.equals(""))
					continue;

				if(strLin1.length() > 2){
					populationpr.add(strLin1);
					l++;
				}
			}
			if(flag == 1)
				temp2 = strLin1;
		}
		System.out.println("Finidhed analysing population data for IGA...");
	} //end method
	
	
	private void findMinDisIndividual(String temp1) throws IOException {
		String strLin="";
		// read min disagree file
		String filepath = mainGUI.OutPath + "iga/analysis/disAgrFinalEli.txt";
		FileInputStream Fstream1 = new FileInputStream(filepath);
		DataInputStream IN1 = new DataInputStream(Fstream1);
		BufferedReader BR1 = new BufferedReader(new InputStreamReader(IN1));
		long last_len = 0;
	
		long lineNum = Integer.parseInt(temp1);
		long line=0;
		while ((strLin = BR1.readLine()) != null){
			if(strLin.equals(""))
				break;
			line++;
			if(line == lineNum){
				long run_no = Integer.parseInt(temp1);
				String[] temp = strLin.split("\t");
				for(int i=0; i<temp.length; i++){
					disagreementrun.add("Run-"+ run_no);
					disagreementpr.add(temp[i]);
					last_len++;
				}
		
				long flag=0;
				for(int i=0; i<mindisagree.length; i++){
					for(int j=0; j<populationpr.size(); j++){
						if(mindisagree[i][0].equalsIgnoreCase(disagreementrun.get(j).toString()) && Integer.parseInt(mindisagree[i][1]) == Integer.parseInt(disagreementpr.get(j).toString())){
							individual[index++] = populationpr.get(j);
							flag=1;
							break;
						}
					}
					if(flag == 1){
						disagreementrun.clear();
						disagreementpr.clear();
						BR1.close(); Fstream1.close(); IN1.close();
						break;
					}
				}
				break;
			}
		}
	}
}
