package IGA;

import java.io.IOException;

public class averageDistance {
	public static float[] avgDistIGA = new float[Main.TotRunNumber];//[20]
	public int[][] avgDistIGAindv = new int[Main.TotRunNumber][Main.NUM_REQ];//[20]
	
	public void calculateAverageDistance() throws IOException{
		System.out.println("Calculating Average Distance (AD) for IGA...");
		//average distance for IGA......
		int indxIndvIGA, indxGSIGA = 0, indxDiffIGA, diffSumIGA=0;
		float avgDiffIGA = (float) 0.0;
		String tmpIGA;
		for(int i=0; i< Main.TotRunNumber; i++){
			String[] temp = mainFrame.individual[i].split(" ");
			diffSumIGA = 0;
			for(int j=0; j<Main.NUM_REQ; j++){
				tmpIGA = temp[j];
				indxIndvIGA = j;
				for(int k=0; k<Main.NUM_REQ; k++){
					if(tmpIGA.equalsIgnoreCase(creatFramework.goldStandard[k]))
						indxGSIGA = k;
				}
				if(indxIndvIGA < indxGSIGA)
					indxDiffIGA = indxGSIGA - indxIndvIGA;
				else
					indxDiffIGA = indxIndvIGA - indxGSIGA;
				avgDistIGAindv[i][indxDiffIGA] = avgDistIGAindv[i][indxDiffIGA] + 1;
				diffSumIGA = diffSumIGA + indxDiffIGA;
			}
			avgDiffIGA = (float) diffSumIGA/Main.NUM_REQ;
			avgDistIGA[i] = (float) avgDiffIGA;			
		}
		System.out.println("Finished calculating Average Distance (AD) for IGA...");
	}
}