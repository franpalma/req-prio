/****************************************************************/
/*                      mainGUI	                            */
/*                                                              */
/****************************************************************/
package pack.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.DecimalFormat;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import smt.prio.SMTMain;
import smt.prio.showOrderSMT;
import IAHP.IAHP;
import IAHP.showOrderIAHP;
import IGA.Main;
import IGA.showOrderIGA;

public class mainGUI extends JDialog{
	public static DecimalFormat fmtObj = new DecimalFormat("####0.0000");
	public static int minV, maxV, TOTPRIO, TOTDEP, USER_PLATFORM, GSFLAG=1, MAX_ELI_PAIR;
	private static final long serialVersionUID = 1L;
	public static String PROJECT_PATH, InPath, OutPath, x1;
	//Variables declaration
	private JTabbedPane jTabbedPane1;
	private JPanel contentPane;
	//-----
	private JRadioButton igaRadioButton;
	private JRadioButton iahpRadioButton;
	private JRadioButton smtRadioButton;
	private JPanel jPanel1;
	private JPanel jPanel2;
	//-----
	private JRadioButton monScnRadioButton;
	private JRadioButton falScnRadioButton;
	private JRadioButton escScnRadioButton;
	private JRadioButton allScnRadioButton;
	private JRadioButton cusScnRadioButton;
	private JComboBox combo = new JComboBox();
	private JLabel label = new JLabel("Select User Platform: ");
	private JButton okButton;
	private JButton closeButton;
	private JButton open1File;
    private JCheckBox chkbox = new JCheckBox("Include Gold Standard (GS)");
	JTextField textField = new JTextField("---Show the project jar path here---", 70);
	JLabel textlabel = new JLabel("Project Path: ");
	private JButton showpath;
	//-----
	// End of variables declaration

	public mainGUI(Frame w1){
		super(w1);
		initializeComponent();
		this.setVisible(true);
	}

	private void initializeComponent(){
		combo.addItem("Linux/i686 (32bit)"); //index 0
		combo.addItem("Linux/x86_64 (64bit)"); //index 1
		combo.addItem("Mac OS X (Snow)Leopard (32bit)"); //index 2
		combo.addItem("Mac OS X (Snow)Leopard (64bit)"); //index 3
		combo.addItem("Mac OS X Tiger (32bit)"); //index 4
		combo.addItem("Mac OS X for PowerPC"); //index 5
		combo.addItem("Solaris"); //index 6
		combo.addItem("Windows"); //index 7
		combo.setSelectedItem(null);
		combo.setEnabled(false);
		combo.setBackground(Color.green);
		combo.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			USER_PLATFORM = combo.getSelectedIndex();
		   }
		});
		
		chkbox.setSelected(true);
		chkbox.setBorderPaintedFlat(true);
		chkbox.setContentAreaFilled(true);
		chkbox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(chkbox.isSelected() == true)
					GSFLAG = 1;
				else
					GSFLAG = 0;
			   }
			});
		jTabbedPane1 = new JTabbedPane();
		contentPane = (JPanel)this.getContentPane();
		//-----
		igaRadioButton = new JRadioButton();
		iahpRadioButton = new JRadioButton();
		smtRadioButton = new JRadioButton();
		jPanel1 = new JPanel();
		//-----
		monScnRadioButton = new JRadioButton();
		falScnRadioButton = new JRadioButton();
		escScnRadioButton = new JRadioButton();
		allScnRadioButton = new JRadioButton();
		cusScnRadioButton = new JRadioButton();
		okButton = new JButton();
		closeButton = new JButton();
		open1File = new JButton();
		showpath = new JButton();
		jPanel2 = new JPanel();
		//-----

		//
		// jTabbedPane1
		//
		jTabbedPane1.addTab("Select Algorithm", jPanel1);
		jTabbedPane1.addTab("Select Macro Scenario", jPanel2);
		jTabbedPane1.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e)
			{
				jTabbedPane1_stateChanged(e);
			}

		});
		//
		// contentPane
		//
		contentPane.setLayout(null);
		contentPane.setMaximumSize(new Dimension(720, 620));
		addComponent(contentPane, jTabbedPane1, 14,14,720,620);
		//
		// jRadioButton6
		//
		igaRadioButton.setText("Interactive Genetic Algorithm (IGA)");
		igaRadioButton.setFocusable(true);
		igaRadioButton.setMnemonic(KeyEvent.VK_G);
		igaRadioButton.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e)
			{
				jRadioButton6_itemStateChanged(e);
			}

		});
		//
		// jRadioButton7
		//
		iahpRadioButton.setText("Incomplete Analytical Hierarchy Process (IAHP)");
		iahpRadioButton.setMnemonic(KeyEvent.VK_H);
		iahpRadioButton.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e)
			{
				jRadioButton7_itemStateChanged(e);
			}

		});
		//
		// jRadioButton8
		//
		smtRadioButton.setText("Constraints Solver: Satisfiability Modulo Theories (SMT)");
		smtRadioButton.setMnemonic(KeyEvent.VK_M);
		smtRadioButton.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				jRadioButton8_itemStateChanged(e);
			}

		});
			
		//
		// jPanel1
		//
		jPanel1.setLayout(null);
		jPanel1.setOpaque(false);
		addComponent(jPanel1, igaRadioButton, 242,94,400,25);
		addComponent(jPanel1, iahpRadioButton, 240,138,400,25);
		addComponent(jPanel1, smtRadioButton, 239,182,400,25);
		addComponent(jPanel1, label, 90, 280, 120, 25);
		addComponent(jPanel1, combo, 240, 280, 200, 25);
		addComponent(jPanel1, textlabel, 90, 320, 110, 25);
		addComponent(jPanel1, textField, 240, 320, 350, 25);
		addComponent(jPanel1, showpath, 600, 320, 25, 25);
		
		addComponent(jPanel1, chkbox, 440, 400, 200, 25);
		//
		// jRadioButton9
		//
		monScnRadioButton.setText("Macro Scenario 1 (MON)");
		monScnRadioButton.setMnemonic(KeyEvent.VK_M);
		monScnRadioButton.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				jRadioButton9_itemStateChanged(e);
			}

		});
		//
		// jRadioButton10
		//
		falScnRadioButton.setText("Macro Scenario 2 (FAL)");
		falScnRadioButton.setMnemonic(KeyEvent.VK_F);
		falScnRadioButton.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				jRadioButton10_itemStateChanged(e);
			}

		});
		//
		// jRadioButton11
		//
		escScnRadioButton.setText("Macro Scenario 3 (ESC)");
		escScnRadioButton.setMnemonic(KeyEvent.VK_E);
		escScnRadioButton.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				jRadioButton11_itemStateChanged(e);
			}

		});
		//
		// jRadioButton12
		//
		allScnRadioButton.setText("Macro Scenario 4 (ALL)");
		allScnRadioButton.setMnemonic(KeyEvent.VK_A);
		allScnRadioButton.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e)
			{
				jRadioButton12_itemStateChanged(e);
			}

		});
		//
		// jRadioButton13
		//
		cusScnRadioButton.setText("Custom Scenario (CUS)");
		cusScnRadioButton.setMnemonic(KeyEvent.VK_U);
		cusScnRadioButton.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e)
			{
				jRadioButton13_itemStateChanged(e);
			}

		});
		//
		// jButton3
		//
		okButton.setText("Start");
		okButton.setMnemonic(KeyEvent.VK_S);
		okButton.setEnabled(false);
		okButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				try {
					jButton3_actionPerformed(e);
				} catch (IOException e1) {
					e1.printStackTrace();
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				} catch (ArrayIndexOutOfBoundsException e1) {
					e1.printStackTrace();
				} catch (InvocationTargetException e1) {
					e1.printStackTrace();
				} catch (HeadlessException e1) {
					
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					
					e1.printStackTrace();
				} catch (InstantiationException e1) {
					
					e1.printStackTrace();
				} catch (IllegalAccessException e1) {
					
					e1.printStackTrace();
				} catch (UnsupportedLookAndFeelException e1) {
					
					e1.printStackTrace();
				} catch (Throwable e1) {
					e1.printStackTrace();
				}
			}
		});
		//
		// jButton4
		//
		closeButton.setText("Close");
		closeButton.setMnemonic(KeyEvent.VK_C);
		closeButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				jButton4_actionPerformed(e);
			}

		});
		open1File.setText("Open 1 File");
		open1File.setMnemonic(KeyEvent.VK_O);
		open1File.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				try {
					jButton5_actionPerformed(e);
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
			}

		});
		showpath.setText("...");
		showpath.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				try {
					showpath_actionPerformed(e);
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
			}

		});
		//
		// jPanel2
		//
		jPanel2.setLayout(null);
		jPanel2.setBorder(BorderFactory.createRaisedBevelBorder());
		jPanel2.setOpaque(false);
		addComponent(jPanel2, monScnRadioButton, 90,59,250,25);
		addComponent(jPanel2, falScnRadioButton, 90,99,250,25);
		addComponent(jPanel2, escScnRadioButton, 90,139,250,25);
		addComponent(jPanel2, allScnRadioButton, 90,179,250,25);
		addComponent(jPanel2, cusScnRadioButton, 90,219,250,25);
		addComponent(jPanel2, okButton, 100,380,85,30);
		addComponent(jPanel2, closeButton, 220,380,85,30);
		addComponent(jPanel2, open1File, 350,380,110,30);

		//
		// mainGUI
		//
		this.setTitle("Interactive Requirements Prioritization...");
		this.setLocation(new Point(100, 50));
		//this.setAlwaysOnTop(true);
		this.setSize(new Dimension(880, 680));
		this.hide();
	}

	/** Add Component Without a Layout Manager (Absolute Positioning) */
	public static void addComponent(Container container,Component c,int x,int y,int width,int height){
		c.setBounds(x,y,width,height);
		container.add(c);
	}

	//
	private void jTabbedPane1_stateChanged(ChangeEvent e){
		//System.out.println("\njTabbedPane1_stateChanged(ChangeEvent e) called.");
	}

	private void jRadioButton6_itemStateChanged(ItemEvent e){
		if(e.getStateChange() == ItemEvent.SELECTED){
			iahpRadioButton.setSelected(false);
			smtRadioButton.setSelected(false);
			combo.setEnabled(false);
			if((monScnRadioButton.isSelected() == true || escScnRadioButton.isSelected() == true || falScnRadioButton.isSelected() == true || allScnRadioButton.isSelected() == true || cusScnRadioButton.isSelected() == true) && (textField.getText().contains("Show the project jar path here") == false)) 
				okButton.setEnabled(true);
		}			
	}

	private void jRadioButton7_itemStateChanged(ItemEvent e){
		if(e.getStateChange() == ItemEvent.SELECTED){
			igaRadioButton.setSelected(false);
			smtRadioButton.setSelected(false);
			combo.setEnabled(false);
			if((monScnRadioButton.isSelected() == true || escScnRadioButton.isSelected() == true || falScnRadioButton.isSelected() == true || allScnRadioButton.isSelected() == true || cusScnRadioButton.isSelected() == true) && (textField.getText().contains("Show the project jar path here") == false))
				okButton.setEnabled(true);
		}
	}

	private void jRadioButton8_itemStateChanged(ItemEvent e){
		if(e.getStateChange() == ItemEvent.SELECTED){
			igaRadioButton.setSelected(false);
			iahpRadioButton.setSelected(false);			
			combo.setEnabled(true);
			combo.setBackground(Color.BLUE);
			combo.setForeground(Color.BLUE);
			combo.setPopupVisible(true);
			if((monScnRadioButton.isSelected() == true || escScnRadioButton.isSelected() == true || falScnRadioButton.isSelected() == true || allScnRadioButton.isSelected() == true || cusScnRadioButton.isSelected() == true) && (combo.getSelectedIndex() >=0 && combo.getSelectedIndex() <= 7) && (textField.getText().contains("Show the project jar path here") == false))
				okButton.setEnabled(true);
		}
	}

	private void jRadioButton9_itemStateChanged(ItemEvent e){
		if(e.getStateChange() == ItemEvent.SELECTED){
			falScnRadioButton.setSelected(false);
			escScnRadioButton.setSelected(false);
			allScnRadioButton.setSelected(false);
			cusScnRadioButton.setSelected(false);
			if((igaRadioButton.isSelected() == true || iahpRadioButton.isSelected() == true || smtRadioButton.isSelected() == true) && (textField.getText().contains("Show the project jar path here") == false))
				okButton.setEnabled(true);
		}
	}

	private void jRadioButton10_itemStateChanged(ItemEvent e){
		if(e.getStateChange() == ItemEvent.SELECTED){
			monScnRadioButton.setSelected(false);
			escScnRadioButton.setSelected(false);
			allScnRadioButton.setSelected(false);
			cusScnRadioButton.setSelected(false);
			if((igaRadioButton.isSelected() == true || iahpRadioButton.isSelected() == true || smtRadioButton.isSelected() == true) && (textField.getText().contains("Show the project jar path here") == false))
				okButton.setEnabled(true);
		}
	}

	private void jRadioButton11_itemStateChanged(ItemEvent e){
		if(e.getStateChange() == ItemEvent.SELECTED){
			monScnRadioButton.setSelected(false);
			falScnRadioButton.setSelected(false);
			allScnRadioButton.setSelected(false);
			cusScnRadioButton.setSelected(false);
			if((igaRadioButton.isSelected() == true || iahpRadioButton.isSelected() == true || smtRadioButton.isSelected() == true) && (textField.getText().contains("Show the project jar path here") == false))
				okButton.setEnabled(true);
		}		
	}

	private void jRadioButton12_itemStateChanged(ItemEvent e){
	if(e.getStateChange() == ItemEvent.SELECTED){
		monScnRadioButton.setSelected(false);
		falScnRadioButton.setSelected(false);
		escScnRadioButton.setSelected(false);
		cusScnRadioButton.setSelected(false);
		if((igaRadioButton.isSelected() == true || iahpRadioButton.isSelected() == true || smtRadioButton.isSelected() == true) && (textField.getText().contains("Show the project jar path here") == false))
			okButton.setEnabled(true);
	}	
		//System.out.println("\njRadioButton12_itemStateChanged(ItemEvent e) called.");
		//System.out.println(">>" + ((e.getStateChange() == ItemEvent.SELECTED) ? "selected":"unselected"));
	}
	
	private void jRadioButton13_itemStateChanged(ItemEvent e){
	if(e.getStateChange() == ItemEvent.SELECTED){
		monScnRadioButton.setSelected(false);
		falScnRadioButton.setSelected(false);
		escScnRadioButton.setSelected(false);
		allScnRadioButton.setSelected(false);
		if((igaRadioButton.isSelected() == true || iahpRadioButton.isSelected() == true || smtRadioButton.isSelected() == true) && (combo.getSelectedIndex() >=0 && combo.getSelectedIndex() <= 7) && (textField.getText().contains("Show the project jar path here") == false))
			okButton.setEnabled(true);
	}	
	}
	
	private void jButton3_actionPerformed(ActionEvent e) throws Throwable{
		int response = JOptionPane.showConfirmDialog(null, "   Proceed to configure the Algorithm... ?   ");
		if(response == 0){
			PROJECT_PATH = textField.getText();
			InPath = PROJECT_PATH + "in/";
			OutPath = PROJECT_PATH + "out/";
			if(monScnRadioButton.isSelected() == true)
				x1 = "mon";
			else if(falScnRadioButton.isSelected() == true)
				x1 = "fal";
			else if(escScnRadioButton.isSelected() == true)
				x1 = "esc";
			else if(allScnRadioButton.isSelected() == true)
				x1 = "all";
			else if(cusScnRadioButton.isSelected() == true)
				x1 = "cus";
			else{
				JOptionPane.showInternalMessageDialog(null, " Please select a macro scenario...");
			}
			 
			if(PROJECT_PATH == "")
				JOptionPane.showMessageDialog(null, "Please provide the project path...");
			else{
				if(iahpRadioButton.isSelected() == true){
					minV = Integer.parseInt(JOptionPane.showInputDialog("Enter MIN-Scale Value: (default 1)","1"));
					maxV = Integer.parseInt(JOptionPane.showInputDialog("Enter MAX-Scale Value: (5 or 7 or 9)","9"));
				}
				int iga=0, iahp=0, smt=0;
				if(igaRadioButton.isSelected() == true)
					iga = 1;
				else if(iahpRadioButton.isSelected() == true)
					iahp = 1;
				else if(smtRadioButton.isSelected() == true)
					smt = 1;
				if(igaRadioButton.isSelected() == true && monScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					Main IGAMAIN = new Main();
					try {
						IGAMAIN.main(PROJECT_PATH + "iga.config.properties");
					} catch (ClassNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (InstantiationException e1) {
						
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						
						e1.printStackTrace();
					} catch (UnsupportedLookAndFeelException e1) {
						
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "   Running IGA Finished...!!!   ");
					showOrderIGA.showFinalOrder();
					igaRadioButton.setSelected(false); igaRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(igaRadioButton.isSelected() == true && falScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					Main IGAMAIN = new Main();
					try {
						IGAMAIN.main(PROJECT_PATH + "iga.config.properties");
					} catch (ClassNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (InstantiationException e1) {
						
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						
						e1.printStackTrace();
					} catch (UnsupportedLookAndFeelException e1) {
						
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "   Running IGA Finished...!!!   ");
					showOrderIGA.showFinalOrder();
					igaRadioButton.setSelected(false); igaRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(igaRadioButton.isSelected() == true && escScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					Main IGAMAIN = new Main();
					try {
						IGAMAIN.main(PROJECT_PATH + "iga.config.properties");
					} catch (ClassNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (InstantiationException e1) {
						
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						
						e1.printStackTrace();
					} catch (UnsupportedLookAndFeelException e1) {
						
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "   Running IGA Finished...!!!   ");
					showOrderIGA.showFinalOrder();
					igaRadioButton.setSelected(false); igaRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(igaRadioButton.isSelected() == true && allScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					Main IGAMAIN = new Main();
					try {
						IGAMAIN.main(PROJECT_PATH + "iga.config.properties");
					} catch (ClassNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (InstantiationException e1) {
						
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						
						e1.printStackTrace();
					} catch (UnsupportedLookAndFeelException e1) {
						
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "   Running IGA Finished...!!!   ");
					showOrderIGA.showFinalOrder();
					igaRadioButton.setSelected(false); igaRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(igaRadioButton.isSelected() == true && cusScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					Main IGAMAIN = new Main();
					try {
						IGAMAIN.main(PROJECT_PATH + "iga.config.properties");
					} catch (ClassNotFoundException e1) {
						
						e1.printStackTrace();
					} catch (InstantiationException e1) {
						
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						
						e1.printStackTrace();
					} catch (UnsupportedLookAndFeelException e1) {
						
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "   Running IGA Finished...!!!   ");
					showOrderIGA.showFinalOrder();
					igaRadioButton.setSelected(false); igaRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(iahpRadioButton.isSelected() == true && monScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					IAHP IAHPMAIN = new IAHP();
					IAHPMAIN.main(PROJECT_PATH + "iahp.config.properties", minV, maxV);
					JOptionPane.showMessageDialog(null, "   Running IAHP Finished...!!!   ");
					showOrderIAHP.showFinalOrder();
					iahpRadioButton.setSelected(false); iahpRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(iahpRadioButton.isSelected() == true && falScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					IAHP IAHPMAIN = new IAHP();
					IAHPMAIN.main(PROJECT_PATH + "iahp.config.properties", minV, maxV);
					JOptionPane.showMessageDialog(null, "   Running IAHP Finished...!!!   ");
					showOrderIAHP.showFinalOrder();
					iahpRadioButton.setSelected(false); iahpRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(iahpRadioButton.isSelected() == true && escScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					IAHP IAHPMAIN = new IAHP();
					IAHPMAIN.main(PROJECT_PATH + "iahp.config.properties", minV, maxV);
					JOptionPane.showMessageDialog(null, "   Running IAHP Finished...!!!   ");
					showOrderIAHP.showFinalOrder();
					iahpRadioButton.setSelected(false); iahpRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(iahpRadioButton.isSelected() == true && allScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					IAHP IAHPMAIN = new IAHP();
					IAHPMAIN.main(PROJECT_PATH + "iahp.config.properties", minV, maxV);
					JOptionPane.showMessageDialog(null, "   Running IAHP Finished...!!!   ");
					showOrderIAHP.showFinalOrder();
					iahpRadioButton.setSelected(false); iahpRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(iahpRadioButton.isSelected() == true && cusScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					IAHP IAHPMAIN = new IAHP();
					IAHPMAIN.main(PROJECT_PATH + "iahp.config.properties", minV, maxV);
					JOptionPane.showMessageDialog(null, "   Running IAHP Finished...!!!   ");
					showOrderIAHP.showFinalOrder();
					iahpRadioButton.setSelected(false); iahpRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				
				else if(smtRadioButton.isSelected() == true && monScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					SMTMain SMTMAIN = new SMTMain();
					SMTMAIN.main(PROJECT_PATH + "smt.config.properties");
					JOptionPane.showMessageDialog(null, "   Running SMT Finished...!!!   ");
					showOrderSMT.showFinalOrder();
					smtRadioButton.setSelected(false); smtRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(smtRadioButton.isSelected() == true && falScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					SMTMain SMTMAIN = new SMTMain();
					SMTMAIN.main(PROJECT_PATH + "smt.config.properties");
					JOptionPane.showMessageDialog(null, "   Running SMT Finished...!!!   ");
					showOrderSMT.showFinalOrder();
					smtRadioButton.setSelected(false); smtRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(smtRadioButton.isSelected() == true && escScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					SMTMain SMTMAIN = new SMTMain();
					SMTMAIN.main(PROJECT_PATH + "smt.config.properties");
					JOptionPane.showMessageDialog(null, "   Running SMT Finished...!!!   ");
					showOrderSMT.showFinalOrder();
					smtRadioButton.setSelected(false); smtRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(smtRadioButton.isSelected() == true && allScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					SMTMain SMTMAIN = new SMTMain();
					SMTMAIN.main(PROJECT_PATH + "smt.config.properties");
					JOptionPane.showMessageDialog(null, "   Running SMT Finished...!!!   ");
					showOrderSMT.showFinalOrder();
					smtRadioButton.setSelected(false); smtRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				else if(smtRadioButton.isSelected() == true && cusScnRadioButton.isSelected() == true){
					Configuration.UserConfigure(iga, iahp, smt);
					SMTMain SMTMAIN = new SMTMain();
					SMTMAIN.main(PROJECT_PATH + "smt.config.properties");
					JOptionPane.showMessageDialog(null, "   Running SMT Finished...!!!   ");
					showOrderSMT.showFinalOrder();
					smtRadioButton.setSelected(false); smtRadioButton.setEnabled(false);
					JOptionPane.showMessageDialog(null, "   You can close this window and proceed for another Prioritization Algorithm...   ");
				}
				
				System.out.println("Finished Interactive Requirements Prioritization...");
			}
			//System.exit(0);
		}
		if(smtRadioButton.isEnabled() == false && igaRadioButton.isEnabled() == false && iahpRadioButton.isEnabled() == false)
			this.hide();		
	}

	private void jButton4_actionPerformed(ActionEvent e){
		//System.out.println("\njButton4_actionPerformed(ActionEvent e) called.");
		this.hide();
	}
	
	private void jButton5_actionPerformed(ActionEvent e) throws FileNotFoundException{
		PROJECT_PATH = textField.getText();
		final JFileChooser fc = new JFileChooser();
		int returnVal = fc.showOpenDialog(this);
		File file1 = null;
		if (returnVal == JFileChooser.APPROVE_OPTION){
			file1 = fc.getSelectedFile();
		}
		Scanner fileStream = new Scanner(file1);
		String file = "";
		file += "File Name: " + file1.getName() + "\n";
		file += "File Full Path: " + file1.getPath() + "\n";
		while(fileStream.hasNextLine()){
			file += "\n";
			file += fileStream.nextLine();
		}
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("File Path: " + file1.getPath());
		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

		JTextArea area = new JTextArea();
		area.setPreferredSize(new Dimension(840, 700));
		area.setText(file);
		area.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(area, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setSize(840, 680);
		frame.add(area);
		frame.add(scrollPane);
		area.setLineWrap(true);
		frame.setSize(860, 720);
		frame.pack();
		frame.setVisible(true);	
	}
	
	private void showpath_actionPerformed(ActionEvent e) throws FileNotFoundException{
		final JFileChooser fc = new JFileChooser();
		int returnVal = fc.showOpenDialog(this);
		File file1 = null;
		if (returnVal == JFileChooser.APPROVE_OPTION){
			file1 = fc.getSelectedFile();
		}
		//String tmp = file1.getParent();
		String path = file1.getParent()+"/";//file1.getPath().substring(0, file1.getPath().length()-16);
		textField.setText(path);
		PROJECT_PATH = textField.getText();
	}

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
		System.out.println("Starting Interactive Requirements Prioritization...");
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
	    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		final JFrame frame1 = new JFrame("Interactive Requirements Prioritization...");
		final JButton btn = new JButton("Enter!");
		JButton btn1 = new JButton("Exit...");
		JPanel p = new JPanel();
		p.setLayout(null);
		
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				new mainGUI(frame1);
				btn.setEnabled(false);
			}});
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				System.exit(1);
			}});
		mainGUI.addComponent(p, btn, 150,140,85,30);
		mainGUI.addComponent(p, btn1, 150,180,85,30);
		p.add(btn);
		p.add(btn1);
		frame1.getContentPane().add(p);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.setSize(380,280);
		frame1.setLocation(450,200);
		frame1.setVisible(true);
		
	}
//= End of Testing =

}
