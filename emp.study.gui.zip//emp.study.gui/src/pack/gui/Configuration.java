/**
 * 
 */
package pack.gui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import smt.prio.SMTMain;
import IGA.Main;

/**
 * @author Francis
 *
 */
public class Configuration extends JDialog implements ActionListener{

	//Variables declaration
	//-----
	JLabel textlabelEli = new JLabel("Select Max Number of Elicited Pairs: ");
	private JComboBox comboEli = new JComboBox();
	JLabel textlabelGen = new JLabel("Select Total Number of Generations (for IGA only): ");
	private JComboBox comboGen = new JComboBox();
	JLabel textlabelPop = new JLabel("Select Population Size (for SMT only): ");
	private JComboBox comboPop = new JComboBox();
	private JCheckBox priority_graph_flag = new JCheckBox("Include the Priority Graphs, PRIOs: ");
	private JLabel priority_graph_flag1 = new JLabel("[tick = yes]  default 'yes'");
	private JCheckBox dependency_graph_flag = new JCheckBox("Include the Dependency Graphs, DEPs:");
	private JLabel dependency_graph_flag1 = new JLabel("[tick = yes]  default 'yes'");
	
	private JLabel weight_priority = new JLabel("         >   Weight for Prio: ");
	JTextField weight_priority1 = new JTextField("1", 10);
	private JLabel weight_priority2 = new JLabel("default '1'");
	
	private JLabel weight_dependency = new JLabel("         >   Weight for Dep: ");
	JTextField weight_dependency1 = new JTextField("1", 10);
	private JLabel weight_dependency2 = new JLabel("default '1'");
	
	private JLabel weight_elicited = new JLabel("         >   Weight for Eli: ");
	JTextField weight_elicited1 = new JTextField("1", 10);
	private JLabel weight_elicited2 = new JLabel("default '1'");
	
	private JLabel minimum_disagreement = new JLabel("         >   Threshold Disagreement (Min): ");
	JTextField minimum_disagreement1 = new JTextField("0", 10);
	private JLabel minimum_disagreement2 = new JLabel("default '0'");
	
	private JLabel percentage_population = new JLabel("         >   Top Population Percentage: ");
	JTextField percentage_population1 = new JTextField("0.20", 10);
	private JLabel percentage_population2 = new JLabel("default '0.20'");
	
	private JLabel total_run_number = new JLabel("         >   Total Number of Run: ");
	JTextField total_run_number1 = new JTextField("1", 10);
	private JLabel total_run_number2 = new JLabel("default '1'");
	
	JPanel contentPane;
	private JButton okButton;
	//-----
	// End of variables declaration

	public Configuration(Frame w1, String str, int iga, int iahp, int smt){
		super(w1, str, true);
		contentPane = new JPanel();
		priority_graph_flag.setSelected(true);
		dependency_graph_flag.setSelected(true);
		if(iga == 1){
			comboEli.setEnabled(true);
			comboGen.setEnabled(true);
			comboPop.setEnabled(false);
			priority_graph_flag.setEnabled(true);
			dependency_graph_flag.setEnabled(true);
			weight_priority1.setEditable(true);
			weight_dependency1.setEditable(true);
			weight_elicited1.setEditable(true);
			minimum_disagreement1.setEditable(true);
			percentage_population1.setEditable(true);
			total_run_number1.setEditable(true);
		}
		if(iahp == 1){
			comboEli.setEnabled(true);
			comboGen.setEnabled(false);
			comboPop.setEnabled(false);
			priority_graph_flag.setEnabled(false);
			dependency_graph_flag.setEnabled(false);
			weight_priority1.setEditable(false);
			weight_dependency1.setEditable(false);
			weight_elicited1.setEditable(false);
			minimum_disagreement1.setEditable(false);
			percentage_population1.setEditable(false);
			total_run_number1.setEditable(false);
		}
		if(smt == 1){
			comboPop.setEnabled(true);
			comboEli.setEnabled(true);
			comboGen.setEnabled(false);
			priority_graph_flag.setEnabled(false);
			dependency_graph_flag.setEnabled(false);
			weight_priority1.setEditable(false);
			weight_dependency1.setEditable(false);
			weight_elicited1.setEditable(false);
			minimum_disagreement1.setEditable(false);
			percentage_population1.setEditable(false);
			total_run_number1.setEditable(false);
		}
		comboEli.addItem("5"); //index 0
		comboEli.addItem("10"); //index 1
		comboEli.addItem("25"); //index 2
		comboEli.addItem("50"); //index 3
		comboEli.addItem("75"); //index 4
		comboEli.addItem("100"); //index 5
		comboEli.addItem("125"); //index 6
		comboEli.addItem("150"); //index 7
		comboEli.setSelectedItem(null);
		comboEli.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			okButton.setEnabled(true);
			mainGUI.MAX_ELI_PAIR = Integer.parseInt(comboEli.getSelectedItem().toString());
		   }
		});
		
		comboGen.addItem("100"); //index 0
		comboGen.addItem("200"); //index 1
		comboGen.addItem("500"); //index 2
		comboGen.addItem("1000"); //index 3
		comboGen.addItem("2000"); //index 4
		comboGen.setSelectedItem(null);
		if(iga == 1)
			comboGen.setEnabled(true);
		else
			comboGen.setEnabled(false);
		comboGen.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			Main.GENERATIONS = Integer.parseInt(comboGen.getSelectedItem().toString());
		   }
		});
		
		comboPop.addItem("5"); //index 0
		comboPop.addItem("10"); //index 1
		comboPop.addItem("20"); //index 2
		comboPop.addItem("30"); //index 3
		comboPop.addItem("50"); //index 4
		comboPop.setSelectedItem(null);
		if(smt == 1)
			comboPop.setEnabled(true);
		else
			comboPop.setEnabled(false);
		comboPop.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			SMTMain.MAX_SIZE = Integer.parseInt(comboPop.getSelectedItem().toString());
		   }
		});
		contentPane = (JPanel)this.getContentPane();
		okButton = new JButton();
		
	
		contentPane.setLayout(null);
		contentPane.setMaximumSize(new Dimension(640, 620));
		
		contentPane.setOpaque(false);
		addComponent(contentPane, textlabelEli, 50,50,200,25);
		addComponent(contentPane, comboEli, 300,50,80,25);
		addComponent(contentPane, textlabelGen, 50,90,250,25);
		addComponent(contentPane, comboGen, 300,90,80,25);
		addComponent(contentPane, textlabelPop, 50,130,200,25);
		addComponent(contentPane, comboPop, 300,130,80,25);
		addComponent(contentPane, priority_graph_flag, 45,180,250,25);
		addComponent(contentPane, priority_graph_flag1, 50,200,200,25);
		addComponent(contentPane, dependency_graph_flag, 45,220,250,25);
		addComponent(contentPane, dependency_graph_flag1, 50,240,200,25);
		
		addComponent(contentPane, weight_priority, 50,280,200,25);
		addComponent(contentPane, weight_priority1, 300,280,100,25);
		addComponent(contentPane, weight_priority2, 410,280,100,25);
		
		addComponent(contentPane, weight_dependency, 50,320,200,25);
		addComponent(contentPane, weight_dependency1, 300,320,100,25);
		addComponent(contentPane, weight_dependency2, 410,320,100,25);
		
		addComponent(contentPane, weight_elicited, 50,360,200,25);
		addComponent(contentPane, weight_elicited1, 300,360,100,25);
		addComponent(contentPane, weight_elicited2, 410,360,100,25);
		
		addComponent(contentPane, minimum_disagreement, 50,400,200,25);
		addComponent(contentPane, minimum_disagreement1, 300,400,100,25);
		addComponent(contentPane, minimum_disagreement2, 410,400,100,25);
		
		addComponent(contentPane, percentage_population, 50,440,200,25);
		addComponent(contentPane, percentage_population1, 300,440,100,25);
		addComponent(contentPane, percentage_population2, 410,440,100,25);
		
		addComponent(contentPane, total_run_number, 50,480,200,25);
		addComponent(contentPane, total_run_number1, 300,480,100,25);
		addComponent(contentPane, total_run_number2, 410,480,100,25);
		
		addComponent(contentPane, okButton, 260,535,90,30);
		
		okButton.setText(" DONE ");
		okButton.setMnemonic(KeyEvent.VK_D);
		okButton.setEnabled(false);
		okButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				try {
					jButton3_actionPerformed(e);
				} catch (IOException e1) {
					e1.printStackTrace();
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				} catch (ArrayIndexOutOfBoundsException e1) {
					e1.printStackTrace();
				} catch (InvocationTargetException e1) {
					e1.printStackTrace();
				} catch (HeadlessException e1) {
					
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					
					e1.printStackTrace();
				} catch (InstantiationException e1) {
					
					e1.printStackTrace();
				} catch (IllegalAccessException e1) {
					
					e1.printStackTrace();
				} catch (UnsupportedLookAndFeelException e1) {
					
					e1.printStackTrace();
				} catch (Throwable e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		
		//this.setUndecorated(true); 
		//this.getRootPane().setWindowDecorationStyle(JRootPane.NONE);  
		this.setTitle("   Parametric Configuration...   ");
		this.setLocation(new Point(80, 50));
		//this.setAlwaysOnTop(true);
		this.setSize(new Dimension(640, 620));
		this.hide();
		this.setVisible(true);
	}

	/** Add Component Without a Layout Manager (Absolute Positioning) */
	public static void addComponent(Container container,Component c,int x,int y,int width,int height){
		c.setBounds(x,y,width,height);
		container.add(c);
	}



	private void jButton3_actionPerformed(ActionEvent e) throws Throwable{
		if(priority_graph_flag.isSelected() == true)
			Main.pGraphFlag = 1;
		else
			Main.pGraphFlag = 0;
		if(dependency_graph_flag.isSelected() == true)
			Main.dGraphFlag = 1;
		else
			Main.dGraphFlag = 0;
		Main.WEIGHT_PRIO = Integer.parseInt(weight_priority1.getText());
		Main.WEIGHT_DEP = Integer.parseInt(weight_dependency1.getText());
		Main.WEIGHT_ELI = Integer.parseInt(weight_elicited1.getText());
		Main.TotRunNumber = Integer.parseInt(total_run_number1.getText());
		Main.threshholdDisagreement = Integer.parseInt(minimum_disagreement1.getText());
		Main.topPopulationPerc = Float.parseFloat(percentage_population1.getText());
		JOptionPane.showMessageDialog(null, "   Parameters are configured...   ");
		this.hide();
		
	}

	public static void UserConfigure(int iga, int iahp, int smt) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
		System.out.println("Configuring Algorithm...");
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
	    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		String str = "Parametric Configuration... ";
		new Configuration(new JFrame(), str, iga, iahp, smt);		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		setVisible(false);
	    dispose(); 		
	}
}
