package smt.prio;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

import pack.gui.mainGUI;

public class SMTMain {
	public static ArrayList<String> PRIOFILEs = new ArrayList<String>();
	public static ArrayList<String> DEPFILEs = new ArrayList<String>();
	static StringBuilder sb;
	public static double TOTAL_ELI_TIME=0, TOTAL_PRIO_TIME, START_TIME, END_TIME=0, ELI_START_TIME, ELI_END_TIME, MAX_ELI_TIME=0.0, MIN_ELI_TIME=9999, AVG_ELI_TIME;
	public static int ERROR_RATE, NUM_REQ, MAX_SIZE, SEQ_REQ;
	public void main(String string) throws Exception{
		
		System.out.println("Started Main module for SMT...");
		SMTMain.START_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
		//int y = MAX_SIZE = Integer.parseInt(configFile.getProperty("MAXSIZE"));
	
	//int v = totErrorPair = (maxElicitedPairs * ERROR_RATE)/100;
	String prepath = mainGUI.OutPath;
    String postpath = "/smt/results/smt.out";
	String filepath = prepath + postpath;
	BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
	bw.close();
	GetSize gS = new GetSize();
	int x = SEQ_REQ = NUM_REQ = gS.getPopulationSize(mainGUI.x1);
	int y = SMTMain.MAX_SIZE;
	int z = mainGUI.MAX_ELI_PAIR;
	//get prio count
	final File priofolder = new File(mainGUI.PROJECT_PATH+"in/"+mainGUI.x1+"/prio/");
	File[] priolistOfFiles = priofolder.listFiles();
	mainGUI.TOTPRIO = priolistOfFiles.length;
	for (int i = 0; i < priolistOfFiles.length; i++){
	    File fileEntry = priolistOfFiles[i];
	    if (!fileEntry.isDirectory()) {
	        PRIOFILEs.add(fileEntry.getName());
	    }
	}
	//get dep count
	final File depfolder = new File(mainGUI.PROJECT_PATH+"in/"+mainGUI.x1+"/dep/");
	File[] deplistOfFiles = depfolder.listFiles();
	mainGUI.TOTDEP = deplistOfFiles.length;
	for (int i = 0; i < deplistOfFiles.length; i++){
	    File fileEntry = deplistOfFiles[i];
	    if (!fileEntry.isDirectory()){
	        DEPFILEs.add(fileEntry.getName());
	    }
	}
	if(mainGUI.GSFLAG==1){
	GetGoldStandard getGS = new GetGoldStandard();
	getGS.getGoldStandard(x, y, z, mainGUI.x1);}

	GetPriority gP = new GetPriority();
	gP.getPriorityArray(x, y, z, mainGUI.x1);
	
	BuildPriorityGraph bPG = new BuildPriorityGraph();
	bPG.BuildPrioGraph();
	
	BuildDependencyGraph bDG = new BuildDependencyGraph();
	bDG.buildDepGraph(x, y, z, mainGUI.x1);
	
	AlgorithmSMT algo = new AlgorithmSMT();
	algo.methodAlgorithm(x, y, z, mainGUI.x1);
	
	//show results in a frame here...
	System.out.println("Finished Main module for SMT...");
}
}