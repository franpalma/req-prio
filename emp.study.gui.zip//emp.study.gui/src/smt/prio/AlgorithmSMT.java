package smt.prio;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import pack.gui.mainGUI;

public class AlgorithmSMT{
	public static double[] ELI_CUMUL_TIME_SUM = new double[mainGUI.MAX_ELI_PAIR];
	public static double[] ELI_INDV_TIME = new double[mainGUI.MAX_ELI_PAIR];
	public static int[] eliOrderFlag = new int[mainGUI.MAX_ELI_PAIR];
	public static String[][] reqOrders = new String[SMTMain.MAX_SIZE][SMTMain.NUM_REQ];
	public static String[][] reqOrdersFINAL = new String[SMTMain.MAX_SIZE][SMTMain.NUM_REQ];
	public static ArrayList<String> assertStrings = new ArrayList<String>();
	public static String[] errorEli = new String[mainGUI.MAX_ELI_PAIR];
	
	public 	static int solutionCounter=0, minDisagreement=9999, minDisagree=9999;
	public static int elicount=0, sizeA, lastDisagree, errorPair=0;
	public int minPosition;

public void methodAlgorithm(int x, int y, int z, String x1) throws Exception{
	int index=0;
	System.out.println("Starting main algorithm for SMT...");
	final int NUMREQ  = x;
	writeYicesFileInitCons yiceinit = new writeYicesFileInitCons();
	yiceinit.writeYicesFileINIT(x, y, z, x1);
	
	int maxElicitedPair = z;
	//writeSHFile wshell = new writeSHFile();
	//writeBatFile wbat = new writeBatFile();
	//wbat.writebatchfile();
	//("Linux/i686 (32bit)"); //index 0
	//("Linux/x86_64 (64bit)"); //index 1
	//("Mac OS X (Snow)Leopard (32bit)"); //index 2
	//("Mac OS X (Snow)Leopard (64bit)"); //index 3
	//("Mac OS X Tiger (32bit)"); //index 4
	//("Mac OS X for PowerPC"); //index 5
	//("Solaris"); //index 6
	//("Windows"); //index 7
	//Process process = null;
	String cmd = null, folder=null;
	Runtime run;
	if(mainGUI.USER_PLATFORM == 0)  		
		folder = "linux32bit/";
	else if(mainGUI.USER_PLATFORM == 1)  		
		folder = "linux64bit/";
	else if(mainGUI.USER_PLATFORM == 2)  		
		folder = "macleopard32/";
	else if(mainGUI.USER_PLATFORM == 3)  		
		folder = "macleopard64/";
	else if(mainGUI.USER_PLATFORM == 4)  		
		folder = "mactiger32/";
	else if(mainGUI.USER_PLATFORM == 5)  		
		folder = "macpowerpc/";
	else if(mainGUI.USER_PLATFORM == 6)  		
		folder = "solaris/";
	else if(mainGUI.USER_PLATFORM == 7)
		cmd = "cmd.exe /E:1900 /C " + mainGUI.PROJECT_PATH + "resources/yices/win/yices.exe " + mainGUI.OutPath + "smt/analysis/SMT.ys > " + mainGUI.OutPath + "smt/analysis/SMT.txt";
	else
		cmd = "cmd.exe /E:1900 /C " + mainGUI.PROJECT_PATH + "resources/yices/win/yices.exe " + mainGUI.OutPath + "smt/analysis/SMT.ys > " + mainGUI.OutPath + "smt/analysis/SMT.txt";
	
	Process process = null; int exitflag=0;
	while(ElicitPairs.elicitedPairs < maxElicitedPair && exitflag == 0){
		replaceString rep = new replaceString();
		int disagree;
		String prepath = mainGUI.OutPath;
		String postpath = "smt/analysis/SMT.txt";
		String fileToDel = prepath + postpath;
		File f = new File(fileToDel);
		if(f.exists())
			f.delete();	
		
		if(mainGUI.USER_PLATFORM >= 0 && mainGUI.USER_PLATFORM <= 6){
			String tmp = "chmod a+x " + mainGUI.PROJECT_PATH + "resources/yices/" + folder + "yices";
			String tmp1 = mainGUI.PROJECT_PATH + "resources/yices/" + folder + "./yices " + mainGUI.OutPath + "smt/analysis/SMT.ys" + " > " + mainGUI.OutPath + "smt/analysis/SMT.txt";
			String shcmd[] = {"/bin/bash", "-c",  tmp};
			String shcmd1[] = {"/bin/bash", "-c",  tmp1};
			process = Runtime.getRuntime().exec(shcmd);
			process.waitFor();
			process = Runtime.getRuntime().exec(shcmd1);
			process.waitFor();
		}
		else{
			run = Runtime.getRuntime();
			try{
				process = run.exec(cmd); }
			catch (Exception e) {}
			process.waitFor();
		}
		
		//get the sorted requirement order from SMT file here E:/EclipseCPP/workspace.
		String[] tmpFinalOrder = new String[NUMREQ]; int[] tmpFinalIndx = new int[NUMREQ];
		prepath = mainGUI.OutPath;
		postpath = "smt/analysis/SMT.txt";
		String filepath = prepath + postpath;
		FileInputStream Fstream = new FileInputStream(filepath);
		DataInputStream IN = new DataInputStream(Fstream);
		BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
		int foundPair = 0; String line;
		while ((line = BR.readLine()) != null){
			if(line.indexOf("(=") != -1){
				foundPair++;
				String req = line.substring(7, line.length());
				String search = ")"; String replace = "";
				req = rep.replaceAllString(req, search, replace);
				//req.replace(")","");
				String[] result = req.split(" ");
				for(int i=0; i<result.length;){
					String str = "RT";
					String REQ = str.concat(result[i].toString());
					i = i + 1;
					int post = Integer.parseInt(result[i]);
					i = i + 1;
					tmpFinalOrder[foundPair-1] = REQ;
					tmpFinalIndx[foundPair-1] = post;
				}
			}
			if(foundPair == SMTMain.NUM_REQ)
				break;
		}
		BR.close(); IN.close(); Fstream.close();

		for(int i=0; i<SMTMain.NUM_REQ-1; i++){
			for(int j=i+1; j<SMTMain.NUM_REQ; j++){
				if(tmpFinalIndx[i] > tmpFinalIndx[j]){
					int tmp = tmpFinalIndx[i];
					tmpFinalIndx[i] = tmpFinalIndx[j];
					tmpFinalIndx[j] = tmp;
					String str = tmpFinalOrder[i];
					tmpFinalOrder[i] = tmpFinalOrder[j];
					tmpFinalOrder[j] = str;
		}}}

		//capture ordering and cost
		prepath = mainGUI.OutPath;
		postpath = "/smt/analysis/SMT.txt";
		filepath = prepath + postpath;
		Fstream = new FileInputStream(filepath);
		IN = new DataInputStream(Fstream);
		BR = new BufferedReader(new InputStreamReader(IN));
		String mainString = "(assert ";
			String strMain = "";
			foundPair = 0;
			int costflag = 0;
				while((line = BR.readLine()) != null){
					if(foundPair == SMTMain.NUM_REQ && !line.contains("cost"))
						continue;
					if(line.contains("cost")){
						String dis = line.substring(6, line.length());
						disagree = Integer.parseInt(dis);
						lastDisagree = disagree;
						costflag = 1;

					if(minDisagreement > disagree)
						minDisagreement = disagree;
					}
					if (line.contains("sat"))
						continue;
					else{
						if(line.contains("(=") && (foundPair < SMTMain.NUM_REQ)){
							foundPair++;
							String search = "(="; String replace = "(/=";
							line = rep.replaceAllString(line, search, replace);
							//line.replaceFirst("(=", "(/=");
						}
						if(foundPair == 1)
							strMain = strMain.concat(line+" ");
						else{
							if((foundPair == SMTMain.NUM_REQ) && costflag == 0)
								strMain = strMain.concat(line+")");
							else if((foundPair < SMTMain.NUM_REQ) && costflag == 0)
								strMain = strMain.concat(line+") ");
						}
					}
					if(foundPair == SMTMain.NUM_REQ && costflag == 1)
						break;
		}
		BR.close(); IN.close(); Fstream.close();
		
		for(int i=0; i<SMTMain.NUM_REQ-1; i++)
			mainString = mainString.concat("(or ");
		mainString = mainString.concat(strMain+")");
		if(!assertStrings.contains(mainString.toString()) && strMain.length()>0 ){
			//replacing all "(/= (R "
			String search = "(/= (RT "; String replace = "";
			strMain = rep.replaceAllString(strMain, search, replace);
			//strMain.replace("(/= (RT ", "");
			//replacing all "))"
			search = "))"; replace = "";
			strMain = rep.replaceAllString(strMain, search, replace);
			//strMain.toString().replaceAll("))", "");
			//replacing all ")"
			search = ")"; replace = "";
			strMain = rep.replaceAllString(strMain, search, replace);		
			//strMain.toString().replaceAll(")", "");
			//tokenize with the "white_space"
			String[] result = strMain.split(" ");
			int pos;
			for(int i=0; i<result.length;){
				String str = "RT";
				String req = str.concat(result[i]);
				i = i + 1;
				pos = Integer.parseInt(result[i]);
				i = i + 1;
				for(int j=0; j<SMTMain.NUM_REQ; j++){
					if(req.equalsIgnoreCase(tmpFinalOrder[j])){
						pos = j;
						break;}
				}
				if(req.length()==3)
					reqOrders[sizeA][pos] = req.substring(0, 2) + "00" + req.substring(2, req.length());
				else if(req.length()==4)
					reqOrders[sizeA][pos] = req.substring(0, 2) + "0" + req.substring(2, req.length());
				else
					reqOrders[sizeA][pos] = req;
			}
			//cout << strMain << "\n";

			assertStrings.add(sizeA, mainString.toString());
			sizeA++;
			solutionCounter++;
			//cout << mainString.c_str() << "\n";
			}
		
		while((minDisagreement == lastDisagree) && (ElicitPairs.elicitedPairs < maxElicitedPair)){
			System.gc();
			writeYicesFilewithAsserts wYFA = new writeYicesFilewithAsserts();
			wYFA.writeYicesWithNewAssert();
			prepath = mainGUI.OutPath;
			postpath = "/smt/analysis/SMT.txt";
			fileToDel = prepath + postpath;
			f = new File(fileToDel);
			if(f.exists())
				f.delete();
			if(mainGUI.USER_PLATFORM >= 0 && mainGUI.USER_PLATFORM <= 6){
				String tmp = "chmod a+x " + mainGUI.PROJECT_PATH + "resources/yices/" + folder + "yices";
				String tmp1 = mainGUI.PROJECT_PATH + "resources/yices/" + folder + "./yices " + mainGUI.OutPath + "smt/analysis/SMT.ys" + " > " + mainGUI.OutPath + "smt/analysis/SMT.txt";
				String shcmd[] = {"/bin/bash", "-c",  tmp};
				String shcmd1[] = {"/bin/bash", "-c",  tmp1};
				process = Runtime.getRuntime().exec(shcmd);
				process.waitFor();
				process = Runtime.getRuntime().exec(shcmd1);
				process.waitFor();
			}
			else{
				run = Runtime.getRuntime();
				try{
					process = run.exec(cmd); }
				catch (Exception e) {}
				process.waitFor();
			}

			//get the sorted requirement order from SMT file hereE:/EclipseCPP/workspace.
			//String[] tmpFinalOrder = new String[NUMREQ]; tmpFinalIndx = new int[NUMREQ];
			//get the sorted requirement order from SMT file hereE:/EclipseCPP/workspace.
			prepath = mainGUI.OutPath;
			postpath = "/smt/analysis/SMT.txt";
			filepath = prepath + postpath;
			Fstream = new FileInputStream(filepath);
			IN = new DataInputStream(Fstream);
			BR = new BufferedReader(new InputStreamReader(IN));
			foundPair = 0;
			while((line = BR.readLine()) != null){
				if(line.indexOf("(=") != -1){
					foundPair++;
					String req = line.substring(7, line.length());
					String search = ")"; String replace = "";
					req = rep.replaceAllString(req, search, replace);
					//req.replaceAll(")", "");
					String[] result = req.split(" ");
					for(int i=0; i<result.length;){
						String str = "RT";
						String REQ = str.concat(result[i]);
						i = i + 1;
						int post = Integer.parseInt(result[i]);
						i = i + 1;
						tmpFinalOrder[foundPair-1] = REQ;
						tmpFinalIndx[foundPair-1] = post;
					}
				}
				if(foundPair == SMTMain.NUM_REQ)
					break;
			}
			BR.close(); IN.close(); Fstream.close();

			for(int i=0; i<SMTMain.NUM_REQ-1; i++){
				for(int j=i+1; j<SMTMain.NUM_REQ; j++){
					if(tmpFinalIndx[i] > tmpFinalIndx[j]){
						int tmp = tmpFinalIndx[i];
						tmpFinalIndx[i] = tmpFinalIndx[j];
						tmpFinalIndx[j] = tmp;
						String str = tmpFinalOrder[i];
						tmpFinalOrder[i] = tmpFinalOrder[j];
						tmpFinalOrder[j] = str;
			}}}

			//capture ordering and cost
			prepath = mainGUI.OutPath;
			postpath = "/smt/analysis/SMT.txt";
			filepath = prepath + postpath;
			Fstream = new FileInputStream(filepath);
			IN = new DataInputStream(Fstream);
			BR = new BufferedReader(new InputStreamReader(IN));
			mainString = "(assert ";
			String strMain2 = "";
			foundPair = 0; costflag = 0;
				while((line = BR.readLine()) != null){
					if(foundPair == SMTMain.NUM_REQ && !line.contains("cost"))
						continue;
					if(line.contains("cost")){
						disagree = Integer.parseInt(line.substring(6, line.length()));
						lastDisagree = disagree;
						costflag = 1;
						if(minDisagreement > disagree)
						minDisagreement = disagree;
					}
					if (line.contains("sat"))
						continue;
					else{
						if((line.contains("(=")) && (foundPair < SMTMain.NUM_REQ)) {
							foundPair++;
							String search = "(="; String replace = "(/=";
							line = rep.replaceAllString(line, search, replace);
							//line.replaceFirst("(=", "(/=");
						}
						if(foundPair == 1)
							strMain2 = strMain2.concat(line+" ");
						else{
							if((foundPair == SMTMain.NUM_REQ) && costflag == 0)
								strMain2 = strMain2.concat(line+")");
							else if((foundPair < SMTMain.NUM_REQ) && costflag == 0)
								strMain2 = strMain2.concat(line+") ");
						}
					}
						if(foundPair == SMTMain.NUM_REQ && costflag == 1)
							break;
					}
			BR.close(); IN.close(); Fstream.close();
			
			for(int i=0; i<SMTMain.NUM_REQ-1; i++)
				mainString = mainString.concat("(or ");
			mainString = mainString.concat(strMain2+")");
			
			if(!assertStrings.contains(mainString.toString()) && (minDisagreement == lastDisagree)){
				//replacing all "(/= (R "
				String search = "(/= (RT "; String replace = "";
				strMain2 = rep.replaceAllString(strMain2, search, replace);
				//strMain2.toString().replaceAll("(/= (RT ", "");
				//replacing all "))"
				search = "))"; replace = "";
				strMain2 = rep.replaceAllString(strMain2, search, replace);
				//strMain2.toString().replaceAll("))", "");
				//replacing all ")"
				search = ")"; replace = "";
				strMain2 = rep.replaceAllString(strMain2, search, replace);
				//strMain2.toString().replaceAll(")", "");
				//tokenize with the "white_space"
				String[] result = strMain2.split(" ");
				int pos;
				for(int i=0; i<result.length;)
					try {
						{
							String str = "RT";
							String req = str.concat(result[i]);
							i = i + 1;
							pos = Integer.parseInt(result[i]);
							i = i + 1;
							for(int j=0; j<SMTMain.NUM_REQ; j++){
								if(req.equalsIgnoreCase(tmpFinalOrder[j])){
									pos = j;
									break;}
							}		
						if(req.length()==3)
							reqOrders[sizeA][pos] = req.substring(0, 2) + "00" + req.substring(2, req.length());
						else if(req.length()==4)
							reqOrders[sizeA][pos] = req.substring(0, 2) + "0" + req.substring(2, req.length());
						else
							reqOrders[sizeA][pos] = req;
						}
					} catch (NumberFormatException e) {
						e.printStackTrace();
					}
				//cout << strMain << "\n";

				assertStrings.add(sizeA, mainString.toString());
				sizeA++;
				solutionCounter++;
				//cout << mainString.c_str() << "\n";
				
		}
			if(sizeA == SMTMain.MAX_SIZE)
				break;
		}
		
		if(solutionCounter >= 2){
			int preEli = ElicitPairs.elicitedPairs;
			SMTMain.sb = new StringBuilder(); 
			double START_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
			ElicitPairs.doElicit(x, y, z, x1);
			double END_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
			if(SMTMain.sb.length() > 0){
				ElicitPairs.ELI_SESSION[index][0] = SMTMain.sb.toString();
				ElicitPairs.ELI_SESSION[index][1] = Double.toString(END_TIME - START_TIME);
				index++;
			}
			int postEli = ElicitPairs.elicitedPairs;
			writeYicesFileALLCons wYFALL = new writeYicesFileALLCons();
			wYFALL.writeYicesWithALLCons(x, y, z, x1);
			//clear everything
			//for(int i=0;i<MAXSIZE;i++){
			//	for(int j=0;j<NUMREQ;j++){
			//		reqOrders[i][j].clear();}}
			assertStrings.clear();
			solutionCounter=0; minDisagreement=9999; lastDisagree=0;
			sizeA=0;
			if(preEli == postEli)
				break;
		}
		
		else{
			writeYicesFileALLCons wYFALL = new writeYicesFileALLCons();
			wYFALL.writeYicesWithALLCons(x, y, z, x1);
			prepath = mainGUI.OutPath;
			postpath = "/smt/analysis/SMT.txt";
			fileToDel = prepath + postpath;
			f = new File(fileToDel);
			if(f.exists())
				f.delete();
			if(mainGUI.USER_PLATFORM >= 0 && mainGUI.USER_PLATFORM <= 6){
				String tmp = "chmod a+x " + mainGUI.PROJECT_PATH + "resources/yices/" + folder + "yices";
				String tmp1 = mainGUI.PROJECT_PATH + "resources/yices/" + folder + "./yices " + mainGUI.OutPath + "smt/analysis/SMT.ys" + " > " + mainGUI.OutPath + "smt/analysis/SMT.txt";
				String shcmd[] = {"/bin/bash", "-c",  tmp};
				String shcmd1[] = {"/bin/bash", "-c",  tmp1};
				process = Runtime.getRuntime().exec(shcmd);
				process.waitFor();
				process = Runtime.getRuntime().exec(shcmd1);
				process.waitFor();
			}
			else{
				run = Runtime.getRuntime();
				try{
					process = run.exec(cmd); }
				catch (Exception e) {}
				process.waitFor();
			}
			
			SMTMain.END_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
			SMTMain.TOTAL_PRIO_TIME = Double.parseDouble((mainGUI.fmtObj.format(SMTMain.END_TIME - SMTMain.START_TIME)));
			CalculateDisagreement calcDis = new CalculateDisagreement();
			calcDis.calculateDisagreementGS(x, y, z, x1);
			exitflag = 1;
		}
	}	//END OF WHILE LOOPE:/EclipseCPP/workspace.
	
	if(exitflag == 0){
	replaceString rep = new replaceString();
	//cout << "END OF WHILE LOOP";
	assertStrings.clear(); solutionCounter=0; lastDisagree=0;
	sizeA=0;
	int disagree;
	writeYicesFileALLCons wYFALL = new writeYicesFileALLCons();
	wYFALL.writeYicesWithALLCons(x, y, z, x1);
	String prepath = mainGUI.OutPath;
	String postpath = "/smt/analysis/SMT.txt";
	String fileToDel = prepath + postpath;
	File f = new File(fileToDel);
	if(f.exists())
		f.delete();
	if(mainGUI.USER_PLATFORM >= 0 && mainGUI.USER_PLATFORM <= 6){
		String tmp = "chmod a+x " + mainGUI.PROJECT_PATH + "resources/yices/" + folder + "yices";
		String tmp1 = mainGUI.PROJECT_PATH + "resources/yices/" + folder + "./yices " + mainGUI.OutPath + "smt/analysis/SMT.ys" + " > " + mainGUI.OutPath + "smt/analysis/SMT.txt";
		String shcmd[] = {"/bin/bash", "-c",  tmp};
		String shcmd1[] = {"/bin/bash", "-c",  tmp1};
		process = Runtime.getRuntime().exec(shcmd);
		process.waitFor();
		process = Runtime.getRuntime().exec(shcmd1);
		process.waitFor();
	}
	else{
		run = Runtime.getRuntime();
		try{
			process = run.exec(cmd); }
		catch (Exception e) {}
		process.waitFor();
	}

	//get the sorted requirement order from SMT file hereE:/EclipseCPP/workspace.
	String[] tmpFinalOrder = new String[NUMREQ]; int[] tmpFinalIndx = new int[NUMREQ];
	prepath = mainGUI.OutPath;
	postpath = "/smt/analysis/SMT.txt";
	String filepath = prepath + postpath;
	FileInputStream Fstream = new FileInputStream(filepath);
	DataInputStream IN = new DataInputStream(Fstream);
	BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
	int foundPair = 0; String line;
	while ((line = BR.readLine()) != null){
		if(line.indexOf("(=") != -1){
			foundPair++;
			String req = line.substring(7, line.length());
			String search = ")"; String replace = "";
			req = rep.replaceAllString(req, search, replace);
			//req.replace(")","");
			String[] result = req.split(" ");
			for(int i=0; i<result.length;){
				String str = "RT";
				String REQ = str.concat(result[i]);
				i = i + 1;
				int post = Integer.parseInt(result[i]);
				i = i + 1;
				tmpFinalOrder[foundPair-1] = REQ;
				tmpFinalIndx[foundPair-1] = post;
			}
		}
		if(foundPair == SMTMain.NUM_REQ)
			break;
	}
	BR.close(); IN.close(); Fstream.close();

	for(int i=0; i<SMTMain.NUM_REQ-1; i++){
		for(int j=i+1; j<SMTMain.NUM_REQ; j++){
			if(tmpFinalIndx[i] > tmpFinalIndx[j]){
				int tmp = tmpFinalIndx[i];
				tmpFinalIndx[i] = tmpFinalIndx[j];
				tmpFinalIndx[j] = tmp;
				String str = tmpFinalOrder[i];
				tmpFinalOrder[i] = tmpFinalOrder[j];
				tmpFinalOrder[j] = str;
	}}}
	
	//capture ordering and cost
	prepath = mainGUI.OutPath;
	postpath = "/smt/analysis/SMT.txt";
	filepath = prepath + postpath;
	Fstream = new FileInputStream(filepath);
	IN = new DataInputStream(Fstream);
	BR = new BufferedReader(new InputStreamReader(IN));
	String mainString = "(assert ";
		String strMain = "";
		foundPair = 0;
		int costflag = 0;
			while((line = BR.readLine()) != null){
				if(foundPair == SMTMain.NUM_REQ && !line.contains("cost"))
					continue;
				if(line.contains("cost")){
					String dis = line.substring(6, line.length());
					disagree = Integer.parseInt(dis);
					lastDisagree = disagree;
					costflag = 1;

				if(minDisagreement > disagree)
					minDisagreement = disagree;
				}
				if (line.contains("sat"))
					continue;
				else{
					if(line.contains("(=") && (foundPair < SMTMain.NUM_REQ)){
						foundPair++;
						String search = "(="; String replace = "(/=";
						line = rep.replaceAllString(line, search, replace);
						//line.replaceFirst("(=", "(/=");
					}
					if(foundPair == 1)
						strMain = strMain.concat(line+" ");
					else{
						if((foundPair == SMTMain.NUM_REQ) && costflag == 0)
							strMain = strMain.concat(line+")");
						else if((foundPair < SMTMain.NUM_REQ) && costflag == 0)
							strMain = strMain.concat(line+") ");
					}
				}
				if(foundPair == SMTMain.NUM_REQ && costflag == 1)
					break;
	}
	BR.close(); IN.close(); Fstream.close();
	
	for(int i=0; i<SMTMain.NUM_REQ-1; i++)
		mainString = mainString.concat("(or ");
	mainString = mainString.concat(strMain+")");
	if(!assertStrings.contains(mainString.toString()) && strMain.length()>0 ){
		//replacing all "(/= (R "
		String search = "(/= (RT "; String replace = "";
		strMain = rep.replaceAllString(strMain, search, replace);
		//strMain.replace("(/= (RT ", "");
		//replacing all "))"
		search = "))"; replace = "";
		strMain = rep.replaceAllString(strMain, search, replace);
		//strMain.toString().replaceAll("))", "");
		//replacing all ")"
		search = ")"; replace = "";
		strMain = rep.replaceAllString(strMain, search, replace);		
		//strMain.toString().replaceAll(")", "");
		//tokenize with the "white_space"
		String[] result = strMain.split(" ");
		int pos;
		for(int i=0; i<result.length;){
			String str = "RT";
			String req = str.concat(result[i]);
			i = i + 1;
			pos = Integer.parseInt(result[i]);
			i = i + 1;
			for(int j=0; j<SMTMain.NUM_REQ; j++){
				if(req.equalsIgnoreCase(tmpFinalOrder[j])){
					pos = j;
					break;}
			}
			//if(req.length()==3)
			//	reqOrdersFINAL[sizeA][pos] = req.substring(0, 2) + "00" + req.substring(2, req.length());
			//else if(req.length()==4)
			//	reqOrdersFINAL[sizeA][pos] = req.substring(0, 2) + "0" + req.substring(2, req.length());
			//else
				reqOrdersFINAL[sizeA][pos] = req;
		}
		//cout << strMain << "\n";

		assertStrings.add(sizeA, mainString.toString());
		sizeA++;
		solutionCounter++;
		//cout << mainString.c_str() << "\n";
		}

	while(minDisagreement == lastDisagree){
		System.gc();

		writeYicesFilewithAsserts wYFA = new writeYicesFilewithAsserts();
		wYFA.writeYicesWithNewAssert();

		prepath = mainGUI.OutPath;
		postpath = "/smt/analysis/SMT.txt";
		fileToDel = prepath + postpath;
		f = new File(fileToDel);
		if(f.exists())
			f.delete();
		
		if(mainGUI.USER_PLATFORM >= 0 && mainGUI.USER_PLATFORM <= 6){
			String tmp = "chmod a+x " + mainGUI.PROJECT_PATH + "resources/yices/" + folder + "yices";
			String tmp1 = mainGUI.PROJECT_PATH + "resources/yices/" + folder + "./yices " + mainGUI.OutPath + "smt/analysis/SMT.ys" + " > " + mainGUI.OutPath + "smt/analysis/SMT.txt";
			String shcmd[] = {"/bin/bash", "-c",  tmp};
			String shcmd1[] = {"/bin/bash", "-c",  tmp1};
			process = Runtime.getRuntime().exec(shcmd);
			process.waitFor();
			process = Runtime.getRuntime().exec(shcmd1);
			process.waitFor();
		}
		else{
			run = Runtime.getRuntime();
			try{
				process = run.exec(cmd); }
			catch (Exception e) {}
			process.waitFor();
		}
		
		//get the sorted requirement order from SMT file hereE:/EclipseCPP/workspace.
		//tmpFinalOrder = new String[NUMREQ]; tmpFinalIndx = new int[NUMREQ];
		//get the sorted requirement order from SMT file hereE:/EclipseCPP/workspace.
		prepath = mainGUI.OutPath;
		postpath = "/smt/analysis/SMT.txt";
		filepath = prepath + postpath;
		Fstream = new FileInputStream(filepath);
		IN = new DataInputStream(Fstream);
		BR = new BufferedReader(new InputStreamReader(IN));
		foundPair = 0;
		while((line = BR.readLine()) != null){
			if(line.indexOf("(=") != -1){
				foundPair++;
				String req = line.substring(7, line.length());
				String search = ")"; String replace = "";
				req = rep.replaceAllString(req, search, replace);
				//req.replaceAll(")", "");
				String[] result = req.split(" ");
				for(int i=0; i<result.length;){
					String str = "RT";
					String REQ = str.concat(result[i]);
					i = i + 1;
					int post = Integer.parseInt(result[i]);
					i = i + 1;
					tmpFinalOrder[foundPair-1] = REQ;
					tmpFinalIndx[foundPair-1] = post;
				}
			}
			if(foundPair == SMTMain.NUM_REQ)
				break;
		}
		BR.close(); IN.close(); Fstream.close();

		for(int i=0; i<SMTMain.NUM_REQ-1; i++){
			for(int j=i+1; j<SMTMain.NUM_REQ; j++){
				if(tmpFinalIndx[i] > tmpFinalIndx[j]){
					int tmp = tmpFinalIndx[i];
					tmpFinalIndx[i] = tmpFinalIndx[j];
					tmpFinalIndx[j] = tmp;
					String str = tmpFinalOrder[i];
					tmpFinalOrder[i] = tmpFinalOrder[j];
					tmpFinalOrder[j] = str;
		}}}

		//capture ordering and cost
		prepath = mainGUI.OutPath;
		postpath = "/smt/analysis/SMT.txt";
		filepath = prepath + postpath;
		Fstream = new FileInputStream(filepath);
		IN = new DataInputStream(Fstream);
		BR = new BufferedReader(new InputStreamReader(IN));
		mainString = "(assert ";
			strMain = "";
			foundPair = 0;
			costflag = 0;
				while((line = BR.readLine()) != null){
					if(foundPair == SMTMain.NUM_REQ && !line.contains("cost"))
						continue;
					if(line.contains("cost")){
						String dis = line.substring(6, line.length());
						disagree = Integer.parseInt(dis);
						lastDisagree = disagree;
						costflag = 1;

					if(minDisagreement > disagree)
						minDisagreement = disagree;
					}
					if (line.contains("sat"))
						continue;
					else{
						if(line.contains("(=") && (foundPair < SMTMain.NUM_REQ)){
							foundPair++;
							String search = "(="; String replace = "(/=";
							line = rep.replaceAllString(line, search, replace);
							//line.replaceFirst("(=", "(/=");
						}
						if(foundPair == 1)
							strMain = strMain.concat(line+" ");
						else{
							if((foundPair == SMTMain.NUM_REQ) && costflag == 0)
								strMain = strMain.concat(line+")");
							else if((foundPair < SMTMain.NUM_REQ) && costflag == 0)
								strMain = strMain.concat(line+") ");
						}
					}
					if(foundPair == SMTMain.NUM_REQ && costflag == 1)
						break;
		}
		BR.close(); IN.close(); Fstream.close();
		
		for(int i=0; i<SMTMain.NUM_REQ-1; i++)
			mainString = mainString.concat("(or ");
		mainString = mainString.concat(strMain+")");
		if(!assertStrings.contains(mainString.toString()) && strMain.length()>0 ){
			//replacing all "(/= (R "
			String search = "(/= (RT "; String replace = "";
			strMain = rep.replaceAllString(strMain, search, replace);
			//strMain.replace("(/= (RT ", "");
			//replacing all "))"
			search = "))"; replace = "";
			strMain = rep.replaceAllString(strMain, search, replace);
			//strMain.toString().replaceAll("))", "");
			//replacing all ")"
			search = ")"; replace = "";
			strMain = rep.replaceAllString(strMain, search, replace);		
			//strMain.toString().replaceAll(")", "");
			//tokenize with the "white_space"
			String[] result = strMain.split(" ");
			int pos;
			for(int i=0; i<result.length;){
				String str = "RT";
				String req = str.concat(result[i]);
				i = i + 1;
				pos = Integer.parseInt(result[i]);
				i = i + 1;
				for(int j=0; j<SMTMain.NUM_REQ; j++){
					if(req.equalsIgnoreCase(tmpFinalOrder[j])){
						pos = j;
						break;}
				}
				//if(req.length()==3)
				//	reqOrdersFINAL[sizeA][pos] = req.substring(0, 2) + "00" + req.substring(2, req.length());
				//else if(req.length()==4)
				//	reqOrdersFINAL[sizeA][pos] = req.substring(0, 2) + "0" + req.substring(2, req.length());
				//else
					reqOrdersFINAL[sizeA][pos] = req;
			}
			//cout << strMain << "\n";

			assertStrings.add(sizeA, mainString.toString());
			sizeA++;
			solutionCounter++;
			//cout << mainString.c_str() << "\n";
			}
	
		if(sizeA == SMTMain.MAX_SIZE)
			break;
}
	SMTMain.END_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
	SMTMain.TOTAL_PRIO_TIME = Double.parseDouble((mainGUI.fmtObj.format(SMTMain.END_TIME - SMTMain.START_TIME)));
	
	CalculateDisagreementLst calcDisLst = new CalculateDisagreementLst();
	calcDisLst.calculateDisagreementGSLast(x, y, z, x1);
	}
	System.out.println("Finished main algorithm for SMT...");

	}

}