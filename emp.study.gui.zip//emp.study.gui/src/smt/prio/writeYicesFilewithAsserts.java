package smt.prio;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import pack.gui.mainGUI;

/**
 * @author Francis
 *
 */
public class writeYicesFilewithAsserts {
	
	public void writeYicesWithNewAssert() throws IOException{
		System.out.println("Started writing Yices file with asserts...");
		//System.out.println("writeYicesFilewithAsserts");
		//System.gc();
		BufferedWriter bw = null;
		String prepath = mainGUI.OutPath;
		String postpath = "/smt/analysis/SMT.ys";
		String filepath = prepath + postpath;
		bw = new BufferedWriter(new FileWriter(filepath));
		bw.write("(set-evidence! true)");
		bw.write("\n");
		bw.write (";;(set-arith-only! true)");
		bw.write("\n");
		bw.write ("(define RT::(-> nat nat))");
		bw.write("\n");
		String strr = "(define N::nat " + Integer.toString(SMTMain.NUM_REQ) + ")";
		bw.write (strr);
		bw.write("\n\n");
		bw.write("(assert (forall (i::(subrange 1 N)) (and (>= (RT i) 1) (<= (RT i) N))))");
		bw.write("\n");
		bw.write("(assert (forall (i::(subrange 1 (- N 1))) (forall (j::(subrange (+ i 1) N)) (/= (RT i) (RT j)))))");
		bw.write("\n\n");
		//write prio here;;
		for(int xx=0; xx<mainGUI.TOTPRIO; xx++){
		for(int i=0; i<SMTMain.NUM_REQ; i++){
			for(int j=0; j<SMTMain.NUM_REQ; j++){
				int prioWeight = BuildPriorityGraph.adjacencyMatrix[xx][i][j];
				if(BuildPriorityGraph.adjacencyMatrix[xx][i][j] == 1){
					String str = "(assert+ (< (RT " + Integer.toString(i+1) + ") (RT " + Integer.toString(j+1) + ")) " + Integer.toString(prioWeight) + ")";
					bw.write(str.toString());
					bw.write("\n");
				}
			}
		}
		}
		bw.write("\n");
		//write dep here;;
		for(int xx=0; xx<mainGUI.TOTDEP; xx++){
		int depWeight = 1;
		for(int i=0; i<SMTMain.NUM_REQ; i++){
			for(int j=0; j<SMTMain.NUM_REQ; j++){
				if(BuildDependencyGraph.depndencyMatrix[xx][i][j] == 1){
					String str = "(assert+ (< (RT " + Integer.toString(i+1) + ") (RT " + Integer.toString(j+1) + ")) " + Integer.toString(depWeight) + ")";
					bw.write(str.toString());
					bw.write("\n");
				}
			}
		}
		}
		bw.write("\n");
		
		//write eli here;;
		int eliWeight = 1;
		for(int i=0; i<SMTMain.NUM_REQ; i++){
			for(int j=0; j<SMTMain.NUM_REQ; j++){
				if(ElicitPairs.elicitedMatrix[i][j] == 1){
					String str = "(assert+ (< (RT " + Integer.toString(i+1) + ") (RT " + Integer.toString(j+1) + ")) " + Integer.toString(eliWeight) + ")";
					bw.write(str.toString());
					bw.write("\n");
				}
			}
		}
		
		bw.write("\n");
		for(int i=0; i<AlgorithmSMT.sizeA; i++){ //
			if(AlgorithmSMT.assertStrings.get(i).length()>0){
				bw.write(AlgorithmSMT.assertStrings.get(i).toString());
				bw.write("\n");}
		}
		bw.write("\n");
		bw.write("(max-sat)");
		bw.close();
		System.out.println("Finished writing Yices file with asserts...");
	}
}