package smt.prio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;


class GetGoldStandard {

public static String[] goldStandard = new String[SMTMain.NUM_REQ];

public void getGoldStandard(int x, int y, int z, String x1) throws IOException{
	System.out.println("Getting Gold Standard (GS)...");
	String prepath = mainGUI.InPath;
	String postpath = "/oth/eliOrd.txt";
	String inputfile = prepath + x1 + postpath;
	FileInputStream FStream = new FileInputStream(inputfile);
	DataInputStream In = new DataInputStream(FStream);
	BufferedReader Br = new BufferedReader(new InputStreamReader(In));
	String strLine;
		while ((strLine = Br.readLine()) != null){		
			String[] tempeli = new String[SMTMain.NUM_REQ];
			tempeli = strLine.split(" ");
			for(int i=0; i<tempeli.length; i++)
				goldStandard[i] = tempeli[i];
		}
		Br.close();
		prepath = mainGUI.OutPath;
		postpath = "/smt/results/smt.out";
		String filepath = prepath + postpath;
		BufferedWriter bw = new BufferedWriter(new FileWriter(filepath, true));
		bw.write("Gold Standard: \n");
		for(int i=0; i<goldStandard.length; i++)
			bw.write(goldStandard[i] + " ");
		bw.write("\n\n");
		bw.close();
	}

}



