package smt.prio;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;

public class GetSize {

public static int populationSIZE;

public int getPopulationSize(String x1) throws IOException{
	System.out.println("Getting number of requirements...");
	String prepath = mainGUI.InPath;
	String postpath = "/prio/0priority.txt";
	String inputfile = prepath + x1 + postpath;
	FileInputStream FStream = new FileInputStream(inputfile);
	DataInputStream In = new DataInputStream(FStream);
	BufferedReader Br = new BufferedReader(new InputStreamReader(In));
			int totalElement = 0;
			while ((Br.readLine()) != null){
				totalElement++;
			}
			Br.close();
	populationSIZE = totalElement;
	return populationSIZE;
}
}
