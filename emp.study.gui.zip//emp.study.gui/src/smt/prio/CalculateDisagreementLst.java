package smt.prio;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import pack.gui.mainGUI;

public class CalculateDisagreementLst {

public int calculateDisagreementGSLast(int x, int y, int z, String x1) throws IOException{
	System.out.println("Calculating disagreementLst for SMT...");
	String prepath = mainGUI.OutPath;
	String postpath = "/smt/results/smt.out";
	String filepath = prepath + postpath;
	BufferedWriter bw = new BufferedWriter(new FileWriter(filepath, true));
	if(mainGUI.GSFLAG == 1){
	bw.write("Disagreement with GS: " + "\n");
	int NUMREQ = x;
	//calculate disagree here for orders
	ArrayList<String> disagreeList = new ArrayList<String>();
	for(int l=0; l<AlgorithmSMT.sizeA; l++){
	int totalDisAgreeGS = 0;
		for(int i=0; i<NUMREQ-1; i++){
			for(int j=i+1; j<NUMREQ; j++){
				String fOsrc = AlgorithmSMT.reqOrdersFINAL[l][i];
				int fOindxsrc = i;
				String fOdst = AlgorithmSMT.reqOrdersFINAL[l][j];
				int fOindxdst = j;
				int gsindxsrc = 0, gsindxdst = 0;
				for(int k=0; k<NUMREQ; k++){
					if(Integer.parseInt((GetGoldStandard.goldStandard[k].substring(2, GetGoldStandard.goldStandard[k].length())).toString()) == Integer.parseInt((fOsrc.substring(2, fOsrc.length())).toString()))
						gsindxsrc = k;
					if(Integer.parseInt((GetGoldStandard.goldStandard[k].substring(2, GetGoldStandard.goldStandard[k].length())).toString()) == Integer.parseInt((fOdst.substring(2, fOdst.length())).toString()))
						gsindxdst = k;
				}
					if(fOindxsrc <= fOindxdst && gsindxsrc <= gsindxdst){//(fOindxsrc > fOindxdst && gsindxsrc < gsindxdst) || (fOindxsrc < fOindxdst && gsindxsrc > gsindxdst)){
						continue;
					}
					else{
						totalDisAgreeGS++;
						disagreeList.add(fOsrc + fOdst);
					}
			}
		}
		bw.write(totalDisAgreeGS + "\t");
	}
	bw.write("\n\n");
	
	//calculate average distance here.
	bw.write("Average Distance with GS: " + "\n");
	for(int y1=0; y1<AlgorithmSMT.sizeA; y1++){
			float averageDistance;
			int diffSum = 0;
			for(int j=0; j<NUMREQ; j++){
				String tmp = AlgorithmSMT.reqOrdersFINAL[y1][j];
				int indxIndv = j;
				int indxDiff, indxGS = 0;
				for(int k=0; k<NUMREQ; k++){
					if(Integer.parseInt((GetGoldStandard.goldStandard[k].substring(2, GetGoldStandard.goldStandard[k].length())).toString()) == Integer.parseInt((tmp.substring(2,tmp.length())).toString()))
						indxGS = k;
				}
				if(indxIndv < indxGS)
					indxDiff = indxGS - indxIndv;
				else
					indxDiff = indxIndv - indxGS;
				diffSum = diffSum + indxDiff;
			}
			averageDistance = (float) diffSum/NUMREQ;
			bw.write(averageDistance + "\t");
	}
	bw.write("\n\n");
	}
	bw.write("\n\n");
	
		int len = (int)ElicitPairs.elicitedPairList.size();
		bw.write("\n");
		bw.write("Elicited pairs list: " + "\n");
		for(int i=0; i<len; i++){
			bw.write(ElicitPairs.elicitedPairList.get(i));
			bw.write("\n");
		}
		bw.write("\n\n");
		bw.write("\nFinal Ordering: \n");
		for(int l=0; l<AlgorithmSMT.sizeA; l++){
			for(int i=0; i<GetSize.populationSIZE; i++)
				bw.write(AlgorithmSMT.reqOrdersFINAL[l][i] + " ");
			bw.write("\n");
		}
		if(mainGUI.GSFLAG == 1){
		bw.write("\n");
		bw.write("Error pairs (wrongly decided by the user):\n");
		for(int i=0; i<AlgorithmSMT.errorPair; i++){
			if(AlgorithmSMT.errorEli[i] != null){
				bw.write(AlgorithmSMT.errorEli[i]);
			}
			bw.write("\n");
		}}
		bw.write("\n");
		int temp = ElicitPairs.elicitedPairs;
		bw.write("\nTotal pairs elicited by the user: " + temp);
		bw.write("\n");
		if(mainGUI.GSFLAG == 1){
		temp = AlgorithmSMT.errorPair;
		bw.write("Number of pairs elicited wrongly by the user: " + temp);
		bw.write("\n");
		float tmp = (float)((float)(AlgorithmSMT.errorPair * 100.00)/ElicitPairs.elicitedPairs);
		bw.write("Percentage/probability of user error: " + tmp);
		bw.write("\n");
		}
		bw.write("\n");
		bw.write("Total Prioritization time: " + SMTMain.TOTAL_PRIO_TIME + "s" + "\n");
		bw.write("Total duration of elicitation session: " + SMTMain.TOTAL_ELI_TIME + "s" + "\n");
		bw.write("Minimum elicitation time for a pair: " + SMTMain.MIN_ELI_TIME + "s" + "\n");
		bw.write("Maximum elicitation time for a pair: " + SMTMain.MAX_ELI_TIME + "s" + "\n");
		bw.write("Average elicitation time for all pairs: " + SMTMain.AVG_ELI_TIME + "s" + "\n");
		bw.write("\n");
		bw.write("\n");
		
		bw.write("FBK IRST, CIT!!!");
		bw.close();
		
		FileWriter fstream1 = new FileWriter(mainGUI.OutPath+"smt/results/finalorder_smt.out");
		BufferedWriter out1 = new BufferedWriter(fstream1);
		for(int i=0; i<SMTMain.MAX_SIZE; i++){
			if(AlgorithmSMT.reqOrdersFINAL[i][0] != null)
				out1.write("Alternative "+Integer.toString(i+1) + ": \n");
			else
				continue;
			for(int j=0; j<SMTMain.NUM_REQ; j++){
				if(AlgorithmSMT.reqOrdersFINAL[i][j] != null){
					out1.write(AlgorithmSMT.reqOrdersFINAL[i][j]+" ");
				}
			}
			out1.write("\n");
		}
		out1.flush();
		out1.close();
		if(mainGUI.GSFLAG == 1){
		FileWriter fstream2 = new FileWriter(mainGUI.OutPath+"smt/results/eli_smt.out");
		BufferedWriter out2 = new BufferedWriter(fstream2);
		out2.write("Elicited pair" + "\t" + "Wrong???"+ "\t"+ "Eli_Time(in Sec)"+ "\t"+ "Cumulative_Eli_Time(in Sec)"+ "\n");
		for(int i=0; i<ElicitPairs.elicitedPairs; i++){
			String flag = null;
			if(AlgorithmSMT.eliOrderFlag[i] == 1)
				flag = "yes";
			else if(AlgorithmSMT.eliOrderFlag[i] == 0)
				flag = "no";
			out2.write(ElicitPairs.elicitedPairList.get(i) + "\t\t" + flag+ "\t\t\t"+ AlgorithmSMT.ELI_INDV_TIME[i] + "\t\t\t\t\t"+ AlgorithmSMT.ELI_CUMUL_TIME_SUM[i]+ "\n");
		}
		out2.write("\n\nSession details for the Elicited Pairs: \n\n");
		for(int i=0; i<ElicitPairs.elicitedPairs; i++){
			if(ElicitPairs.ELI_SESSION[i][0] != null){
				out2.write("\nSession: "+ Integer.toString(i+1) + "\n");
				out2.write(ElicitPairs.ELI_SESSION[i][0] + "\t\t" + ElicitPairs.ELI_SESSION[i][1]+ "\n");
			}
		}
		out2.write("\n***{Pairs elicited in each session} [\\t] {Total time (in sec.) for that session}\n");
		out2.flush();
		out2.close();
		}
		System.out.println("Finished calculating disagreementLst for SMT...");
		return 0;
}
	
}
