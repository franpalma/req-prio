package smt.prio;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;

public class GetPriority{
	public static int index;
	public static String[][] listNodes = new String[mainGUI.TOTPRIO][SMTMain.NUM_REQ];
	public static int[][] nodesPriority = new int[mainGUI.TOTPRIO][SMTMain.NUM_REQ];
	public static String[][] listReq = new String[mainGUI.TOTPRIO][SMTMain.NUM_REQ];
	
	public void getPriorityArray(int x, int y, int z, String x1) throws IOException{
		System.out.println("Getting requirements' priority infos...");
		String prepath = mainGUI.InPath;
		String postpath = "/prio/";
		for(int xx=0; xx<mainGUI.TOTPRIO; xx++){
		String filepath = prepath + x1 + postpath + SMTMain.PRIOFILEs.get(xx);
		FileInputStream FStream = new FileInputStream(filepath);
		DataInputStream In = new DataInputStream(FStream);
		BufferedReader Br = new BufferedReader(new InputStreamReader(In));
		int index = 0;
		String strLine;
		while ((strLine = Br.readLine()) != null){
			String[] temp = new String[4];
			temp = strLine.split("\t");
			listNodes[xx][index] = temp[0];
			nodesPriority[xx][index] = Integer.parseInt(temp[1]);
			listReq[xx][index] = temp[2];
			index++;
		}
		Br.close();
		}
		System.out.println("Finished restoring requirements' priority infos...");
	}
}