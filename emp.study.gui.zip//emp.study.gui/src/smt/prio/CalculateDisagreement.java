package smt.prio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import pack.gui.mainGUI;

public class CalculateDisagreement {

public static String[] finalOrdering = new String[SMTMain.NUM_REQ];

public int calculateDisagreementGS(int x, int y, int z, String x1) throws IOException{
	System.out.println("Calculating disagreement for SMT...");
	int NUMREQ = x;
	//sort the result in ascending order
	String[] tmpFinalOrder = new String[NUMREQ];
	int[] tmpFinalIndx = new int[NUMREQ];
	String prepath = mainGUI.OutPath;
	String postpath = "smt/analysis/SMT.txt";
	String filepath = prepath + postpath;
	FileInputStream Fstream = new FileInputStream(filepath);
	DataInputStream IN = new DataInputStream(Fstream);
	BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
	int foundPair = 0; String line;
	replaceString rep = new replaceString();
	while ((line = BR.readLine()) != null){
		if(line.indexOf("(=") != -1){
			foundPair++;
			String req = line.substring(7, line.length());
			String search = ")"; String replace = "";
			req = rep.replaceAllString(req, search, replace);
			//req.replace(")","");
			String[] result = req.split(" ");
			for(int i=0; i<result.length;){
				String str = "RT";
				String REQ = str.concat(result[i]);
				i = i + 1;
				int post = Integer.parseInt(result[i]);
				i = i + 1;
				tmpFinalOrder[foundPair-1] = REQ;
				tmpFinalIndx[foundPair-1] = post;
			}
		}
		if(foundPair == SMTMain.NUM_REQ)
			break;
	}
	BR.close(); IN.close(); Fstream.close();

	for(int i=0; i<SMTMain.NUM_REQ-1; i++){
		for(int j=i+1; j<SMTMain.NUM_REQ; j++){
			if(tmpFinalIndx[i] > tmpFinalIndx[j]){
				int tmp = tmpFinalIndx[i];
				tmpFinalIndx[i] = tmpFinalIndx[j];
				tmpFinalIndx[j] = tmp;
				String str = tmpFinalOrder[i];
				tmpFinalOrder[i] = tmpFinalOrder[j];
				tmpFinalOrder[j] = str;
	}}}

	for(int i=0; i<NUMREQ; i++)
		finalOrdering[i] = tmpFinalOrder[i];
	int totalDisAgreeGS = 0; float averageDistance = 0;
	if(mainGUI.GSFLAG == 1){
	//calculate disagree here.
	
	ArrayList<String> disagreeList = new ArrayList<String>();
	
	for(int i=0; i<NUMREQ-1; i++){
		for(int j=i+1; j<NUMREQ; j++){
			if(finalOrdering[i] == null || finalOrdering[j] == null)
				continue;
			String fOsrc = finalOrdering[i];
			int fOindxsrc = i;
			String fOdst = finalOrdering[j];
			int fOindxdst = j;
			int gsindxsrc=0, gsindxdst=0;
			for(int k=0; k<NUMREQ; k++){
				if(Integer.parseInt((GetGoldStandard.goldStandard[k].substring(2, GetGoldStandard.goldStandard[k].length())).toString()) == Integer.parseInt((fOsrc.substring(2,fOsrc.length())).toString()))
					gsindxsrc = k;
				if(Integer.parseInt((GetGoldStandard.goldStandard[k].substring(2, GetGoldStandard.goldStandard[k].length())).toString()) == Integer.parseInt((fOdst.substring(2,fOdst.length())).toString()))
					gsindxdst = k;
			}
				if(fOindxsrc <= fOindxdst && gsindxsrc <= gsindxdst){//(fOindxsrc > fOindxdst && gsindxsrc < gsindxdst) || (fOindxsrc < fOindxdst && gsindxsrc > gsindxdst)){
					continue;
				}
				else{
					totalDisAgreeGS++;
					disagreeList.add(fOsrc + fOdst);
				}
		}
	}

	//calculate average distance here.
		
		int diffSum = 0;
		for(int j=0; j<NUMREQ; j++){
			if(finalOrdering[j] == null)
				continue;
			String tmp = finalOrdering[j];
			int indxIndv = j;
			int indxDiff, indxGS = 0;
			for(int k=0; k<NUMREQ; k++){
				if(Integer.parseInt((GetGoldStandard.goldStandard[k].substring(2, GetGoldStandard.goldStandard[k].length())).toString()) == Integer.parseInt((tmp.substring(2,tmp.length())).toString()))
					indxGS = k;
			}
			if(indxIndv < indxGS)
				indxDiff = indxGS - indxIndv;
			else
				indxDiff = indxIndv - indxGS;
			diffSum = diffSum + indxDiff;
		}
		averageDistance = (float) diffSum/NUMREQ;
	}
	
		prepath = mainGUI.OutPath;
		postpath = "/smt/results/smt.out";
		filepath = prepath + postpath;
		BufferedWriter bw = new BufferedWriter(new FileWriter(filepath, true));
		
		bw.write("\nFinal Ordering: \n");
		for(int i=0; i<NUMREQ; i++)
			bw.write(finalOrdering[i] + " ");
		bw.write("\n\n");
		if(mainGUI.GSFLAG == 1){
			bw.write("Disagreement with GS: " + totalDisAgreeGS + "\n");
		bw.write("Average Distance with GS: " + averageDistance + "\n");}
		bw.write("Total Elicited Pairs: " + ElicitPairs.elicitedPairList.size() + "\n");
		if(mainGUI.GSFLAG == 1){
		bw.write("Total Error Pairs: " + AlgorithmSMT.errorPair + "\n");}
		bw.write("\n\n");
		int len = (int)ElicitPairs.elicitedPairList.size();
		bw.write("\n");
		bw.write("Elicited pairs list: " + "\n");
		for(int i=0; i<len; i++){
			bw.write(ElicitPairs.elicitedPairList.get(i));
			bw.write("\n");
		}
		bw.write("\n\n");
		if(mainGUI.GSFLAG == 1){
		bw.write("\n");
		bw.write("Error pairs (wrongly decided by the user):\n");
		for(int i=0; i<AlgorithmSMT.errorPair; i++){
			if(AlgorithmSMT.errorEli[i] != null){
				bw.write(AlgorithmSMT.errorEli[i]);
			}
			bw.write("\n");
		}}
		bw.write("\n");
		int temp = ElicitPairs.elicitedPairs;
		bw.write("\nTotal pairs elicited by the user: " + temp);
		bw.write("\n");
		temp = AlgorithmSMT.errorPair;
		if(mainGUI.GSFLAG == 1){
		bw.write("Number of pairs elicited wrongly by the user: " + temp);
		bw.write("\n");
		float tmp = (float)((float)(AlgorithmSMT.errorPair * 100.00)/ElicitPairs.elicitedPairs);
		bw.write("Percentage/probability of user error: " + tmp);
		bw.write("\n");}
		bw.write("\n");
		bw.write("Total Prioritization time: " + SMTMain.TOTAL_PRIO_TIME + "s" + "\n");
		bw.write("Total duration of elicitation session: " + SMTMain.TOTAL_ELI_TIME + "s" + "\n");
		bw.write("Minimum elicitation time for a pair: " + SMTMain.MIN_ELI_TIME + "s" + "\n");
		bw.write("Maximum elicitation time for a pair: " + SMTMain.MAX_ELI_TIME + "s" + "\n");
		bw.write("Average elicitation time for all pairs: " + SMTMain.AVG_ELI_TIME + "s" + "\n");
		bw.write("\n");
		bw.write("\n");
		bw.write("FBK IRST, CIT!!!");
		bw.close();
		
		FileWriter fstream1 = new FileWriter(mainGUI.OutPath+"smt/results/finalorder_smt.out");
		BufferedWriter out1 = new BufferedWriter(fstream1);
		for(int i=0; i<SMTMain.NUM_REQ; i++){
			for(int j=0; j<SMTMain.NUM_REQ; j++){
				int tmp1 = Integer.parseInt(((GetPriority.listNodes[0][j]).substring(2)));
				int tmp2 = Integer.parseInt((finalOrdering[i].substring(2))); 
				if( tmp1 == tmp2 )
					out1.write(Integer.toString(i+1) + ": "+GetPriority.listNodes[0][j] + " {" + GetPriority.listReq[0][j] +"}\n");
			}
		}
		out1.flush();
		out1.close();
		
		FileWriter fstream2 = new FileWriter(mainGUI.OutPath+"smt/results/eli_smt.out");
		BufferedWriter out2 = new BufferedWriter(fstream2);
		out2.write("Elicited pair" + "\t" + "Wrong???"+ "\t"+ "Eli_Time(in Sec)"+ "\t"+ "Cumulative_Eli_Time(in Sec)"+ "\n");
		for(int i=0; i<ElicitPairs.elicitedPairs; i++){
			String flag = null;
			if(AlgorithmSMT.eliOrderFlag[i] == 1)
				flag = "yes";
			else if(AlgorithmSMT.eliOrderFlag[i] == 0)
				flag = "no";
			out2.write(ElicitPairs.elicitedPairList.get(i) + "\t\t" + flag+ "\t\t\t"+ AlgorithmSMT.ELI_INDV_TIME[i] + "\t\t\t\t\t"+ AlgorithmSMT.ELI_CUMUL_TIME_SUM[i]+ "\n");
		}
		out2.write("\n\nSession details for the Elicited Pairs: \n\n");
		for(int i=0; i<ElicitPairs.elicitedPairs; i++){
			if(ElicitPairs.ELI_SESSION[i][0] != null){
				out2.write("\nSession: "+ Integer.toString(i+1) + "\n");
				out2.write(ElicitPairs.ELI_SESSION[i][0] + "\t\t" + ElicitPairs.ELI_SESSION[i][1]+ "\n");
			}
		}
		out2.write("\n***{Pairs elicited in each session} [\\t] {Total time (in sec.) for that session}\n");
		out2.flush();
		out2.close();
		System.out.println("Finished calculating disagreement for SMT...");
		return 0;
	}	
}