package smt.prio;

import pack.gui.mainGUI;

public class BuildPriorityGraph{
	
	public static int[][][] adjacencyMatrix = new int[mainGUI.TOTPRIO][SMTMain.NUM_REQ][SMTMain.NUM_REQ];
	float[] prDiff = new float[SMTMain.NUM_REQ];
	public BuildPriorityGraph(){}

public void BuildPrioGraph(){
	System.out.println("Building /Prio/ graph for SMT...");
	for(int x=0; x<mainGUI.TOTPRIO; x++){
	for(int i=0; i<SMTMain.NUM_REQ; i++){
		int basePr = GetPriority.nodesPriority[x][i];
		for(int j=0; j<SMTMain.NUM_REQ; j++)
			prDiff[j] = GetPriority.nodesPriority[x][j] - basePr;
		float min = 9999;
		for(int j=0; j<prDiff.length; j++){
			if(prDiff[j] != 0 && prDiff[j] >0 && min > prDiff[j])
				min = prDiff[j];
		}
		for(int j=0; j<prDiff.length; j++){
			if(prDiff[j] == min){
				int S = Integer.parseInt(GetPriority.listNodes[x][i].substring(2, 5));
				int D = Integer.parseInt(GetPriority.listNodes[x][j].substring(2, 5));
				adjacencyMatrix[x][S-1][D-1] = 1;
				adjacencyMatrix[x][D-1][S-1] = -1;
			}
		}
	}
	}
	for(int x=0; x<mainGUI.TOTPRIO; x++){
	for(int i=0; i<SMTMain.NUM_REQ; i++){
		for(int j=0; j<SMTMain.NUM_REQ; j++){
			if(adjacencyMatrix[x][i][j] == 1){
				for(int k=0; k<SMTMain.NUM_REQ; k++){
					if(adjacencyMatrix[x][j][k] == 1){
						adjacencyMatrix[x][i][k] = 1;
						adjacencyMatrix[x][k][i] = -1;
					}
				}
			}
		}
	}
	}
	System.out.println("Finished building /Prio/ graph for SMT...");
}
}