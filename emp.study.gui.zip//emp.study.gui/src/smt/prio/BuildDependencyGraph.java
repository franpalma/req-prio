package smt.prio;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;

public class BuildDependencyGraph{

public static int[][][] depndencyMatrix = new int[mainGUI.TOTDEP][SMTMain.NUM_REQ][SMTMain.NUM_REQ];

public void buildDepGraph(int x, int y, int z, String x1) throws IOException{
	System.out.println("Building 'Dep' graph for SMT...");
	String prepath = mainGUI.InPath;
	String postpath = "/dep/";	
	for(int xx=0; xx<mainGUI.TOTDEP; xx++){
		String filepath = prepath + x1 + postpath + SMTMain.DEPFILEs.get(xx);
		FileInputStream FStream = new FileInputStream(filepath);
		DataInputStream In = new DataInputStream(FStream);
		BufferedReader Br = new BufferedReader(new InputStreamReader(In));
		String strLine;
	while ((strLine = Br.readLine()) != null){
		String[] temp = strLine.split(" ");
		int tempSIZE = temp.length;
		int dstDep = Integer.parseInt(temp[0].substring(2, 5));
			for(int i=1; i<tempSIZE; i++){
				int srcDep = Integer.parseInt(temp[i].substring(2, 5));
				depndencyMatrix[xx][srcDep-1][dstDep-1] = 1;
				depndencyMatrix[xx][dstDep-1][srcDep-1] = -1;
		}
	}
	}
	for(int xx=0; xx<mainGUI.TOTDEP; xx++){
	for(int i=0; i<x; i++){
		for(int j=0; j<x; j++){
			if(depndencyMatrix[xx][i][j] == 1){
				for(int k=0; k<x; k++){
					if(depndencyMatrix[xx][j][k] == 1){
						depndencyMatrix[xx][i][k] = 1;
						depndencyMatrix[xx][k][i] = -1;
					}
				}
			}
		}
	}
	}
	System.out.println("Finished building 'Dep' graph for SMT...");
}
}