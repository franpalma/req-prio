package IAHP;
import Jama.Matrix;

public class comEigenVal{

	static double[] EVfst = new double[computeEigenVector.m];
	static double[] EVlst = new double[computeEigenVector.m];
	public void computeEigenValue(){

			Matrix M = new Matrix(buildMatrixIAHP.A, computeEigenVector.m, computeEigenVector.m);
	        Matrix E = M.times(M);
	       
		 double TotSum = 0.0;
	     for(int i=0; i<computeEigenVector.m; i++){
	    	 double Rsum = 0.0;
	    	 for(int j=0; j<computeEigenVector.m; j++)
	    		 Rsum = Rsum + E.get(i, j); 
	    	 EVfst[i] = Rsum; 
	    	 TotSum = TotSum + Rsum;
	     }
	       
	     for(int i=0; i<EVfst.length; i++)
	    	 EVfst[i] = EVfst[i]/TotSum;
	       
	      while(!equals(EVfst, EVlst)){
	    	   Matrix N = E;
	    	   M = N.times(N);
	    	   N = M;
	    	   
	    	   for(int i=0; i<EVfst.length; i++)
	        	   EVlst[i] = EVfst[i];
	    	   
	    	   TotSum = 0.0;
	    	   for(int i=0; i<computeEigenVector.m; i++){
	        	   double Rsum = 0.0;
	        	   for(int j=0; j<computeEigenVector.m; j++)
	        		   Rsum = Rsum + M.get(i, j);
	        	   EVfst[i] = Rsum; 
	        	   TotSum = TotSum + Rsum;
	           }
	           
	           for(int i=0; i<EVfst.length; i++)
	        	   EVfst[i] = EVfst[i]/TotSum;
	       }
	}
	
	static boolean equals(double[] eVfst, double[] eVlst){
		int flag=0;
		for(int i=0; i<eVfst.length; i++)
			if(eVfst[i] != eVlst[i])
				flag = 1;
		if(flag==1)
			return false;
		else
			return true;
	}
}
