package IAHP;

import java.awt.HeadlessException;
import java.io.IOException;

import javax.swing.JOptionPane;
import javax.swing.UnsupportedLookAndFeelException;

import pack.gui.mainGUI;

public class buildMatrixIAHP {
	public static double[] ELI_CUMUL_TIME_SUM = new double[mainGUI.MAX_ELI_PAIR];
	public static double[] ELI_INDV_TIME = new double[mainGUI.MAX_ELI_PAIR];
	public static int[] eliOrderFlag = new int[mainGUI.MAX_ELI_PAIR];
	public static String[] finalReqOrder = new String[IAHP.NUM_REQ];
	public static int eliDisagr = 0;
	public static double[][] A = new double[IAHP.NUM_REQ][IAHP.NUM_REQ], A_temp = new double[IAHP.NUM_REQ][IAHP.NUM_REQ];
	public static int[] errorDone = new int[(IAHP.NUM_REQ*(IAHP.NUM_REQ-1))/2];//, gSP = new int[IAHP.NUM_REQ];
	public static String errorEli[] = new String[mainGUI.MAX_ELI_PAIR];
	public static String startNode, endNode;
	public static String[] elicitedPairs = new String[mainGUI.MAX_ELI_PAIR];
	public static int nn=0, eliflag=0;
	public buildMatrixIAHP() {}
	
	public void builddoubleMatrix(int minV, int maxV) throws NumberFormatException, IOException, HeadlessException, ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
		System.out.println("Starting building initial intensity matrix for IAHP...");
		if(eliflag==0){
			JOptionPane.showMessageDialog(null, "Entering into Interactive session...       \n\nPress OK to continue...  \n\n"); eliflag=1;
		}
		String S, D;
		//DecimalFormat fmtObj = new DecimalFormat("####0.000000");
		//int minLen = getGoldStd.gS.length/4, tag = 1, incrementor = 2;
		startNode = initReqOrder.reqOrder[0];
		endNode = initReqOrder.reqOrder[IAHP.NUM_REQ-1];		
		//gSP[0] = tag;
		//tag = tag + incrementor;
		//for(int i=1; i<gSP.length; i++){
		//	gSP[i] = tag;
		//	if(i%minLen == 0)
		//		tag = tag + incrementor;
		//}

		//int dS=0, dD=0, d;
		//double intensity=0.0;
	
		for(int i=0; i<IAHP.NUM_REQ; i++){
			for(int j=i; j<IAHP.NUM_REQ; j++){
				if(i==j){
					A[i][j] = 1.0;
					break;
				}
			}
		}
		
		for(int i=0; i<IAHP.NUM_REQ-1; i++)	{
			S= initReqOrder.reqOrder[i];
			D= initReqOrder.reqOrder[i+1];
			StringBuilder sb = new StringBuilder();
			sb.append(S + "-"+D + "\t");
			elicitPairs.doElicitPairs(S, D, i, i+1, minV, maxV);
			elicitPairs.ELI_SESSION[i][0] = sb.toString();
			elicitPairs.ELI_SESSION[i][1] = Double.toString(IAHP.ELI_END_TIME - IAHP.ELI_START_TIME);
			
			if((IAHP.NoOfElicitedPair >= mainGUI.MAX_ELI_PAIR)){
				break;
			}
			/*else{
				String str = initReqOrder.reqOrder[i] + " " + initReqOrder.reqOrder[i+1];
				buildMatrixIAHP.elicitedPairs[IAHP.NoOfElicitedPair] = str;
				IAHP.NoOfElicitedPair++;
				IAHP.graph.addEdge(initReqOrder.reqOrder[i],initReqOrder.reqOrder[i+1]);
				IAHP.graph.addEdge(initReqOrder.reqOrder[i+1],initReqOrder.reqOrder[i]);						
				A[i][i+1] = Double.parseDouble((fmtObj.format(intensity)));
				A[i+1][i] = Double.parseDouble((fmtObj.format(1.0/intensity)));
			}*/
			nn++;
			}
		System.out.println("Finished building initial intensity matrix for IAHP...");
		}
}
