package IAHP;
import pack.gui.mainGUI;


public class buildPriorityGraph {

	public static int[][][] adjacencyMatrix = new int[mainGUI.TOTPRIO][IAHP.SEQ_REQ][IAHP.SEQ_REQ];
	int[] prDiff = new int[IAHP.NUM_REQ];
	
	public buildPriorityGraph(){}
	public void buildPrioGraph(){
		System.out.println("Building 'Prio' graph for IAHP...");
		for(int x=0; x<mainGUI.TOTPRIO; x++){
		for(int i=0; i<IAHP.NUM_REQ; i++)	{
			int basePr = getPriority.nodesPriority[x][i];
			for(int j=0; j<IAHP.NUM_REQ; j++)
				prDiff[j] = getPriority.nodesPriority[x][j] - basePr;
			int min = 9999;
			for(int j=0; j<prDiff.length; j++)	{
				if(prDiff[j] != 0 && prDiff[j] >0 && min > prDiff[j])
					min = prDiff[j];
			}
			for(int j=0; j<prDiff.length; j++)	{
				if(prDiff[j] == min){
					int S = Integer.parseInt(getPriority.listNodes[x][i].substring(2, 5));
					int D = Integer.parseInt(getPriority.listNodes[x][j].substring(2, 5));
					adjacencyMatrix[x][S-1][D-1] = 1;
					adjacencyMatrix[x][S-1][D-1] = -1;
				}
			}
		}
	}
		System.out.println("Finished building 'Prio' graph for IAHP...");
	}
}
