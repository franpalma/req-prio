/**
 * 
 */
package IAHP;

import java.awt.HeadlessException;
import java.io.IOException;
import java.text.DecimalFormat;

import javax.swing.UnsupportedLookAndFeelException;

import org.apache.commons.lang.ArrayUtils;

import pack.gui.mainGUI;

import Jama.Matrix;
/**
 * @author Francis
 */
public class normDerivative{
	
	DecimalFormat fmtObj = new DecimalFormat("####0.000000");
	double[][] NORM = new double[IAHP.NUM_REQ][IAHP.NUM_REQ], I = new double[IAHP.NUM_REQ][IAHP.NUM_REQ], Dr = new double[IAHP.NUM_REQ][IAHP.NUM_REQ];	
	static double[][] e = new double[1][IAHP.NUM_REQ];
	int x, y;
	
	public int calculatenormDerivative(int minV, int maxV) throws IOException, HeadlessException, ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
		System.out.println("Finding next candidate-pair to be elicited by IAHP...");

		
		for(int i=0; i<IAHP.NUM_REQ; i++){
			for(int j=0; j<IAHP.NUM_REQ; j++){
				NORM[i][j] = IAHP.zeroVal; I[i][j] = IAHP.zeroVal; Dr[i][j] = IAHP.zeroVal;
			}
		}
				
		for(int i=0; i<IAHP.NUM_REQ; i++){
			for(int j=i; j<IAHP.NUM_REQ; j++){
				if(j > i)
					Dr[i][j] = (computeEigenVector.y[i][0] * computeEigenVector.x[j][0]) - (computeEigenVector.y[j][0] * computeEigenVector.x[i][0]) / (buildMatrixIAHP.A_temp[i][j] * buildMatrixIAHP.A_temp[i][j]);
			}
		}
	
		for(int i=0; i<IAHP.NUM_REQ; i++){
			for(int j=0; j<IAHP.NUM_REQ; j++){
				if(i == j)
					I[i][j] = 1;
				else
					continue;
			}
		}
		
		for(int i=0; i<IAHP.NUM_REQ; i++)
			e[0][i] = 1;
		
		Matrix tmpA = new Matrix(buildMatrixIAHP.A_temp).getMatrix(0, IAHP.NUM_REQ-2, 0, IAHP.NUM_REQ-1);
		Matrix tmpI = new Matrix(I).getMatrix(0, IAHP.NUM_REQ-2, 0, IAHP.NUM_REQ-1);
		Matrix tmpDr = new Matrix(Dr).getMatrix(0, IAHP.NUM_REQ-2, 0, IAHP.NUM_REQ-1);
				
		for(int i=0; i<IAHP.NUM_REQ; i++){
			for(int j=0; j<IAHP.NUM_REQ; j++){
				double[][] Z = new double[IAHP.NUM_REQ][1];
				String pair =  initReqOrder.reqOrder[i] + " " + initReqOrder.reqOrder[j];
				boolean contains = ArrayUtils.contains(buildMatrixIAHP.elicitedPairs, pair);
				int elicitflag = 1;
				if(contains)
					elicitflag = 0;
				if(j > i && elicitflag == 1){
					Z[i][0] = computeEigenVector.x[j][0];
					Z[j][0] = ((double)-1.0 * computeEigenVector.x[i][0]) / (buildMatrixIAHP.A_temp[i][j] * buildMatrixIAHP.A_temp[i][j]);
				
					Matrix D1 = tmpA.minus(tmpI.times(computeEigenVector.D));
					double[][] tmp = new double[IAHP.NUM_REQ][IAHP.NUM_REQ];
										for(int s=0; s<IAHP.NUM_REQ-1; s++)
						for(int t=0; t<IAHP.NUM_REQ; t++)
							tmp[s][t] = D1.get(s, t);
										for(int l=IAHP.NUM_REQ-1; l>=IAHP.NUM_REQ-1; l--){
						for(int n=0; n<IAHP.NUM_REQ; n++)
							tmp[l][n] = e[0][n];
					}
										Matrix tmpZ = new Matrix(Z).getMatrix(0, IAHP.NUM_REQ-2, 0, 0);
					Matrix tmpD2 = new Matrix(tmp);
					Matrix D2 = Matrix.identity(IAHP.NUM_REQ, IAHP.NUM_REQ);
					Matrix D22 = tmpD2.solve(D2);
					double[][] tmpX = new double[IAHP.NUM_REQ][1];
					for(int f=0; f<computeEigenVector.x.length; f++)
						tmpX[f][0] = computeEigenVector.x[f][0];
					Matrix y1 = new Matrix(tmpX);
					Matrix tmpd3 = (tmpDr.times(y1));
					Matrix tmpD3 = tmpd3.minus(tmpZ);
										double[][] tempD3 = new double[1][IAHP.NUM_REQ];
					for(int s=0; s<IAHP.NUM_REQ-1; s++)//
						tempD3[0][s] = tmpD3.get(s, 0);
					tempD3[0][IAHP.NUM_REQ-1] = 0.0;
										Matrix D3 = new Matrix(tempD3);
					double[][] tempd3 = new double[IAHP.NUM_REQ][1];
					for(int q=0; q<D3.getColumnDimension(); q++)
						tempd3[q][0] = D3.get(0, q);
					Matrix D33 = new Matrix(tempd3);
					
					Matrix tmpNORM = D22.times(D33);
										double maxValue = IAHP.zeroVal;
					for(int p=0; p<IAHP.NUM_REQ; p++){
						for(int q=0; q<1; q++){
							double tmpV = tmpNORM.get(p, q);
							if(tmpV < 0.0)
								tmpV = tmpV * -1.0;
							if(tmpV >= maxValue)
								maxValue = tmpV;						
						}
					}
					if(!(buildMatrixIAHP.A[i][j] > (double)0.0))
						NORM[i][j] = Double.parseDouble((fmtObj.format(maxValue))); 
				}
			}
		}
		double max_norm_val = 0.0; 
		max_norm_val = NORM[0][0];
		for(int a=0; a<IAHP.NUM_REQ; a++){
			for(int b=a; b<IAHP.NUM_REQ; b++){
				if((NORM[a][b] >= max_norm_val)){
					max_norm_val = NORM[a][b]; x=a; y=b;
				}
			}
		}
		//double intensity = 0.0;
		//buildMatrixIAHP.nn++;			
		//String S1= initReqOrder.reqOrder[x];
		//String D1= initReqOrder.reqOrder[y];
		//int sFlag = 0, dFlag = 0, dS=0, dD=0, d;
		
		/*for(int k=0; k<getGoldStd.gS.length;k++){
			if(S1.equals(getGoldStd.gS[k]) && sFlag == 0){
				dS = k; sFlag = 1;
			}
			if(D1.equals(getGoldStd.gS[k]) && dFlag == 0){
				dD = k; dFlag = 1;
				}
			if((dS > dD) && (sFlag == 1) && (dFlag == 1)) {
				d = dS - dD; 
				intensity = 1.0/(double)buildMatrixIAHP.gSP[d];}//changed here lastly
			else if((dD >= dS) && (sFlag == 1) && (dFlag == 1)) {
				d = (dD - dS); 
				intensity = (double)buildMatrixIAHP.gSP[d];}
		}*/
		
		String str = initReqOrder.reqOrder[x] + " " + initReqOrder.reqOrder[y];
		boolean contains1 = ArrayUtils.contains(buildMatrixIAHP.elicitedPairs, str);
		String str1  = initReqOrder.reqOrder[y] + " " + initReqOrder.reqOrder[x];
		boolean contains2 = ArrayUtils.contains(buildMatrixIAHP.elicitedPairs, str1);
					
		if(!contains1 && !contains2){
			StringBuilder sb = new StringBuilder();
			sb.append(initReqOrder.reqOrder[x] + "-"+initReqOrder.reqOrder[y] + "\t");
			elicitPairs.doElicitPairs(initReqOrder.reqOrder[x], initReqOrder.reqOrder[y], x, y, minV, maxV);
			elicitPairs.ELI_SESSION[IAHP.NoOfElicitedPair-1][0] = sb.toString();
			elicitPairs.ELI_SESSION[IAHP.NoOfElicitedPair-1][1] = Double.toString(IAHP.ELI_END_TIME - IAHP.ELI_START_TIME);
		}
				
		if((IAHP.NoOfElicitedPair >= mainGUI.MAX_ELI_PAIR))
			return 0;
		
		return 0;
	}
}