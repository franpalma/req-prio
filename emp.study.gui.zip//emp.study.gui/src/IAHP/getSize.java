package IAHP;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;

public class getSize {
	public static int populationSIZE;
	public getSize() {}
	//getting the population size 
	public int getPopulationSize(String x1) throws IOException{
		System.out.println("Getting number of requirements...");
		String prepath = mainGUI.InPath;
		String postpath = "/prio/0priority.txt";
		String inputfile = prepath + x1 + postpath;
		FileInputStream fstream = new FileInputStream(inputfile);
		DataInputStream in = new DataInputStream(fstream);
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		int totalElement = 0;
		//counting the total nodes in the file
		while ((br.readLine()) != null)	{
			totalElement++;
		}
		in.close();
		populationSIZE = totalElement;
		return populationSIZE;
	}
}
