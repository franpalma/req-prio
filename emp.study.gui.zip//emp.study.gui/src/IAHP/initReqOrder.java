/**
 * 
 */
package IAHP;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;

public class initReqOrder {
	public static String[] reqOrder = new String[IAHP.NUM_REQ];
	public void initializePopulation(String x1) throws IOException{
		System.out.println("Initializing primary requirements order for IAHP...");
		FileInputStream Fstream = null;
		String prepath = mainGUI.InPath;
		String postpath = "/oth/reqOrd.txt";
		String filepath = prepath + x1 + postpath;
		Fstream = new FileInputStream(filepath);		
		DataInputStream IN = new DataInputStream(Fstream);
		BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
		
	String strLine;
	while((strLine = BR.readLine()) != null){
		String[] temp = new String[IAHP.NUM_REQ];
		temp = strLine.split(" ");
		for(int j=0; j<temp.length; j++)
			reqOrder[j] = temp[j];
	}
	BR.close();	IN.close();	Fstream.close();
	}
}