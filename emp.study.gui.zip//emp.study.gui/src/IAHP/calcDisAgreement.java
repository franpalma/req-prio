package IAHP;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import pack.gui.mainGUI;


public class calcDisAgreement {
	
	
	public void rSort(){
		
		for(int i=0; i<IAHP.NUM_REQ; i++)
			buildMatrixIAHP.finalReqOrder[i] = initReqOrder.reqOrder[i];
		
		for(int i=0; i<comEigenVal.EVfst.length; i++){
			for(int j=0; j<comEigenVal.EVfst.length-1; j++){
				if(comEigenVal.EVfst[j] < comEigenVal.EVfst[j+1]){
					double temp = comEigenVal.EVfst[j];
					comEigenVal.EVfst[j] = comEigenVal.EVfst[j+1];
					comEigenVal.EVfst[j+1] = temp;
					String temp0 = buildMatrixIAHP.finalReqOrder[j];
					buildMatrixIAHP.finalReqOrder[j] = buildMatrixIAHP.finalReqOrder[j+1];
					buildMatrixIAHP.finalReqOrder[j+1] = temp0;
				}
			}
		}
	}
	
	public void calDisagreement() throws IOException{
	System.out.println("Calculating disagreement for IAHP...");
	buildMatrixIAHP.eliDisagr = 0;
	int indexStd1=0, indexStd2=0;
	for(int i=0; i<getGoldStd.gS.length-1; i++){
		for(int j=i+1; j<getGoldStd.gS.length; j++){
			for(int t=0; t<getGoldStd.gS.length; t++){
				if(buildMatrixIAHP.finalReqOrder[i].toString().equalsIgnoreCase(getGoldStd.gS[t]))
						indexStd1 = t;
				if(buildMatrixIAHP.finalReqOrder[j].toString().equalsIgnoreCase(getGoldStd.gS[t]))
						indexStd2 = t;
			}
			if(indexStd1 > indexStd2)
				buildMatrixIAHP.eliDisagr = buildMatrixIAHP.eliDisagr + 1;
		}
	}
	String filepath = mainGUI.OutPath + "/iahp/results/iahp.out";
	FileWriter fstream = new FileWriter(filepath,true);
	BufferedWriter out = new BufferedWriter(fstream);
	out.write("\n");
	out.write(">INCOMPLETE-AHP PRIORITIZATION<");
	out.write("\n\n");
	out.write("Final Ordering: \n");
	for(int i=0;i<buildMatrixIAHP.finalReqOrder.length;i++)
		out.write(buildMatrixIAHP.finalReqOrder[i] + " ");
	out.write("\n\n");
	out.write("Disagreement with GS: ");
	out.write(buildMatrixIAHP.eliDisagr+"\n");
	out.flush();
	out.close();
	System.out.println("Finished calculating disagreement for IAHP...");
	}
}