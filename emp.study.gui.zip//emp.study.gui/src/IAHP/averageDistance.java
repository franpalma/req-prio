package IAHP;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import pack.gui.mainGUI;

public class averageDistance {
	
	public void calculateAverageDistance(String[] finalOrd) throws IOException{
		System.out.println("Calculating Average Distance (AD) for IAHP...");
		//average distance
		int indxIndv, indxGS = 0, indxDiff, diffSum=0;
		float avgDiff = (float) 0.0, avgDist = (float) 0.0;
		String tmp;
		double avgDistIAHP = 0.0;
		for(int i=0; i<IAHP.NUM_REQ; i++){
			diffSum = 0;
			for(int j=0; j<IAHP.NUM_REQ; j++){
				tmp = finalOrd[j];
				indxIndv = j;
				for(int k=0; k<IAHP.NUM_REQ; k++){
					if(tmp.equalsIgnoreCase(getGoldStd.gS[k])){
						indxGS = k;
						break;}
				}
				if(indxIndv < indxGS)
					indxDiff = indxGS - indxIndv;
				else
					indxDiff = indxIndv - indxGS;
				avgDistIAHP = avgDistIAHP + 1.0;
				diffSum = diffSum + indxDiff;
			}
			avgDiff = (float)diffSum/IAHP.NUM_REQ;
			avgDist = (float)avgDiff;			
		}
		
		String filepath = mainGUI.OutPath + "/iahp/results/iahp.out";
		FileWriter fstream = new FileWriter(filepath, true);
		BufferedWriter out = new BufferedWriter(fstream);
		out.write("\n");
		out.write("Average Distance with GS: ");
		out.write(avgDist+"\n");

		out.write("\n");
		out.write("Pairs decided by the user: \n");
		for(int i=0; i<buildMatrixIAHP.elicitedPairs.length; i++){
			if(buildMatrixIAHP.elicitedPairs[i] != null){
				out.write(buildMatrixIAHP.elicitedPairs[i]);
			}
			out.write("\n");
		}
		out.write("\n");
		out.write("Error pairs (wrongly decided by the user):\n");
		for(int i=0; i<IAHP.errorPair+1; i++){
			if(buildMatrixIAHP.errorEli[i] != null){
				out.write(buildMatrixIAHP.errorEli[i]);
			}
			out.write("\n");
		}
		out.write("\n");
		int temp = IAHP.NoOfElicitedPair;
		out.write("\nTotal pairs elicited by the user: " + temp);
		out.write("\n");
		temp = IAHP.errorPair;
		out.write("Number of pairs elicited wrongly by the user: " + temp);
		out.write("\n");
		float tmp1 = (float)((float)(IAHP.errorPair * 100.00)/IAHP.NoOfElicitedPair);
		out.write("Percentage/probability of user error: " + tmp1);
		out.write("\n");
		out.write("\n");
		out.write("Total Prioritization time: " + IAHP.TOTAL_PRIO_TIME + "s" + "\n");
		out.write("Total duration of elicitation session: " + IAHP.TOTAL_ELI_TIME + "s" + "\n");
		out.write("Minimum elicitation time for a pair: " + IAHP.MIN_ELI_TIME + "s" + "\n");
		out.write("Maximum elicitation time for a pair: " + IAHP.MAX_ELI_TIME + "s" + "\n");
		out.write("Average elicitation time for all pairs: " + IAHP.AVG_ELI_TIME + "s" + "\n");
		out.write("\n");
		out.write("\n");
		out.write("FBK IRST, CIT!!!");
		out.flush();
		out.close();
		
		FileWriter fstream2 = new FileWriter(mainGUI.OutPath+"iahp/results/eli_iahp.out");
		BufferedWriter out2 = new BufferedWriter(fstream2);
		out2.write("Elicited pair" + "\t" + "Wrong???"+ "\t"+ "Eli_Time(in Sec)"+ "\t"+ "Cumulative_Eli_Time(in Sec)"+ "\n");
		for(int i=0; i<IAHP.NoOfElicitedPair; i++){
			String flag = null;
			if(buildMatrixIAHP.eliOrderFlag[i] == 1)
				flag = "yes";
			else if(buildMatrixIAHP.eliOrderFlag[i] == 0)
				flag = "no";
			out2.write(buildMatrixIAHP.elicitedPairs[i] + "\t\t" + flag+ "\t\t\t"+ buildMatrixIAHP.ELI_INDV_TIME[i] + "\t\t\t\t\t"+ buildMatrixIAHP.ELI_CUMUL_TIME_SUM[i]+ "\n");
		}
		out2.write("\n\nSession details for the Elicited Pairs: \n\n");
		for(int i=0; i<IAHP.NoOfElicitedPair; i++){
			if(elicitPairs.ELI_SESSION[i][0] != null){
				out2.write("\nSession: "+ Integer.toString(i+1) + "\n");
				out2.write(elicitPairs.ELI_SESSION[i][0] + "\t\t" + elicitPairs.ELI_SESSION[i][1]+ "\n");
			}
		}
		out2.write("\n***{Pairs elicited in each session} [\\t] {Total time (in sec.) for that session}\n");
		out2.flush();
		out2.close();
		System.out.println("Finished calculating Average Distance (AD) for IAHP...");
	}
}