/**
 * 
 */
package IAHP;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import pack.gui.mainGUI;

public class getGoldStd {	
	public static String[] gS = new String[IAHP.NUM_REQ];
	
	public getGoldStd(){
		
	}
	
	public void getGoldS(String x1) throws IOException{
		System.out.println("Getting Gold Standard (GS)...");
		
		String prepath = mainGUI.InPath;
		String postpath = "/oth/eliOrd.txt";
		String filepath = prepath + x1 + postpath;
		FileInputStream Fstream = new FileInputStream(filepath);
		DataInputStream IN = new DataInputStream(Fstream);
		BufferedReader BR = new BufferedReader(new InputStreamReader(IN));
		String strLine = null;
		while ((strLine = BR.readLine()) != null){		
			String[] tempeli = new String[IAHP.NUM_REQ];
			tempeli = strLine.split(" ");
			for(int i=0; i<tempeli.length; i++)
				getGoldStd.gS[i] = tempeli[i];
		}
		filepath = mainGUI.OutPath + "/iahp/results/iahp.out";
		FileWriter fstream = new FileWriter(filepath,true);
		BufferedWriter out = new BufferedWriter(fstream);
		out.write("\n");
		out.write("Gold Standard: \n");
		for(int i=0;i<getGoldStd.gS.length;i++)
			out.write(getGoldStd.gS[i] + " ");
		out.write("\n");
		out.flush();
		out.close();
	}
}