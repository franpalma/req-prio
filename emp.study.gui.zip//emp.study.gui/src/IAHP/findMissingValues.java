/**
 * 
 */
package IAHP;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.LinkedList;

public class findMissingValues {
	DecimalFormat fmtObj = new DecimalFormat("####0.000000");
	public static String src, dest;
	
	public void findMissingValue() throws IOException{
	System.out.println("Finding missing values of the matrix for IAHP...");

		for(int i=0; i<IAHP.NUM_REQ; i++){
			for(int j=0; j<IAHP.NUM_REQ; j++){
				buildMatrixIAHP.A_temp[i][j] = Double.parseDouble((fmtObj.format(buildMatrixIAHP.A[i][j])));
			}
		}
		
		for(int k=2; k<IAHP.NUM_REQ; k++){
			for(int i=0, j=k; i<IAHP.NUM_REQ-1 && j<IAHP.NUM_REQ; i++, j++){
				if(buildMatrixIAHP.A_temp[i][j] != 0.0)
					continue;
				else{
					src  = initReqOrder.reqOrder[i]; dest = initReqOrder.reqOrder[j];
					LinkedList<String> visited = new LinkedList();
					double missingVal;
					visited.add(src);
					missingVal = new Search().breadthFirst(IAHP.graph, visited, src);
					//System.out.println("missingVal: " + missingVal);
					buildMatrixIAHP.A_temp[i][j] = Double.parseDouble((fmtObj.format((double)missingVal)));
					buildMatrixIAHP.A_temp[j][i] = Double.parseDouble((fmtObj.format(((double)1.0/missingVal))));
				}
			}
		}
		//**BufferedWriter bw1 = new BufferedWriter(new FileWriter("../IAHP/Resources/filledA.txt", true));
		//**bw1.write("\n");
		//**bw1.write("Loop" + IAHP.count);
		//**bw1.write("\n");
		//**for(int p=0; p<IAHP.NUM_REQ; p++){
		//**for(int q=0; q<IAHP.NUM_REQ; q++){
				//**bw1.write(Double.toString(buildMatrixIAHP.A[p][q]));
				//**bw1.write("\t");				
		//**}
			//**bw1.write("\n");
		//**}
		//**bw1.flush();
		//**bw1.close();
		System.out.println("Finished finding missing values of the matrix for IAHP...");
	}
	/*public void printPath(LinkedList<String> visitedtmp){        
		for (String node : visitedtmp){            
			System.out.print(node);            
			System.out.print("->");        
		}        
		System.out.println();  }*/
}
