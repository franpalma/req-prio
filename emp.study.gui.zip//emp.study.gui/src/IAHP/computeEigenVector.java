/**
 * 
 */
package IAHP;

import java.text.DecimalFormat;

import Jama.Matrix;
import Jama.EigenvalueDecomposition;
/**
 * @author Francis
 *
 */
public class computeEigenVector{
	
	static final int m = IAHP.NUM_REQ;
	public static Matrix X, Y;
	public static double[][] x=new double[IAHP.NUM_REQ][1], y = new double[IAHP.NUM_REQ][1];
	public static double D;
	DecimalFormat fmtObj = new DecimalFormat("####0.000000");
	computeEigenVector(){}
	
	public void computeEigenVec(){
		Matrix M = new Matrix(buildMatrixIAHP.A_temp,m,m);
		Matrix transM = M.transpose();
		
		EigenvalueDecomposition e = M.eig();
		EigenvalueDecomposition etrans = transM.eig();
		
		X = e.getV(); //right eigen vector x
		for(int i=0; i<X.getRowDimension(); i++)
			x[i][0] = Double.parseDouble((fmtObj.format(X.get(i, 0))));
		
		Y = etrans.getV(); //left eigen vector of transpose y
		for(int i=0; i<Y.getRowDimension(); i++)
			y[i][0] = Double.parseDouble((fmtObj.format(-1 * Y.get(i, 0))));

		D = Double.parseDouble((fmtObj.format(e.getD().get(0, 0))));
	}
}
