
package IAHP;

import java.awt.HeadlessException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.UnsupportedLookAndFeelException;

import pack.gui.mainGUI;

//7
public class IAHP {
	public static ArrayList<String> PRIOFILEs = new ArrayList<String>();
	public static ArrayList<String> DEPFILEs = new ArrayList<String>();
	public static double TOTAL_ELI_TIME=0, TOTAL_PRIO_TIME, START_TIME, END_TIME=0, ELI_START_TIME, ELI_END_TIME, MAX_ELI_TIME=0.0, MIN_ELI_TIME=9999, AVG_ELI_TIME;
	public static int NUM_REQ, SEQ_REQ, errorPair=0;
	public static int percentDone = 0, countErrorPair=0, count = 1, NoOfElicitedPair = 0;
	public static Graph graph = new Graph();
	public static double zeroVal = 0.0;
	public IAHP(){}
	public void main(String string, int minV, int maxV) throws IOException, HeadlessException, ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
		System.out.println("Starting Main module of IAHP...");
		IAHP.START_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
	
		//get prio count
		final File priofolder = new File(mainGUI.PROJECT_PATH+"in/"+mainGUI.x1+"/prio/");
		File[] priolistOfFiles = priofolder.listFiles();
		mainGUI.TOTPRIO = priolistOfFiles.length;
		for (int i = 0; i < priolistOfFiles.length; i++){
		    File fileEntry = priolistOfFiles[i];
		    if (!fileEntry.isDirectory()){
		        PRIOFILEs.add(fileEntry.getName());
		    }
		}
		//get dep count
		final File depfolder = new File(mainGUI.PROJECT_PATH+"in/"+mainGUI.x1+"/dep/");
		File[] deplistOfFiles = depfolder.listFiles();
		mainGUI.TOTDEP = deplistOfFiles.length;
		for (int i = 0; i < deplistOfFiles.length; i++){
		    File fileEntry = deplistOfFiles[i];
		    if (!fileEntry.isDirectory()){
		        DEPFILEs.add(fileEntry.getName());
		    }
		}
		
		String filepath = mainGUI.OutPath + "/iahp/results/iahp.out";
		FileWriter fstream = new FileWriter(filepath);
		fstream.close();
		
		getSize getS = new getSize();
		SEQ_REQ = NUM_REQ = getS.getPopulationSize(mainGUI.x1);
		
		if(mainGUI.GSFLAG == 1){
		getGoldStd gS = new getGoldStd();
		gS.getGoldS(mainGUI.x1);}
		
		getPriority gP = new getPriority();
		gP.getPriorityArray(mainGUI.x1);
	
		buildPriorityGraph buildGraph = new buildPriorityGraph();
		buildGraph.buildPrioGraph();
		
		buildDependencyGraph buildDpGraph = new buildDependencyGraph();
		buildDpGraph.buildDepGraph(mainGUI.x1);
	
		initReqOrder iRO = new initReqOrder();
		iRO.initializePopulation(mainGUI.x1);
		
		buildMatrixIAHP bM = new buildMatrixIAHP();
		bM.builddoubleMatrix(minV, maxV);
		
		
		while(NoOfElicitedPair < mainGUI.MAX_ELI_PAIR){
			findMissingValues fMV = new findMissingValues();
			fMV.findMissingValue();
			
			computeEigenVector cEV = new computeEigenVector();
			cEV.computeEigenVec();
			
			normDerivative nD = new normDerivative();
			nD.calculatenormDerivative(minV, maxV);
		}
		
		comEigenVal compEV = new comEigenVal();
		compEV.computeEigenValue();
		
		calcDisAgreement calDisAgr = new calcDisAgreement();
		calDisAgr.rSort();
		if(mainGUI.GSFLAG == 1)
			calDisAgr.calDisagreement();
		
		IAHP.END_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
		IAHP.TOTAL_PRIO_TIME = Double.parseDouble((mainGUI.fmtObj.format(IAHP.END_TIME - IAHP.START_TIME)));
		if(mainGUI.GSFLAG == 1){
		averageDistance avgD = new averageDistance();
		avgD.calculateAverageDistance(buildMatrixIAHP.finalReqOrder);}
		
		FileWriter fstream1 = new FileWriter(mainGUI.OutPath+"iahp/results/finalorder_iahp.out");
		BufferedWriter out1 = new BufferedWriter(fstream1);
		for(int i=0; i<buildMatrixIAHP.finalReqOrder.length; i++){
			if(buildMatrixIAHP.finalReqOrder[i] != null){
				for(int j=0; j<IAHP.NUM_REQ; j++){
					if(getPriority.listNodes[0][j].equalsIgnoreCase(buildMatrixIAHP.finalReqOrder[i])){
						out1.write(Integer.toString(i+1) + ": " + buildMatrixIAHP.finalReqOrder[i] + " {" + getPriority.listReq[0][j] +"}\n");
					}
				}
			}
		}
		out1.flush();
		out1.close();
		
		if(mainGUI.GSFLAG == 0){
			filepath = mainGUI.OutPath + "/iahp/results/iahp.out";
			fstream = new FileWriter(filepath,true);
			BufferedWriter out = new BufferedWriter(fstream);
			out.write("\n");
			out.write(">INCOMPLETE-AHP PRIORITIZATION<");
			out.write("\n\n");
			out.write("Final Ordering: \n");
			for(int i=0;i<buildMatrixIAHP.finalReqOrder.length;i++)
				out.write(buildMatrixIAHP.finalReqOrder[i] + " ");
			out.write("\n\n");			
			out.write("\n");
			out.write("Pairs decided by the user: \n");
			for(int i=0; i<buildMatrixIAHP.elicitedPairs.length; i++){
				if(buildMatrixIAHP.elicitedPairs[i] != null){
					out.write(buildMatrixIAHP.elicitedPairs[i]);
				}
				out.write("\n");
			}
			out.write("\n");
			out.write("\n");
			int temp = IAHP.NoOfElicitedPair;
			out.write("\nTotal pairs elicited by the user: " + temp);
			out.write("\n");
			out.write("\n");
			out.write("Total Prioritization time: " + IAHP.TOTAL_PRIO_TIME + "s" + "\n");
			out.write("Total duration of elicitation session: " + IAHP.TOTAL_ELI_TIME + "s" + "\n");
			out.write("Minimum elicitation time for a pair: " + IAHP.MIN_ELI_TIME + "s" + "\n");
			out.write("Maximum elicitation time for a pair: " + IAHP.MAX_ELI_TIME + "s" + "\n");
			out.write("Average elicitation time for all pairs: " + IAHP.AVG_ELI_TIME + "s" + "\n");
			out.write("\n");
			out.write("\n");
			out.write("FBK IRST, CIT!!!");
			out.flush();
			out.close();
			
		}
		System.out.println("Finished Main module of IAHP...");
	}
}