package IAHP;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedList;

public class Search {
	
	DecimalFormat fmtObj = new DecimalFormat("####0.000000");
	public int count;
	public double missinVal = 1.0;
	public int[] nodeVisited = new int[IAHP.NUM_REQ];
	public HashMap hm = new HashMap(); 
	public double breadthFirst(Graph graph, LinkedList<String> visited, String initnode) throws IOException {

		if(initnode.length()>0)
			hm.put(initnode.toString(), "1");
		LinkedList<String> nodes = graph.adjacentNodes(visited.getLast());
		//**BufferedWriter bw = new BufferedWriter(new FileWriter("../IAHP/Resources/graphPath.txt", true));
		//**bw.write("\n"+"Loop" + IAHP.count+"\n");
		//**bw.flush();
		//**bw.close();
		double val = 0.0;
		int infinityFlag = 0;
		for (String node : nodes){
			if (visited.contains(node)){
				hm.put(node.toString(), "1");
				continue;
			}
			if (node.equals(findMissingValues.dest)){
				count = count + 1;
				hm.put(node.toString(), "1");
				visited.add(node);
				//PATH COMPUTATION
				//printPath(visited);
				int listsize = visited.size();
				String[] strNodeArray = new String[listsize];
				double[] nodeValues = new double[listsize-1];
				
				for (int i=0; i<listsize; i++)
					strNodeArray[i] = visited.get(i);
				
				for (int i=0; i<nodeValues.length; i++){
					int indx1 = 0, indx2 = 0;
					for(int t=0; t<initReqOrder.reqOrder.length; t++){
						if(strNodeArray[i].equalsIgnoreCase(initReqOrder.reqOrder[t])) indx1 = t;
						if(strNodeArray[i+1].equalsIgnoreCase(initReqOrder.reqOrder[t])) indx2 = t;
					}
					nodeValues[i] = buildMatrixIAHP.A[indx1][indx2];
				}
				double tmpVal = 1.0;
				for (int i=0; i<nodeValues.length; i++)            
					tmpVal = tmpVal * nodeValues[i];
				int len = nodeValues.length;
				double div, tempVal;
				div = (double)1/len;
				tempVal = Math.pow(tmpVal, div);
				missinVal = missinVal * tempVal;
				
				//System.out.println("missinVal: " + missinVal);
				visited.removeLast();
				break;
			}
		}
			
		for (String node : nodes){
			if (visited.contains(node) || node.equals(findMissingValues.dest)){hm.put(node.toString(), "1");
				continue;}
			if(nodes.size() == 1 && (nodes.contains(buildMatrixIAHP.startNode) || nodes.contains(buildMatrixIAHP.endNode)))
				continue;
			
				//check if visited? if yes continue, else add in hashkey and in the path
				if(hm.get(node.toString()) == "1")
					continue;
				else{
					visited.addLast(node);
					//hm.put(node.toString(), "1");
					breadthFirst(graph, visited,"");
					visited.removeLast();
				}
		}
		
		if(count != 0)
			val = Double.parseDouble((fmtObj.format(Math.pow(missinVal, (1.0/(double)count)))));
		//System.out.println(val);
		return val;
	}    
	/*private void printPath(LinkedList<String> visited) throws IOException{
		System.out.print("\n");
		System.out.print(findMissingValues.src +", " + findMissingValues.dest);
		System.out.print("\n");
		int a=0, len = visited.size();
		for (String node : visited){
			a = a + 1;
			System.out.print(node);  
			if(a == len)
				continue;
			else
				System.out.print(">");        
		}
		System.out.print("\n");
	}*/
	/*private void printPath(LinkedList<String> visited) throws IOException{   
		BufferedWriter bw = new BufferedWriter(new FileWriter("../IAHP/Resources/graphPath.txt", true));
		bw.write("("+"R"+findMissingValues.src +", " + "R"+findMissingValues.dest+") ");
		bw.write("\n");
		int a=0, len = visited.size();
		for (String node : visited){
			a = a + 1;
			bw.write(node);  
			if(a == len)
				continue;
			else
				bw.write(" -> ");        
		}        
		bw.write("\n");
		bw.flush();
		bw.close();
	}*/
}