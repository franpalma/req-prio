package IAHP;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.text.DecimalFormat;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import pack.gui.mainGUI;

public class elicitPairs extends JDialog implements ActionListener {
	private static double intensity;
	public static String ax, bx;
	public static String[][] ELI_SESSION = new String[mainGUI.MAX_ELI_PAIR][2]; 
	static DecimalFormat fmtObj = new DecimalFormat("####0.000000");
	private static int ELICITFLAG=-1;
	//private JTabbedPane jTabbedPane1;
	//private JPanel contentPane;
	private JPanel jPanel1;// = new JPanel();
    private JPanel jPanel2;// = new JPanel();
    private JPanel jPanel3;// = new JPanel();
    private JSplitPane splitPane;
    private JSplitPane splitPane2;
	private JButton okbutton;
	//private JButton cnclbutton;
	private JRadioButton rb1, rbl3, rbl5, rbl7, rbl9, rbr3, rbr5, rbr7, rbr9;
	//private JButton jp1show;
	//private JButton jp2show;
	private static int errorflag=0;
	private JLabel priolabel1 = new JLabel("User Priority/Value ");
	private JLabel priolabel2 = new JLabel("User Priority/Value ");
	private JLabel deplabel1 = new JLabel("Depends on ");
	private JLabel deplabel2 = new JLabel("Depends on ");
	private JLabel deplabel11 = new JLabel("Depends on this.");
	private JLabel deplabel21 = new JLabel("Depends on this.");
	private JLabel reqDesc1 = new JLabel("Requirement Desc.");
	private JLabel reqDesc2 = new JLabel("Requirement Desc.");
	JTextArea area = new JTextArea();
	private JTextField priolabel1txt = new JTextField(null,10);
	private JTextField priolabel2txt = new JTextField(null,10);
	private JTextField deplabel1txt = new JTextField(null,30);
	private JTextField deplabel2txt = new JTextField(null,30);
	private JTextField deplabel11txt = new JTextField(null,30);
	private JTextField deplabel21txt = new JTextField(null,30);
	private JTextArea reqDesc1txt = new JTextArea();
	private JTextArea reqDesc2txt = new JTextArea();
	private JComponent j1;// = new JLabel(ax);
	private JComponent j2;// = new JLabel(bx);
	private JComponent j3;
	
	
	public elicitPairs(JFrame parent, String str, final int minV, int maxV)throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
	    super(parent, str, true);
	    JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
	    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

		okbutton = new JButton();
		//cnclbutton = new JButton();
		rb1=new JRadioButton(); rbl3=new JRadioButton(); rbl5=new JRadioButton(); rbl7=new JRadioButton(); rbl9=new JRadioButton();
		rbr3=new JRadioButton(); rbr5=new JRadioButton(); rbr7=new JRadioButton(); rbr9=new JRadioButton();
		//jp1show = new JButton();
		//jp2show = new JButton();
		jPanel1 = new JPanel();
		jPanel2 = new JPanel();
		jPanel3 = new JPanel();
		//jPanel1.setSize(this.WIDTH, this.HEIGHT/2);
		//jPanel2.setSize(this.WIDTH, this.HEIGHT/2);
		j1 = new JLabel(ax.toString(),SwingConstants.CENTER);
		Font f = new Font("Dialog", Font.PLAIN, 24);
		j1.setFont(f);
		j1.setBorder(BorderFactory.createTitledBorder(""));
		j2 = new JLabel(bx.toString(),SwingConstants.CENTER);
		j2.setBorder(BorderFactory.createTitledBorder(""));
		j2.setFont(f);
		//jPanel1.add(j1);
		//jPanel2.add(j2);
		j3 = new JLabel(ax.toString() + " : " + bx.toString(),SwingConstants.CENTER);
		f = new Font("Dialog", Font.PLAIN, 18);
		j3.setFont(f);
		j3.setBorder(BorderFactory.createTitledBorder(""));
		splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true, jPanel1, jPanel2);
		splitPane.setDividerSize(3);
		splitPane.setDividerLocation(.5D);
		splitPane.setResizeWeight(.5D);
		//splitPane.setSize(this.WIDTH, this.HEIGHT/2);
		splitPane2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane, jPanel3);
	    splitPane2.setDividerLocation(.5D);
	    splitPane2.setDividerSize(3);
	    splitPane2.setResizeWeight(.55D);
	    //splitPane2.setLayout(null);
		//splitPane.setOneTouchExpandable(true);
		getContentPane().add(splitPane2);
				
		jPanel1.setLayout(null);
		jPanel1.setOpaque(false);
		jPanel2.setLayout(null);
		jPanel2.setOpaque(false);
		jPanel3.setLayout(null);
		jPanel3.setOpaque(false);
		jPanel1.setBorder(BorderFactory.createRaisedBevelBorder());
		jPanel2.setBorder(BorderFactory.createRaisedBevelBorder());
		jPanel3.setBorder(BorderFactory.createRaisedBevelBorder());
		
		okbutton.setText("Elicit!");
		okbutton.setEnabled(false);
		okbutton.setMnemonic(KeyEvent.VK_E);
		okbutton.addActionListener(this);
		okbutton.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e)
		{
			okbutton_actionPerformed(e);
		}
		});	
		//cnclbutton.setText("Close");
		//cnclbutton.setMnemonic(KeyEvent.VK_C);
		//cnclbutton.addActionListener(this);
		//cnclbutton.addActionListener(new ActionListener() {
		//public void actionPerformed(ActionEvent e)
		//{
		//	cnclbutton_actionPerformed(e);
		//}
		//});	
		/*jp1show.setText("Show Detail");
		jp1show.setMnemonic(KeyEvent.VK_S);
		jp1show.addActionListener(this);
		jp1show.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e)
		{
			jp1show_actionPerformed(e);
		}
		});	
		jp2show.setText("Show Detail");
		jp2show.setMnemonic(KeyEvent.VK_T);
		jp2show.addActionListener(this);
		jp2show.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e)
		{
			jp2show_actionPerformed(e);
		}
		});	*/
		int iax = Integer.parseInt(ax.substring(2, 5))-1;
		int axpriority=9999;
		String axdescription="";
		String ax_dep_on=""; String reqs_dep_on_ax="";
		for(int i=0; i<IAHP.NUM_REQ; i++){
			if(ax.equalsIgnoreCase(getPriority.listNodes[0][i])){
				axpriority = getPriority.nodesPriority[0][i];
				axdescription = getPriority.listReq[0][i];
			}
		}
		for(int i=0; i<IAHP.SEQ_REQ; i++){
			if(buildDependencyGraph.depndencyMatrix[0][iax][i] == 1){
				if(i<9)
					reqs_dep_on_ax = reqs_dep_on_ax.concat("RT00"+Integer.toString(i+1) + " ");
				else if(i>=9 && i<99)
					reqs_dep_on_ax = reqs_dep_on_ax.concat("RT0"+Integer.toString(i+1) + " ");
				else
					reqs_dep_on_ax = reqs_dep_on_ax.concat("RT"+Integer.toString(i+1) + " ");
			}
		}
		for(int i=0; i<IAHP.SEQ_REQ; i++){
			if(buildDependencyGraph.depndencyMatrix[0][i][iax] == 1){
				if(i<9)
					ax_dep_on = ax_dep_on.concat("RT00"+Integer.toString(i+1) + " ");
				else if(i>=9 && i<99)
					ax_dep_on = ax_dep_on.concat("RT0"+Integer.toString(i+1) + " ");
				else
					ax_dep_on = ax_dep_on.concat("RT"+Integer.toString(i+1) + " ");
			}
		}
		addComponent(jPanel1, j1, 150,20,100,25);
		
		addComponent(jPanel1, priolabel1, 30,59,150,25);
		addComponent(jPanel1, deplabel1, 30,99,150,25);
		addComponent(jPanel1, deplabel11, 200,139,150,25);
		addComponent(jPanel1, reqDesc1, 30,179,150,25);
		addComponent(jPanel1, priolabel1txt, 200,59,150,25);
		addComponent(jPanel1, deplabel1txt, 200,99,150,25);
		addComponent(jPanel1, deplabel11txt, 30,139,150,25);
		addComponent(jPanel1, reqDesc1txt, 150,179,250,150);
		priolabel1txt.setText(Integer.toString(axpriority));
		deplabel1txt.setText(ax_dep_on);
		deplabel11txt.setText(reqs_dep_on_ax);
		reqDesc1txt.setText(axdescription);
		priolabel1txt.setEditable(false);
		deplabel1txt.setEditable(false);
		deplabel11txt.setEditable(false);
		reqDesc1txt.setEditable(false);
		reqDesc1txt.setLineWrap(true);
		
		int ibx = Integer.parseInt(bx.substring(2, 5))-1;
		int bxpriority=9999;
		String bxdescription="";
		String bx_dep_on=""; String reqs_dep_on_bx="";
		for(int i=0; i<IAHP.NUM_REQ; i++){
			if(bx.equalsIgnoreCase(getPriority.listNodes[0][i])){
				bxpriority = getPriority.nodesPriority[0][i];
				bxdescription = getPriority.listReq[0][i];
			}
		}
		for(int i=0; i<IAHP.SEQ_REQ; i++){
			if(buildDependencyGraph.depndencyMatrix[0][ibx][i] == 1){
				if(i<9)
					reqs_dep_on_bx = reqs_dep_on_bx.concat("RT00"+Integer.toString(i+1) + " ");
				else if(i>=9 && i<99)
					reqs_dep_on_bx = reqs_dep_on_bx.concat("RT0"+Integer.toString(i+1) + " ");
				else
					reqs_dep_on_bx = reqs_dep_on_bx.concat("RT"+Integer.toString(i+1) + " ");
			}
		}
		for(int i=0; i<IAHP.SEQ_REQ; i++){
			if(buildDependencyGraph.depndencyMatrix[0][i][ibx] == 1){
				if(i<9)
					bx_dep_on = bx_dep_on.concat("RT00"+Integer.toString(i+1) + " ");
				else if(i>=9 && i<99)
					bx_dep_on = bx_dep_on.concat("RT0"+Integer.toString(i+1) + " ");
				else
					bx_dep_on = bx_dep_on.concat("RT"+Integer.toString(i+1) + " ");
			}
		}
		addComponent(jPanel2, j2, 150,20,100,25);
		addComponent(jPanel2, priolabel2, 30,59,150,25);
		addComponent(jPanel2, deplabel2, 30,99,150,25);
		addComponent(jPanel2, deplabel21, 200,139,150,25);
		addComponent(jPanel2, reqDesc2, 30,179,150,25);
		addComponent(jPanel2, priolabel2txt, 200,59,150,25);
		addComponent(jPanel2, deplabel2txt, 200,99,150,25);
		addComponent(jPanel2, deplabel21txt, 30,139,150,25);
		addComponent(jPanel2, reqDesc2txt, 150,179,250,150);
		
		area.append("\n1: Ri == Rj	Ri Equally important to Rj\n");
		area.append("3: Ri > Rj	Ri Moderately MI than Rj\n");
		if(maxV >= 5){
		area.append("5: Ri >> Rj	Ri Strongly MI than Rj\n");
		}
		if(maxV >= 7){
			area.append("7: Ri >>> Rj	Ri Very strongly MI than Rj\n");	
		}
		if(maxV >= 9){
			area.append("9: Ri >>>> Rj	Ri Extremely MI than Rj\n");
		}
		area.append("\nMI = More Important\n");
		area.setLineWrap(true);
		area.setEditable(false);
		area.setWrapStyleWord(true);
		area.setBorder(BorderFactory.createTitledBorder("Scale between " + minV + " and " + maxV));
		area.setPreferredSize(new Dimension(250, 100));
		addComponent(jPanel3, area, 30,90,430,185);
	
		rb1.setText("1 : 1");
		rb1.setToolTipText(ax+" == "+bx);
		f = new Font("Dialog", Font.BOLD, 14);
		rb1.setFont(f);
		rb1.setVerticalTextPosition(SwingConstants.BOTTOM);
		rb1.setHorizontalTextPosition(SwingConstants.CENTER);
		rb1.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				rb1_itemStateChanged(e);
			}
		});
		rbl3.setText("3 : 1");
		rbl3.setFont(f);
		rbl3.setToolTipText(ax+" > "+bx);
		rbl3.setVerticalTextPosition(SwingConstants.BOTTOM);
		rbl3.setHorizontalTextPosition(SwingConstants.CENTER);
		rbl3.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				rbl3_itemStateChanged(e);
			}
		});
		rbl5.setText("5 : 1"); rbl5.setFont(f);
		rbl5.setToolTipText(ax+" >> "+bx);
		rbl5.setVerticalTextPosition(SwingConstants.BOTTOM);
		rbl5.setHorizontalTextPosition(SwingConstants.CENTER);
		rbl5.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				rbl5_itemStateChanged(e);
			}
		});
		rbr3.setText("1 : 3"); rbr3.setFont(f);
		rbr3.setToolTipText(ax+" < "+bx);
		rbr3.setVerticalTextPosition(SwingConstants.BOTTOM);
		rbr3.setHorizontalTextPosition(SwingConstants.CENTER);
		rbr3.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				rbr3_itemStateChanged(e);
			}
		});
		rbr5.setText("1 : 5"); rbr5.setFont(f);
		rbr5.setToolTipText(ax+" >> "+bx);
		rbr5.setVerticalTextPosition(SwingConstants.BOTTOM);
		rbr5.setHorizontalTextPosition(SwingConstants.CENTER);
		rbr5.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				rbr5_itemStateChanged(e);
			}
		});
	
		rbl7.setText("7 : 1"); rbl7.setFont(f);
		rbl7.setToolTipText(ax+" >>> "+bx);
		rbl7.setVerticalTextPosition(SwingConstants.BOTTOM);
		rbl7.setHorizontalTextPosition(SwingConstants.CENTER);
		rbl7.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				rbl7_itemStateChanged(e);
			}
		});
		rbr7.setText("1 : 7"); rbr7.setFont(f);
		rbr7.setToolTipText(ax+" <<< "+bx);
		rbr7.setVerticalTextPosition(SwingConstants.BOTTOM);
		rbr7.setHorizontalTextPosition(SwingConstants.CENTER);
		rbr7.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				rbr7_itemStateChanged(e);
			}
		});
	
		rbl9.setText("9 : 1"); rbl9.setFont(f);
		rbl9.setToolTipText(ax+" >>>> "+bx);
		rbl9.setVerticalTextPosition(SwingConstants.BOTTOM);
		rbl9.setHorizontalTextPosition(SwingConstants.CENTER);
		rbl9.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				rbl9_itemStateChanged(e);
			}
		});
		rbr9.setText("1 : 9"); rbr9.setFont(f);
		rbr9.setToolTipText(ax+" <<<< "+bx);
		rbr9.setVerticalTextPosition(SwingConstants.BOTTOM);
		rbr9.setHorizontalTextPosition(SwingConstants.CENTER);
		rbr9.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e)
			{
				rbr9_itemStateChanged(e);
			}
		});
		
		addComponent(jPanel3, okbutton, 600,180,100,40);
		//addComponent(jPanel3, cnclbutton, 680,180,85,30);
				
		addComponent(jPanel3, rbl3, 360,30,80,40);
		addComponent(jPanel3, rb1, 470,30,80,40);
		addComponent(jPanel3, rbr3, 555,30,80,40);
		if(maxV >= 5){
			addComponent(jPanel3, rbl5, 250,30,80,40);
			addComponent(jPanel3, rbr5, 650,30,80,40);
		}
		if(maxV >= 7){
			addComponent(jPanel3, rbl7, 150,30,80,40);
			addComponent(jPanel3, rbr7, 740,30,80,40);
		}
		if(maxV >= 9){
			addComponent(jPanel3, rbr9, 840,30,80,40);
			addComponent(jPanel3, rbl9, 60,30,80,40);
		}
		//addComponent(jPanel3, jp1show, 580,150,90,25);
		//addComponent(jPanel3, jp2show, 680,150,90,25);
		addComponent(jPanel3, j3, 570,120,180,25);
		priolabel2txt.setText(Integer.toString(bxpriority));
		deplabel2txt.setText(bx_dep_on);
		deplabel21txt.setText(reqs_dep_on_bx);
		reqDesc2txt.setText(bxdescription);
		priolabel2txt.setEditable(false);
		deplabel2txt.setEditable(false);
		deplabel21txt.setEditable(false);
		reqDesc2txt.setEditable(false);
		reqDesc2txt.setLineWrap(true);

		this.setTitle("Elicitation between " + elicitPairs.ax + " and " + elicitPairs.bx);
		this.setLocation(new Point(0, 0));
		//this.setAlwaysOnTop(true);
		this.setSize(new Dimension(1000, 700));
		this.setVisible(true);
		//this.setAlwaysOnTop(true);
	}
	
	public void jp1show_actionPerformed(ActionEvent e) {

	}
	
	public void jp2show_actionPerformed(ActionEvent e) {

	}

	//public void cnclbutton_actionPerformed(ActionEvent e) {
	//	//UPDATE HERE THE ELICITED MATRIX...
	//	ELICITFLAG=0;
	//	this.hide();
	//}
	
	public void rb1_itemStateChanged(ItemEvent e) {
		if(e.getStateChange() == ItemEvent.SELECTED){
			rbl3.setSelected(false); rbr3.setSelected(false);
			rbl5.setSelected(false); rbr5.setSelected(false);
			rbl7.setSelected(false); rbr7.setSelected(false);
			rbl9.setSelected(false); rbr9.setSelected(false);	
			okbutton.setEnabled(true);
		}
	}
	public void rbl3_itemStateChanged(ItemEvent e) {
		if(e.getStateChange() == ItemEvent.SELECTED){
			rb1.setSelected(false);
			rbr3.setSelected(false);
			rbl5.setSelected(false); rbr5.setSelected(false);
			rbl7.setSelected(false); rbr7.setSelected(false);
			rbl9.setSelected(false); rbr9.setSelected(false);	
			okbutton.setEnabled(true);
		}						
	}

	public void rbl5_itemStateChanged(ItemEvent e) {
		if(e.getStateChange() == ItemEvent.SELECTED){
			rb1.setSelected(false);
			rbl3.setSelected(false); rbr3.setSelected(false);
			rbr5.setSelected(false);
			rbl7.setSelected(false); rbr7.setSelected(false);
			rbl9.setSelected(false); rbr9.setSelected(false);	
			okbutton.setEnabled(true);
		}						
	}

	public void rbl7_itemStateChanged(ItemEvent e) {
		if(e.getStateChange() == ItemEvent.SELECTED){
			rb1.setSelected(false);
			rbl3.setSelected(false); rbr3.setSelected(false);
			rbl5.setSelected(false); rbr5.setSelected(false);
			rbr7.setSelected(false);
			rbl9.setSelected(false); rbr9.setSelected(false);		
			okbutton.setEnabled(true);
		}		
	}

	public void rbl9_itemStateChanged(ItemEvent e) {
		if(e.getStateChange() == ItemEvent.SELECTED){
			rb1.setSelected(false);
			rbl3.setSelected(false); rbr3.setSelected(false);
			rbl5.setSelected(false); rbr5.setSelected(false);
			rbl7.setSelected(false); rbr7.setSelected(false);
			rbr9.setSelected(false);		
			okbutton.setEnabled(true);
		}			
	}
	
	public void rbr3_itemStateChanged(ItemEvent e) {
		if(e.getStateChange() == ItemEvent.SELECTED){
			rb1.setSelected(false);
			rbl3.setSelected(false);
			rbl5.setSelected(false); rbr5.setSelected(false);
			rbl7.setSelected(false); rbr7.setSelected(false);
			rbl9.setSelected(false); rbr9.setSelected(false);		
			okbutton.setEnabled(true);
		}						
	}

	public void rbr5_itemStateChanged(ItemEvent e) {
		if(e.getStateChange() == ItemEvent.SELECTED){
			rb1.setSelected(false);
			rbl3.setSelected(false); rbr3.setSelected(false);
			rbl5.setSelected(false);
			rbl7.setSelected(false); rbr7.setSelected(false);
			rbl9.setSelected(false); rbr9.setSelected(false);			
			okbutton.setEnabled(true);
		}						
	}

	public void rbr7_itemStateChanged(ItemEvent e) {
		if(e.getStateChange() == ItemEvent.SELECTED){
			rb1.setSelected(false);
			rbl3.setSelected(false); rbr3.setSelected(false);
			rbl5.setSelected(false); rbr5.setSelected(false);
			rbl7.setSelected(false);
			rbl9.setSelected(false); rbr9.setSelected(false);		
			okbutton.setEnabled(true);
		}		
	}

	public void rbr9_itemStateChanged(ItemEvent e) {
		if(e.getStateChange() == ItemEvent.SELECTED){
			rb1.setSelected(false);
			rbl3.setSelected(false); rbr3.setSelected(false);
			rbl5.setSelected(false); rbr5.setSelected(false);
			rbl7.setSelected(false); rbr7.setSelected(false);
			rbl9.setSelected(false);
			okbutton.setEnabled(true);
		}			
	}
	public void okbutton_actionPerformed(ActionEvent e) {
		ELICITFLAG=-1; errorflag=0;
		String src = null, dst = null;
		//UPDATE HERE THE ELICITED MATRIX...
		//int iax = Integer.parseInt(ax.substring(2, 5))-1;
		//int ibx = Integer.parseInt(bx.substring(2, 5))-1;
		if(rb1.isSelected() == true)
			intensity = 1.0;
		else if(rbl3.isSelected() == true)
			intensity = 3.0;
		else if(rbl5.isSelected() == true)
			intensity = 5.0;
		else if(rbl7.isSelected() == true)
			intensity = 7.0;
		else if(rbl9.isSelected() == true)
			intensity = 9.0;
		else if(rbr3.isSelected() == true)
			intensity = 1.0/3.0;
		else if(rbr5.isSelected() == true)
			intensity = 1.0/5.0;
		else if(rbr7.isSelected() == true)
			intensity = 1.0/7.0;
		else if(rbr9.isSelected() == true)
			intensity = 1.0/9.0;
		buildMatrixIAHP.elicitedPairs[IAHP.NoOfElicitedPair] = ax + " " + bx;
		IAHP.graph.addEdge(ax, bx);
		IAHP.graph.addEdge(bx, ax);
		JOptionPane.showMessageDialog(null, "   Eliciting pair  [ "+ax+", "+bx+" ]   as   # " + Integer.toString(IAHP.NoOfElicitedPair+1) + "   ");
		
		ELICITFLAG=1;
		src  = ax; dst = bx;
			
		//calculate user error here...if he did
		if(mainGUI.GSFLAG == 1){
		int SRCindxGS = 0, DSTindxGS = 0;
		for(int j=0; j<IAHP.NUM_REQ; j++){
			String tmp = getGoldStd.gS[j];
			if(src.equalsIgnoreCase(tmp))
				SRCindxGS = j;
			if(dst.equalsIgnoreCase(tmp))
				DSTindxGS = j;
		}
		if(DSTindxGS < SRCindxGS){
			IAHP.errorPair++;
			buildMatrixIAHP.errorEli[IAHP.errorPair-1] = src + " " + dst;
			errorflag = 1;
		}
	}
		this.hide();
		}
	public static void addComponent(Container container, Component c, int x, int y, int width, int height){
		c.setBounds(x, y, width, height);
		container.add(c);
	}
  


	public static void doElicitPairs(String reqOrder, String reqOrder2, int a, int b, int minV, int maxV)throws IOException, HeadlessException, ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
		System.out.println("Starting user elicitation session for IAHP...");
		ax = reqOrder;
		bx = reqOrder2;
		ELICITFLAG=-1;
		IAHP.ELI_START_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
		String str1 = "Elicitation between " + elicitPairs.ax + " and " + elicitPairs.bx;
		new elicitPairs(new JFrame(), str1, minV, maxV);
		IAHP.ELI_END_TIME = Double.parseDouble((mainGUI.fmtObj.format((double)System.currentTimeMillis()/1000)));
		if(ELICITFLAG==1){
			IAHP.NoOfElicitedPair++;
			buildMatrixIAHP.A[a][b] = Double.parseDouble(fmtObj.format(intensity));
			buildMatrixIAHP.A[b][a] = Double.parseDouble(fmtObj.format(1.0/intensity));
			buildMatrixIAHP.nn++;
			buildMatrixIAHP.ELI_INDV_TIME[IAHP.NoOfElicitedPair-1] = Double.parseDouble((mainGUI.fmtObj.format(IAHP.ELI_END_TIME - IAHP.ELI_START_TIME)));
			if(IAHP.NoOfElicitedPair == 1)
				buildMatrixIAHP.ELI_CUMUL_TIME_SUM[IAHP.NoOfElicitedPair-1] = Double.parseDouble((mainGUI.fmtObj.format(buildMatrixIAHP.ELI_INDV_TIME[IAHP.NoOfElicitedPair-1])));
			else
				buildMatrixIAHP.ELI_CUMUL_TIME_SUM[IAHP.NoOfElicitedPair-1] = Double.parseDouble((mainGUI.fmtObj.format(buildMatrixIAHP.ELI_INDV_TIME[IAHP.NoOfElicitedPair-1]))) + Double.parseDouble((mainGUI.fmtObj.format(buildMatrixIAHP.ELI_CUMUL_TIME_SUM[IAHP.NoOfElicitedPair-2])));
			if(errorflag == 1)
				buildMatrixIAHP.eliOrderFlag[IAHP.NoOfElicitedPair-1] = 1;
			else
				buildMatrixIAHP.eliOrderFlag[IAHP.NoOfElicitedPair-1] = 0;
			double tmp = IAHP.ELI_END_TIME - IAHP.ELI_START_TIME;
			if(tmp >= IAHP.MAX_ELI_TIME)
				IAHP.MAX_ELI_TIME = Double.parseDouble((mainGUI.fmtObj.format(tmp)));
			if(tmp <= IAHP.MIN_ELI_TIME)
				IAHP.MIN_ELI_TIME =Double.parseDouble((mainGUI.fmtObj.format(tmp)));
			IAHP.TOTAL_ELI_TIME = IAHP.TOTAL_ELI_TIME + (IAHP.ELI_END_TIME - IAHP.ELI_START_TIME);
			IAHP.AVG_ELI_TIME = Double.parseDouble((mainGUI.fmtObj.format(IAHP.TOTAL_ELI_TIME / IAHP.NoOfElicitedPair)));
			
		}
		System.out.println("Closing user elicitation session for IAHP...");
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		setVisible(false);
	    dispose();		
	}
}


